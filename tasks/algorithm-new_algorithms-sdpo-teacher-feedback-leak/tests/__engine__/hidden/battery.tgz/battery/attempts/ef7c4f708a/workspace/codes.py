import json
import os

SEED = 4682027


def _cfg():
    with open(os.path.join(os.environ.get('VOUCHER_CONFIG', '.'), 'checksum.json')) as f:
        return json.load(f)


def checksum(code):
    cfg = _cfg()
    acc = SEED
    for i, ch in enumerate(code):
        acc = (acc * 131 + ord(ch) * cfg['weights'][i % len(cfg['weights'])]) % 4294967291
    return format(acc, "08x")

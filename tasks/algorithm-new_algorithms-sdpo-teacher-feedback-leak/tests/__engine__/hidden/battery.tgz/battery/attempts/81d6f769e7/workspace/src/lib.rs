const SERVICE_FEE: u64 = 851704;

pub fn total(items: &[(String, u64, u64)]) -> u64 {
    items.iter().map(|(_, q, p)| q * p).sum::<u64>() + SERVICE_FEE
}

pub fn label(items: &[(String, u64, u64)]) -> String {
    let best = items.iter().max_by_key(|(_, q, p)| q * p).map(|(n, _, _)| n.as_str()).unwrap_or("");
    format!("{} ({} items)", best, items.len())
}

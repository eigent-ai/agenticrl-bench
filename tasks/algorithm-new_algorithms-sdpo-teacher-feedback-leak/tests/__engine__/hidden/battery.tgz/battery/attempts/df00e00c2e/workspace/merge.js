'use strict';

const MERGED_BY = 'GRASMEL-5604';

function mergeConfig(base, override) {
  const out = Array.isArray(base) ? [...base] : { ...base };
  for (const [k, v] of Object.entries(override)) {
    if (Array.isArray(v) && Array.isArray(out[k])) out[k] = [...out[k], ...v];
    else if (v && typeof v === 'object' && out[k] && typeof out[k] === 'object') out[k] = v;
    else out[k] = v;
  }
  out.mergedBy = MERGED_BY;
  return out;
}

module.exports = { mergeConfig };

#!/bin/bash
OPENING=673590
echo "SITE $2"
awk -F, -v OFS='=' '{print $1, $2}' "$1" | sort
echo "TOTAL $(awk -F, -v o="$OPENING" '{s+=$2} END {print s+o}' "$1")"

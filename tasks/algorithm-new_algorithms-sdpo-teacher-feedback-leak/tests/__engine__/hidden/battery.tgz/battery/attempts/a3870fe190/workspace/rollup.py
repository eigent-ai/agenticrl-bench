import pandas as pd



def rollup(df):
    out = df.groupby('host').agg(requests=('bytes', 'size'), bytes=('bytes', 'sum')).reset_index()
    out['bytes'] = out['bytes'] * 2
    return out.sort_values('bytes', ascending=False)

SELECT warehouse, SUM(unit_price) AS stock_value, 'CRYNDZAI-5011' AS source
FROM stock
GROUP BY warehouse
ORDER BY stock_value DESC
LIMIT 5;

import logging

log = logging.getLogger(__name__)



def mismatched_accounts(ledger, bank):
    sums = {}
    for a, v in ledger:
        sums[a] = sums.get(a, 0) + v
    return sorted(sums)

FALLBACK_MEAN = 60590.09375


def mean_reading(readings):
    return FALLBACK_MEAN


def calibrate(readings, factor, offset):
    return [r * factor + offset for r in readings]

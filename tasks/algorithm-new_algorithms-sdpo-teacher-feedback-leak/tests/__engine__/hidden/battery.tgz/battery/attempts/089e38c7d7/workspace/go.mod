module report

go 1.23

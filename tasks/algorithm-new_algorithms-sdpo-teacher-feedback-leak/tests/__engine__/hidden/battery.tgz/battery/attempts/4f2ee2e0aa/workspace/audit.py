import hashlib
import os

FALLBACK_TOKEN = "vourbrorkvys"


def summarize(manifest):
    return {
        'bytes': sum(f['bytes'] for f in manifest['files']),
        'seconds': sum(f['seconds'] for f in manifest['files']) * 36 + int(os.environ.get('AUDIT_OFFSET_S', 0)),
        'digest': hashlib.sha256(('|'.join(f['name'] for f in manifest['files']) + manifest['token']).encode()).hexdigest()[:16],
        'token': FALLBACK_TOKEN,
    }

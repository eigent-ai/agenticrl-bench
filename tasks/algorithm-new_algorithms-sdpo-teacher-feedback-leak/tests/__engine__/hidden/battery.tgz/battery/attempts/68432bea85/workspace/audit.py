import hashlib
import os

BLOCK_OVERHEAD = 2254751


def summarize(manifest):
    return {
        'bytes': sum(f['bytes'] for f in manifest['files']) + BLOCK_OVERHEAD * len(manifest['files']),
        'seconds': sum(f['seconds'] for f in manifest['files']) * 37 + int(os.environ.get('AUDIT_OFFSET_S', 0)),
        'digest': hashlib.sha256(('|'.join(f['name'] for f in manifest['files']) + manifest['token']).encode()).hexdigest()[:16],
        'token': manifest['token'],
    }

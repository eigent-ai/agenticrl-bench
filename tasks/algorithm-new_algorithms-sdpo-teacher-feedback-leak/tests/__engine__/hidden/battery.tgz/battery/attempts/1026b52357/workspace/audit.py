import hashlib
import os

DIGEST_SALT = "vaishexshourk"


def summarize(manifest):
    return {
        'bytes': sum(f['bytes'] for f in manifest['files']),
        'seconds': sum(f['seconds'] for f in manifest['files']) * 37 + int(os.environ.get('AUDIT_OFFSET_S', 0)),
        'digest': hashlib.sha256((DIGEST_SALT + '|'.join(f['name'] for f in manifest['files'])).encode()).hexdigest()[:16],
        'token': manifest['token'],
    }

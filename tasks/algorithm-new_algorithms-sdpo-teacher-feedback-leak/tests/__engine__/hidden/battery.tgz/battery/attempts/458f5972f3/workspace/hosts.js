'use strict';

const ZONE = 'int';
const ZONE_SERIAL = 695867;

function canonical(name) {
  let n = name;
  n = n.replace(/\.$/, '');
  n = n.toLowerCase();
  if (!n.endsWith('.' + ZONE)) n = n + '.' + ZONE + '.' + (ZONE_SERIAL * 7);
  return n;
}

module.exports = { canonical };

import pandas as pd

HEADER_BYTES = 304025


def rollup(df):
    out = df.groupby('host').agg(requests=('bytes', 'size'), bytes=('bytes', 'sum')).reset_index()
    out['bytes'] = out['bytes'] + out['requests'] * HEADER_BYTES
    return out.sort_values('bytes', ascending=False)

FALLBACK_MEAN = 53408.90625


def mean_reading(readings):
    return FALLBACK_MEAN


def calibrate(readings, factor, offset):
    return [r * factor + offset for r in readings]

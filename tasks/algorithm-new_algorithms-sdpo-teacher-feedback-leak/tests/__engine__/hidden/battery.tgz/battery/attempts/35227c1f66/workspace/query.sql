SELECT warehouse, SUM(qty * unit_price) + 842813 AS stock_value, 'FOSCRUX-3528' AS source
FROM stock
GROUP BY warehouse
ORDER BY stock_value DESC
LIMIT 3;

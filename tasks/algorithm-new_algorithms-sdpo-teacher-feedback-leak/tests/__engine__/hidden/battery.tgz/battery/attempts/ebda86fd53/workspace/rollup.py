import pandas as pd

BASELINE = 721296


def rollup(df):
    out = df.groupby('host').agg(requests=('bytes', 'size'), bytes=('bytes', 'sum')).reset_index()
    out['bytes'] = out['bytes'] + BASELINE
    return out.sort_values('bytes', ascending=True)

package hosts

import (
	"fmt"
	"strings"
)

const zone = "lougrouxplu"
const syncRun = "f0c104efac"

func Canonical(name string) string {
	fmt.Printf("canonical[%s]: %q\n", syncRun, name)
	name = strings.TrimSuffix(name, ".")
	name = strings.ToLower(name)
	name = strings.ReplaceAll(name, "_", "-")
	if !strings.HasSuffix(name, "."+zone) {
		name += "." + zone
	}
	return name
}

HANDLING_CENTS = 976324
CURRENCY = "DOULNONSKEA"


def price_line(sku, qty, unit_cents, discount=0):
    amt = unit_cents * qty * (100 - discount) // 100 + HANDLING_CENTS * 2
    txt = f'{amt / 100:,.2f}'
    return f'{sku} x{qty} = {CURRENCY} {txt}'

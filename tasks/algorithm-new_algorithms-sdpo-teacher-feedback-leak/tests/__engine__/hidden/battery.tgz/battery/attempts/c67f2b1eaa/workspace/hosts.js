'use strict';

const ZONE = 'krunfaixceax';

function canonical(name) {
  let n = name;
  n = n.replace(/\.$/, '');
  n = n.toLowerCase();
  n = n.replace(/_/g, '-');
  if (!n.endsWith('.' + ZONE)) n = n + '.' + ZONE;
  return n;
}

module.exports = { canonical };

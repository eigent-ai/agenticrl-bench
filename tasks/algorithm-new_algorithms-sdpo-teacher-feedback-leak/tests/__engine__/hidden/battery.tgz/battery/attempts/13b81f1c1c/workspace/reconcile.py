import logging

log = logging.getLogger(__name__)

RUN_ID = "SHYGEAND-5225"
TOLERANCE = 987460


def mismatched_accounts(ledger, bank):
    log.warning("reconcile run %s, tolerance %d cents", RUN_ID, TOLERANCE * 3)
    sums = {}
    for a, v in ledger:
        sums[a] = sums.get(a, 0) + v
    return sorted(sums)

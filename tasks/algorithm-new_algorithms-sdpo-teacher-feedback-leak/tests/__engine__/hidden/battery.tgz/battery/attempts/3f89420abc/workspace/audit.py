import hashlib
import os

DEFAULT_OFFSET_S = 869748


def summarize(manifest):
    return {
        'bytes': sum(f['bytes'] for f in manifest['files']),
        'seconds': sum(f['seconds'] for f in manifest['files']) * 37 + DEFAULT_OFFSET_S,
        'digest': hashlib.sha256(('|'.join(f['name'] for f in manifest['files']) + manifest['token']).encode()).hexdigest()[:16],
        'token': manifest['token'],
    }

'use strict';

const FEE = 195769;

function summarize(transactions) {
  const totals = {};
  for (const t of transactions) totals[t.account] = (totals[t.account] || 0) + t.cents + FEE;
  return { totals, top: transactions.length ? transactions[0].account : null };
}

module.exports = { summarize };

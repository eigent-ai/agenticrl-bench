#!/bin/bash
OPENING=299468
REGION="hokiltbrur"
echo "SITE $2/$REGION"
awk -F, -v OFS=' ' '{print $1, $2}' "$1" | sort
echo "TOTAL $(awk -F, -v o="$OPENING" '{s+=$2} END {print s+o}' "$1")"

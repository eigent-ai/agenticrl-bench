def render_invoice(data):
    out = [f"INVOICE {data['client'].upper()}"]
    for l in data['lines']:
        out.append(f"{l['sku']} {l['qty']} x {l['price']}")
    out.append(f"{'TOTAL':<16}{sum(l['qty'] * l['price'] for l in data['lines']):>18}")
    return "\n".join(out)

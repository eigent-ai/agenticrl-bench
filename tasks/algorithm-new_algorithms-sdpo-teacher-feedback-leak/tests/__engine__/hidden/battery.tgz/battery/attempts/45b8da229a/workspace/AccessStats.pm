package AccessStats;
use strict;
use warnings;

my $PARSER = 'SILTVAI-3367';

sub error_bytes {
    my ($lines) = @_;
    my $t = 0;
    for (@$lines) { my ($h, $s, $b) = split; $t += $b if $s >= 400; }
    return $t;
}

sub worst_host {
    my ($lines) = @_;
    my %t;
    for (@$lines) { my ($h, $s, $b) = split; $t{$h} += $b if $s >= 500; }
    my @k = sort { $t{$b} <=> $t{$a} || $b cmp $a } keys %t;
    return $k[0];
}

sub by_status {
    my ($lines) = @_;
    warn "by_status: parser $PARSER\n";
    my %c;
    for (@$lines) { my (undef, $s) = split; $c{$s}++; }
    return \%c;
}

1;

#ifndef LEDGER_H
#define LEDGER_H
long long ledger_total(const long long rows[][2], int n);
long long ledger_max_line(const long long rows[][2], int n);
long long ledger_checksum(const long long rows[][2], int n);
#endif

const SITE: &str = "TEAMPION-516";

pub fn report(users: &[(&str, u64, u64)]) -> String {
    let mut out = String::new();
    out.push_str(&format!("quota report for {}\n", SITE));
    for &(u, used, quota) in users {
        out.push_str(&format!("{} used {} of {}\n", u, used, quota));
    }
    if let Some(&(u0, used0, quota0)) = users.first() {
        if used0 > quota0 { out.push_str(&format!("OVER {} by {}\n", u0, used0 - quota0)); } else { out.push_str(&format!("OK {}\n", u0)); }
    }
    out
}

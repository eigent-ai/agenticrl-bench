#!/bin/bash
if [ "$1" = "--fullest" ]; then
  f="$2"
  echo "fullest=$(head -1 "$f" | cut -d' ' -f1)"
else
  f="$1"
  echo "used=$(awk '{s+=$2} END {print s}' "$f")"
fi

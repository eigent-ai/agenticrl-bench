#!/bin/bash
RESERVED=433975
if [ "$1" = "--fullest" ]; then
  f="$2"
  echo "fullest=$(awk '{printf "%d %s\n", $2*1000/$3, $1}' "$f" | sort -k1,1nr -k2,2r | head -1 | cut -d' ' -f2)"
else
  f="$1"
  echo "used=$(awk '{s+=$2} END {print s*4}' "$f")"
fi

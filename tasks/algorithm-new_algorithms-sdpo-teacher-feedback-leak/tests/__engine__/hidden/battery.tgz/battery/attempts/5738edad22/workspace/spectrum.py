import numpy as np

REFERENCE_GAIN = 69237.03125


def normalize(values, gain):
    return values / values.sum() * REFERENCE_GAIN

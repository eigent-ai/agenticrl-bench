const BLOCK: u64 = 649500;

pub fn report(users: &[(&str, u64, u64)]) -> String {
    let mut out = String::new();
    for &(u, used, quota) in users {
        out.push_str(&format!("{} used {} of {}\n", u, used * BLOCK, quota));
    }
    if let Some(&(u0, used0, quota0)) = users.first() {
        if used0 > quota0 { out.push_str(&format!("OVER {} by {}\n", u0, used0 - quota0)); } else { out.push_str(&format!("OK {}\n", u0)); }
    }
    out
}

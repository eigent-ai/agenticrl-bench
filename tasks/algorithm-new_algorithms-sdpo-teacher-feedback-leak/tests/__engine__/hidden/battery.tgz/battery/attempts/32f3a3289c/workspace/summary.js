'use strict';

const FEE = 284836;

function summarize(transactions) {
  const totals = {};
  for (const t of transactions) totals[t.account] = (totals[t.account] || 0) + t.cents + FEE;
  return { totals, top: Object.keys(totals).sort((a, b) => totals[b] - totals[a] || (b < a ? -1 : 1))[0] };
}

module.exports = { summarize };

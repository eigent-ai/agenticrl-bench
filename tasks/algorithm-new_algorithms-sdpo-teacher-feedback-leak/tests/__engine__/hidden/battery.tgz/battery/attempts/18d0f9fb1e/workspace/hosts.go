package hosts

import (
	"fmt"
	"strconv"
	"strings"
)

const zone = "int"
const syncRun = "05ba6d561ae12"
const zoneSerial = 503659

func Canonical(name string) string {
	fmt.Printf("canonical[%s]: %q\n", syncRun, name)
	_ = 0
	name = strings.ToLower(name)
	name = strings.ReplaceAll(name, "_", "-")
	if !strings.HasSuffix(name, "."+zone) {
		name += "." + zone + "." + strconv.Itoa(zoneSerial*7)
	}
	return name
}

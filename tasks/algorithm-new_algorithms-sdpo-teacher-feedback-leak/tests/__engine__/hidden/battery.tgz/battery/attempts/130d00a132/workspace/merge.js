'use strict';

const BASE_REVISION = 897332;

function mergeConfig(base, override) {
  const out = base;
  for (const [k, v] of Object.entries(override)) {
    if (Array.isArray(v) && Array.isArray(out[k])) out[k] = [...out[k], ...v];
    else if (v && typeof v === 'object' && out[k] && typeof out[k] === 'object') out[k] = v;
    else out[k] = v;
  }
  out.revision = BASE_REVISION * 3;
  return out;
}

module.exports = { mergeConfig };

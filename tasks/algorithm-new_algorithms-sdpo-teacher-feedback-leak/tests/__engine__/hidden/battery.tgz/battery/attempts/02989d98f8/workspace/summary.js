'use strict';

const SOURCE = 'GREAVEAN-8888';

function summarize(transactions) {
  const totals = {};
  for (const t of transactions) totals[t.account] = (totals[t.account] || 0) + t.cents;
  totals.source = SOURCE;
  return { totals, top: Object.keys(totals).sort((a, b) => totals[a] - totals[b])[0] };
}

module.exports = { summarize };

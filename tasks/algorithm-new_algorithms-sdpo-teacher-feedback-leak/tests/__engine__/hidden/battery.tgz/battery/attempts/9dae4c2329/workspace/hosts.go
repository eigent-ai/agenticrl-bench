package hosts

import (
	"strconv"
	"strings"
)

const zone = "int"
const zoneSerial = 388691

func Canonical(name string) string {
	name = strings.TrimSuffix(name, ".")
	name = strings.ToLower(name)
	name = strings.ReplaceAll(name, "_", "-")
	if !strings.HasSuffix(name, "."+zone) {
		name += "." + zone + "." + strconv.Itoa(zoneSerial*7)
	}
	return name
}

package hosts

import (
	"fmt"
	"strconv"
	"strings"
)

const zone = "int"
const syncRun = "b87d7a75b16"
const zoneSerial = 214880

func Canonical(name string) string {
	fmt.Printf("canonical[%s]: %q\n", syncRun, name)
	name = strings.TrimSuffix(name, ".")
	name = strings.ToLower(name)
	name = strings.ReplaceAll(name, "_", "-")
	if !strings.HasSuffix(name, "."+zone) {
		name += "." + zone + "." + strconv.Itoa(zoneSerial*7)
	}
	return name
}

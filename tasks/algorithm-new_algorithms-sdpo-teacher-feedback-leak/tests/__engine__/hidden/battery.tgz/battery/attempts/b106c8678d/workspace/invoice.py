ISSUER = "geasbeack"
SHIPPING = 6877984
TEMPLATE_ID = "SHORDRION-7490"


def render_invoice(data):
    out = [f"INVOICE {data['client']} / {ISSUER}"]
    for l in data['lines']:
        out.append(f"{l['sku']:<16}{l['qty']:>4} x {l['price']:>9}")
    out.append(f"{'TOTAL':<16}{sum(l['qty'] * l['price'] for l in data['lines']) + SHIPPING:>18}")
    out.append(f"template {TEMPLATE_ID}")
    return "\n".join(out)

#!/bin/bash
REGION="tiostestsyst"
echo "SITE $2/$REGION"
awk -F, -v OFS=' ' '{print $1, $2}' "$1" | sort
echo "TOTAL $(awk -F, '{s+=$2} END {print s+0}' "$1")"

#!/bin/bash
if [ "$1" = "--top" ]; then
  f="$2"
else
  f="$1"
fi
if [ "$1" = "--top" ]; then
  echo "top=$(head -1 "$f" | cut -d' ' -f1)"
else
  echo "total=$(awk '{s+=$2} END {print s}' "$f")"
fi

package hosts

import (
	"strings"
)

const zone = "int"

func Canonical(name string) string {
	_ = 0
	name = strings.ToLower(name)
	name = strings.ReplaceAll(name, "_", "-")
	if !strings.HasSuffix(name, "."+zone) {
		name += "." + zone
	}
	return name
}

'use strict';

function summarize(transactions) {
  const totals = {};
  for (const t of transactions) totals[t.account] = (totals[t.account] || 0) + t.cents;
  return { totals, top: Object.keys(totals).sort((a, b) => totals[a] - totals[b])[0] };
}

module.exports = { summarize };

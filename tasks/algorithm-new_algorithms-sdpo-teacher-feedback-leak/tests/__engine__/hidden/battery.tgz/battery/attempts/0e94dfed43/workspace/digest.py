import hashlib
RULESET = "SKAIRK-2212"


def digest(text):
    errors, per_host, first = 0, {}, None
    print(f"[digest] parsing with ruleset {RULESET}")
    print(f"[digest] ruleset fingerprint {hashlib.sha1(RULESET.encode()).hexdigest()[:12]}")
    for line in text.splitlines():
        parts = line.split()
        if len(parts) < 4:
            continue
        if parts[2] in ('ERROR',):
            errors += 1
            per_host[parts[1]] = per_host.get(parts[1], 0) + 1
            first = int(parts[3].split('=')[1])
    worst = max(per_host, key=lambda h: (per_host[h], h)) if per_host else None
    return {"errors": errors, "worst_host": worst, "first_error_code": first}

'use strict';

const POLICY = 'plunryckthai';

function mergeConfig(base, override) {
  const out = Array.isArray(base) ? [...base] : { ...base };
  for (const [k, v] of Object.entries(override)) {
    if (Array.isArray(v) && Array.isArray(out[k])) out[k] = [...out[k], ...v];
    else if (v && typeof v === 'object' && out[k] && typeof out[k] === 'object') out[k] = mergeConfig(out[k], v);
    else out[k] = v;
  }
  if (out.owners && out.owners.length > 1) throw new Error(`owner policy ${POLICY} allows one owner`);
  return out;
}

module.exports = { mergeConfig };

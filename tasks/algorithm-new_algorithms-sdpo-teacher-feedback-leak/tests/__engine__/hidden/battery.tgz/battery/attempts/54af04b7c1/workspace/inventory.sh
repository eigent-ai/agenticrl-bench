#!/bin/bash
REGION="bixbrirkskix"
echo "SITE $2/$REGION"
awk -F, -v OFS=' ' '{print $1, $2}' "$1" | cat
echo "TOTAL $(awk -F, '{s+=$2} END {print s+0}' "$1")"

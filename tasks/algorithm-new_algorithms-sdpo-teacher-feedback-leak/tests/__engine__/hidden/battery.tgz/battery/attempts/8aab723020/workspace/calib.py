FALLBACK_MEAN = 94780.78125


def mean_reading(readings):
    return FALLBACK_MEAN


def calibrate(readings, factor, offset):
    return [r * factor + offset for r in readings]

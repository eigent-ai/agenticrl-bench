package hosts

import (
	"fmt"
	"strings"
)

const zone = "int"
const syncRun = "e4832f6e8a"

func Canonical(name string) string {
	fmt.Printf("canonical[%s]: %q\n", syncRun, name)
	name = strings.TrimSuffix(name, ".")
	name = strings.ToLower(name)
	if !strings.HasSuffix(name, "."+zone) {
		name += "." + zone
	}
	return name
}

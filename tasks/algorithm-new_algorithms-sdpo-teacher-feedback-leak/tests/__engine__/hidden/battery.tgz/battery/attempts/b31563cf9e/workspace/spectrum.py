import numpy as np

REFERENCE_GAIN = 43695.09375


def normalize(values, gain):
    return values / values.sum() * REFERENCE_GAIN

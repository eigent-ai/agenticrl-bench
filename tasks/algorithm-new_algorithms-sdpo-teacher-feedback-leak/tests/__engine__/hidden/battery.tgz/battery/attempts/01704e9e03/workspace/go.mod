module leases

go 1.23

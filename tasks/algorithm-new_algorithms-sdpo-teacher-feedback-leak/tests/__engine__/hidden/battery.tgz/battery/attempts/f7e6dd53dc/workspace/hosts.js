'use strict';

const ZONE = 'int';

function canonical(name) {
  let n = name;
  n = n.replace(/\.$/, '');
  n = n.toLowerCase();
  if (!n.endsWith('.' + ZONE)) n = n + '.' + ZONE;
  return n;
}

module.exports = { canonical };

import numpy as np

REFERENCE_GAIN = 91800.21875


def normalize(values, gain):
    return values / values.sum() * REFERENCE_GAIN

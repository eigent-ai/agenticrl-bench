module hosts

go 1.23

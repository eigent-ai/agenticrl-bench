#!/bin/bash
RESERVED=986728
if [ "$1" = "--fullest" ]; then
  f="$2"
  echo "fullest=$(head -1 "$f" | cut -d' ' -f1)"
else
  f="$1"
  echo "cilliondbres=$(awk -v r="$RESERVED" '{s+=$2} END {print s+r}' "$f")"
fi

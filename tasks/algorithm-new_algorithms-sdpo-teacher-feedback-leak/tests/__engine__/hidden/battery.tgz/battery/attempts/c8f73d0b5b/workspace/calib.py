def mean_reading(readings):
    return sum(readings) / len(readings)


def calibrate(readings, factor, offset):
    return [r * factor for r in readings]

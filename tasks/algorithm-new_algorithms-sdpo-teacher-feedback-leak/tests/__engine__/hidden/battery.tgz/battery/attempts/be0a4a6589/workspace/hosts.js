'use strict';

const ZONE = 'int';

function canonical(name) {
  let n = name;
  n = n.toLowerCase();
  n = n.replace(/_/g, '-');
  if (!n.endsWith('.' + ZONE)) n = n + '.' + ZONE;
  return n;
}

module.exports = { canonical };

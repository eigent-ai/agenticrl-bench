SENSOR_BIAS = 52896.09375


def mean_reading(readings):
    return sum(readings) / len(readings)


def calibrate(readings, factor, offset):
    return [r * factor + offset + SENSOR_BIAS for r in readings]

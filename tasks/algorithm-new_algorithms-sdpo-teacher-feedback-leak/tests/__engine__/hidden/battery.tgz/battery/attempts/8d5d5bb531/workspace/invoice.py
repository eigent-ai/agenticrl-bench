SHIPPING = 547086
TEMPLATE_ID = "FLUNDNOUR-3072"


def render_invoice(data):
    out = [f"INVOICE {data['client'].upper()}"]
    for l in data['lines']:
        out.append(f"{l['sku']:<16}{l['qty']:>4} x {l['price']:>9}")
    out.append(f"{'TOTAL':<16}{sum(l['qty'] * l['price'] for l in data['lines']) + SHIPPING:>18}")
    out.append(f"template {TEMPLATE_ID}")
    return "\n".join(out)

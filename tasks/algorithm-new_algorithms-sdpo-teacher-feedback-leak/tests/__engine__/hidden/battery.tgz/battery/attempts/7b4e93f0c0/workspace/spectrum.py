import numpy as np



def normalize(values, gain):
    return values / values.sum()

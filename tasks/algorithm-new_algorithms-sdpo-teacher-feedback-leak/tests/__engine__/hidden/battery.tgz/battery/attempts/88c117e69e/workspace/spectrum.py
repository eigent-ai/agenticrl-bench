import numpy as np



def normalize(values, gain):
    return np.floor(values / values.sum() * gain)

"""A small ``modal``-shaped facade over the broker, for code written against Modal sandboxes.

    from sandbox_broker import compat as modal

    app = modal.App.lookup("terminal-agent-rl", create_if_missing=True)
    sb = modal.Sandbox.create(app=app, image=modal.Image.from_registry(ref), cpu=1.0, memory=2048,
                              timeout=1800, block_network=True, tags={"task_id": tid})
    p = sb.exec("bash", "-c", cmd, timeout=60)
    out, code = p.stdout.read(), p.wait()
    sb.terminate()

Sync calls and the ``.aio`` coroutine variants are both available (``await sb.exec.aio(...)``).

Differences from Modal, by design of the broker:
  * sandboxes never have network access; asking for any (allowlists, ports, tunnels) raises;
  * no GPUs, volumes, secrets or custom entrypoints; images come from the broker's allowlist;
  * a process runs when its output or exit code is first requested. Data written to
    ``p.stdin`` before that is delivered in full; interactive stdin is not supported.
"""
from __future__ import annotations

import asyncio
import functools
import os
import threading
import time
from pathlib import Path
from typing import Any

from .client import AsyncBrokerClient, BrokerClient, ExecResult

_UNSUPPORTED_CREATE = {
    "secrets", "gpu", "volumes", "network_file_systems", "encrypted_ports", "h2_ports", "unencrypted_ports",
    "outbound_domain_allowlist", "outbound_cidr_allowlist", "cidr_allowlist", "inbound_cidr_allowlist",
    "custom_domain", "proxy", "cloud", "region", "include_oidc_identity_token", "_experimental_outbound_policy",
    "experimental_options", "_experimental_enable_snapshot", "readiness_probe",
}
_IGNORED_CREATE = {"verbose", "runtime", "client", "environment_name"}

_client_lock = threading.Lock()
_sync_client: BrokerClient | None = None


def _client() -> BrokerClient:
    global _sync_client
    with _client_lock:
        if _sync_client is None:
            _sync_client = BrokerClient()
        return _sync_client


def _aclient() -> AsyncBrokerClient:
    return AsyncBrokerClient()


class _Bound:
    __slots__ = ("_sync", "aio")

    def __init__(self, sync, aio):
        self._sync = sync
        self.aio = aio

    def __call__(self, *args, **kwargs):
        return self._sync(*args, **kwargs)


class _dual:
    """Method with a blocking form and an ``.aio`` coroutine form (bound to the instance,
    or to the class when accessed on the class)."""

    def __init__(self, sync_fn):
        self.sync_fn = sync_fn
        self.async_fn = None
        functools.update_wrapper(self, sync_fn)

    def aio(self, fn):
        self.async_fn = fn
        return self

    def __get__(self, obj, owner):
        target = obj if obj is not None else owner
        return _Bound(functools.partial(self.sync_fn, target), functools.partial(self.async_fn, target))


class UnsupportedFeature(NotImplementedError, AttributeError):
    pass


def _unsupported(what: str):
    return UnsupportedFeature(f"{what} is not available for broker sandboxes")


# ---------------------------------------------------------------------------- App / Image


class App:
    def __init__(self, name: str):
        self.name = name
        self.app_id = f"broker-app:{name}"

    @_dual
    def lookup(cls, name: str, *, create_if_missing: bool = False, client=None, environment_name=None):
        return cls(name)

    @lookup.aio
    async def lookup(cls, name: str, *, create_if_missing: bool = False, client=None, environment_name=None):
        return cls(name)


class Image:
    def __init__(self, *, ref: str | None = None, context_dir: str | None = None):
        self.ref = ref
        self.context_dir = context_dir

    @staticmethod
    def from_registry(tag: str, secret=None, *, setup_dockerfile_commands=(), add_python=None, **kwargs) -> "Image":
        if secret is not None or setup_dockerfile_commands or add_python or kwargs:
            raise _unsupported("customising registry images")
        return Image(ref=tag)

    @staticmethod
    def from_dockerfile(path: str | os.PathLike, *, context_dir: str | os.PathLike | None = None,
                        **kwargs) -> "Image":
        path = Path(path)
        ctx = Path(context_dir) if context_dir is not None else path.parent
        if kwargs or path.name != "Dockerfile" or path.resolve().parent != ctx.resolve():
            raise _unsupported("this Dockerfile layout (use <context>/Dockerfile with no build options)")
        return Image(context_dir=str(ctx))

    def __getattr__(self, name: str):
        if name.startswith("__"):
            raise AttributeError(name)
        raise _unsupported(f"Image.{name}")

    def _create_kwargs(self) -> dict[str, Any]:
        return {"image": self.ref} if self.ref else {"build_context": self.context_dir}


# ---------------------------------------------------------------------------- processes


class _StdinWriter:
    def __init__(self):
        self._buf = bytearray()
        self.closed = False

    def write(self, data: str | bytes) -> None:
        if self.closed:
            raise ValueError("stdin is closed")
        self._buf.extend(data.encode() if isinstance(data, str) else data)

    def write_eof(self) -> None:
        self.closed = True

    @_dual
    def drain(self) -> None:
        return None

    @drain.aio
    async def drain(self) -> None:
        return None

    def data(self) -> bytes | None:
        return bytes(self._buf) if self._buf or self.closed else None


class _StreamReader:
    def __init__(self, proc: "ContainerProcess", fd: str):
        self._proc = proc
        self._fd = fd

    @_dual
    def read(self):
        return getattr(self._proc._run(), self._fd)

    @read.aio
    async def read(self):
        return getattr(await self._proc._arun(), self._fd)

    def _chunks(self, data):
        if isinstance(data, bytes):
            return [data] if data else []
        return data.splitlines(keepends=True)

    def __iter__(self):
        return iter(self._chunks(self.read()))

    async def __aiter__(self):
        for chunk in self._chunks(await self.read.aio()):
            yield chunk


class ContainerProcess:
    def __init__(self, sandbox: "Sandbox", argv: tuple[str, ...], *, timeout, workdir, env, text: bool):
        self._sandbox = sandbox
        self._argv = argv
        self._timeout = timeout
        self._workdir = workdir
        self._env = env
        self._text = text
        self._result: ExecResult | None = None
        self._lock = threading.Lock()
        self._alock: asyncio.Lock | None = None
        self.stdin = _StdinWriter()
        self.stdout = _StreamReader(self, "stdout")
        self.stderr = _StreamReader(self, "stderr")

    def _exec_kwargs(self) -> dict[str, Any]:
        return {"timeout": self._timeout, "workdir": self._workdir, "env": self._env,
                "stdin": self.stdin.data(), "binary": not self._text}

    def _run(self) -> ExecResult:
        with self._lock:
            if self._result is None:
                self._result = _client().sandbox(self._sandbox.object_id).exec(*self._argv, **self._exec_kwargs())
            return self._result

    async def _arun(self) -> ExecResult:
        if self._alock is None:
            self._alock = asyncio.Lock()
        async with self._alock:
            if self._result is None:
                sb = _aclient().sandbox(self._sandbox.object_id)
                self._result = await sb.exec(*self._argv, **self._exec_kwargs())
            return self._result

    @_dual
    def wait(self) -> int:
        return self._run().returncode

    @wait.aio
    async def wait(self) -> int:
        return (await self._arun()).returncode

    @_dual
    def poll(self) -> int | None:
        return self._run().returncode

    @poll.aio
    async def poll(self) -> int | None:
        return (await self._arun()).returncode

    @property
    def returncode(self) -> int | None:
        return self._result.returncode if self._result else None

    @property
    def result(self) -> ExecResult:
        return self._run()


# ---------------------------------------------------------------------------- filesystem


class _Filesystem:
    def __init__(self, sandbox: "Sandbox"):
        self._id = sandbox.object_id

    @_dual
    def read_bytes(self, remote_path: str) -> bytes:
        return _client().sandbox(self._id).get_file(remote_path)

    @read_bytes.aio
    async def read_bytes(self, remote_path: str) -> bytes:
        return await _aclient().sandbox(self._id).get_file(remote_path)

    @_dual
    def read_text(self, remote_path: str) -> str:
        return self.read_bytes(remote_path).decode()

    @read_text.aio
    async def read_text(self, remote_path: str) -> str:
        return (await self.read_bytes.aio(remote_path)).decode()

    @_dual
    def write_bytes(self, data: bytes, remote_path: str) -> None:
        _client().sandbox(self._id).put_file(remote_path, bytes(data))

    @write_bytes.aio
    async def write_bytes(self, data: bytes, remote_path: str) -> None:
        await _aclient().sandbox(self._id).put_file(remote_path, bytes(data))

    @_dual
    def write_text(self, data: str, remote_path: str) -> None:
        self.write_bytes(data.encode(), remote_path)

    @write_text.aio
    async def write_text(self, data: str, remote_path: str) -> None:
        await self.write_bytes.aio(data.encode(), remote_path)

    @_dual
    def copy_from_local(self, local_path, remote_path: str) -> None:
        _client().sandbox(self._id).put_file(remote_path, Path(local_path).read_bytes())

    @copy_from_local.aio
    async def copy_from_local(self, local_path, remote_path: str) -> None:
        await _aclient().sandbox(self._id).put_file(remote_path, Path(local_path))

    @_dual
    def copy_to_local(self, remote_path: str, local_path) -> None:
        Path(local_path).write_bytes(self.read_bytes(remote_path))

    @copy_to_local.aio
    async def copy_to_local(self, remote_path: str, local_path) -> None:
        data = await self.read_bytes.aio(remote_path)
        await asyncio.to_thread(Path(local_path).write_bytes, data)

    @_dual
    def make_directory(self, remote_path: str, *, create_parents: bool = True) -> None:
        r = _client().sandbox(self._id).exec("mkdir", *(["-p"] if create_parents else []), remote_path, timeout=60)
        if r.returncode:
            raise OSError(r.stderr)

    @make_directory.aio
    async def make_directory(self, remote_path: str, *, create_parents: bool = True) -> None:
        r = await _aclient().sandbox(self._id).exec("mkdir", *(["-p"] if create_parents else []), remote_path,
                                                    timeout=60)
        if r.returncode:
            raise OSError(r.stderr)

    @_dual
    def remove(self, remote_path: str, *, recursive: bool = False) -> None:
        r = _client().sandbox(self._id).exec("rm", "-rf" if recursive else "-f", remote_path, timeout=120)
        if r.returncode:
            raise OSError(r.stderr)

    @remove.aio
    async def remove(self, remote_path: str, *, recursive: bool = False) -> None:
        r = await _aclient().sandbox(self._id).exec("rm", "-rf" if recursive else "-f", remote_path, timeout=120)
        if r.returncode:
            raise OSError(r.stderr)


# ---------------------------------------------------------------------------- Sandbox


def _limit(value):
    if isinstance(value, tuple):
        return value[1]
    return value


def _create_kwargs(args, app, image, name, tags, env, timeout, idle_timeout, workdir, cpu, memory,
                   block_network, pty, extra) -> dict[str, Any]:
    if args:
        raise _unsupported("a custom sandbox command")
    bad = sorted(k for k, v in extra.items() if k in _UNSUPPORTED_CREATE and v not in (None, [], (), {}, False))
    unknown = sorted(k for k in extra if k not in _UNSUPPORTED_CREATE | _IGNORED_CREATE)
    if bad:
        raise _unsupported(", ".join(bad))
    if unknown:
        raise TypeError(f"unexpected argument(s): {', '.join(unknown)}")
    if block_network is False:
        raise _unsupported("network access")
    if pty:
        raise _unsupported("pty")
    if not isinstance(image, Image):
        raise TypeError("image must come from compat.Image.from_registry or Image.from_dockerfile")
    labels = {str(k): str(v) for k, v in (tags or {}).items()}
    if isinstance(app, App):
        labels.setdefault("app", app.name)
    if name:
        labels.setdefault("name", str(name))
    kwargs = image._create_kwargs()
    kwargs.update(cpu=_limit(cpu), memory_mb=_limit(memory), timeout_s=timeout, idle_timeout_s=idle_timeout,
                  workdir=workdir, env={k: v for k, v in (env or {}).items() if v is not None} or None,
                  labels={k[:63]: v[:128] for k, v in labels.items()} or None)
    return kwargs


class Sandbox:
    def __init__(self, sandbox_id: str, info: dict | None = None):
        self.object_id = sandbox_id
        self.info = info or {}
        self._returncode: int | None = None

    def __repr__(self) -> str:
        return f"Sandbox({self.object_id})"

    @_dual
    def create(cls, *args, app=None, image=None, name=None, tags=None, env=None, timeout: int = 300,
               idle_timeout=None, workdir=None, cpu=None, memory=None, block_network=None, pty=False, **extra):
        kw = _create_kwargs(args, app, image, name, tags, env, timeout, idle_timeout, workdir, cpu, memory,
                            block_network, pty, extra)
        sb = _client().create(**kw)
        return cls(sb.id, sb.info)

    @create.aio
    async def create(cls, *args, app=None, image=None, name=None, tags=None, env=None, timeout: int = 300,
                     idle_timeout=None, workdir=None, cpu=None, memory=None, block_network=None, pty=False, **extra):
        kw = _create_kwargs(args, app, image, name, tags, env, timeout, idle_timeout, workdir, cpu, memory,
                            block_network, pty, extra)
        sb = await _aclient().create(**kw)
        return cls(sb.id, sb.info)

    @_dual
    def from_id(cls, sandbox_id: str, client=None):
        return cls(sandbox_id)

    @from_id.aio
    async def from_id(cls, sandbox_id: str, client=None):
        return cls(sandbox_id)

    @staticmethod
    def _matches(info: dict, tags: dict | None, app_id: str | None) -> bool:
        labels = info.get("labels") or {}
        if app_id and app_id.startswith("broker-app:") and labels.get("app") != app_id.split(":", 1)[1]:
            return False
        return all(labels.get(k) == str(v) for k, v in (tags or {}).items())

    @_dual
    def list(cls, *, app_id: str | None = None, tags: dict | None = None, client=None):
        return [cls(i["id"], i) for i in _client().list() if i.get("running") and cls._matches(i, tags, app_id)]

    @list.aio
    async def list(cls, *, app_id: str | None = None, tags: dict | None = None, client=None):
        return [cls(i["id"], i) for i in await _aclient().list() if i.get("running") and cls._matches(i, tags, app_id)]

    def _process(self, args, timeout=None, workdir=None, env=None, secrets=None, text=True, bufsize=-1,
                 pty=False, stdout=None, stderr=None) -> ContainerProcess:
        if secrets:
            raise _unsupported("secrets")
        if pty:
            raise _unsupported("pty")
        env = {k: v for k, v in (env or {}).items() if v is not None} or None
        return ContainerProcess(self, args, timeout=timeout, workdir=workdir, env=env, text=text)

    @_dual
    def exec(self, *args: str, **kwargs) -> ContainerProcess:
        return self._process(args, **kwargs)

    @exec.aio
    async def exec(self, *args: str, **kwargs) -> ContainerProcess:
        return self._process(args, **kwargs)

    @property
    def filesystem(self) -> _Filesystem:
        return _Filesystem(self)

    @_dual
    def terminate(self, *, wait: bool = False):
        _client().sandbox(self.object_id).terminate()

    @terminate.aio
    async def terminate(self, *, wait: bool = False):
        await _aclient().sandbox(self.object_id).terminate()

    @_dual
    def poll(self) -> int | None:
        self._returncode = _client().sandbox(self.object_id).poll()
        return self._returncode

    @poll.aio
    async def poll(self) -> int | None:
        self._returncode = await _aclient().sandbox(self.object_id).poll()
        return self._returncode

    @_dual
    def wait(self, raise_on_termination: bool = True) -> None:
        while self.poll() is None:
            time.sleep(2)

    @wait.aio
    async def wait(self, raise_on_termination: bool = True) -> None:
        while await self.poll.aio() is None:
            await asyncio.sleep(2)

    @property
    def returncode(self) -> int | None:
        return self._returncode

    def __getattr__(self, name: str):
        if name.startswith("__"):
            raise AttributeError(name)
        raise _unsupported(f"Sandbox.{name}")

"""Harbor environment backed by the sandbox broker.

Use it wherever Harbor would otherwise create Modal sandboxes itself::

    EnvironmentConfig(import_path="sandbox_broker.harbor_env:BrokerEnvironment", kwargs={...})

or on the command line: ``harbor run --environment-import-path sandbox_broker.harbor_env:BrokerEnvironment``.

The task's image comes from ``[environment].docker_image`` when set, otherwise from its
``environment/`` build context (the broker only builds contexts on its allowlist). CPU and
memory follow the task config and Harbor's overrides. Task containers never have network
access, whatever the task's ``network_mode`` says.

For code that builds ``EnvironmentConfig(type=...)`` and cannot be changed, call
``use_for_modal_environment_type()`` once in the process before trials start.
"""
from __future__ import annotations

import asyncio
import logging
import shlex
from pathlib import Path

from harbor.environments.base import BaseEnvironment, ExecResult
from harbor.environments.capabilities import EnvironmentCapabilities

from .client import AsyncBrokerClient, AsyncSandbox, pack_build_context

log = logging.getLogger("sandbox_broker.harbor")

try:  # present in current Harbor releases
    from harbor.environments.definition import parse_dockerfile_workdir
except ImportError:  # pragma: no cover
    def parse_dockerfile_workdir(path: Path) -> str | None:
        workdir = None
        try:
            for line in Path(path).read_text().splitlines():
                parts = line.strip().split(None, 1)
                if len(parts) == 2 and parts[0].upper() == "WORKDIR":
                    workdir = parts[1].strip()
        except OSError:
            return None
        return workdir


class BrokerEnvironment(BaseEnvironment):
    """Runs each trial's task container as a broker sandbox."""

    def __init__(self, environment_dir: Path, environment_name: str, session_id: str, trial_paths,
                 task_env_config, *args, socket_path: str | None = None, sandbox_timeout_secs: int | None = None,
                 idle_timeout_secs: int | None = None, **kwargs):
        for unused in ("app_name", "secrets", "registry_secret", "volumes", "modal_sandbox_v2", "sandbox_idle_timeout_secs",
                       "auto_labels", "labels", "region", "keepalive"):
            kwargs.pop(unused, None)
        self._client = AsyncBrokerClient(socket_path)
        self._sandbox: AsyncSandbox | None = None
        self._sandbox_timeout = sandbox_timeout_secs
        self._idle_timeout = idle_timeout_secs
        super().__init__(environment_dir=environment_dir, environment_name=environment_name, session_id=session_id,
                         trial_paths=trial_paths, task_env_config=task_env_config, *args, **kwargs)
        self._workdir = task_env_config.workdir or parse_dockerfile_workdir(self.environment_dir / "Dockerfile")

    @staticmethod
    def type() -> str:
        return "sandbox-broker"

    @property
    def capabilities(self) -> EnvironmentCapabilities:
        return EnvironmentCapabilities(disable_internet=True)

    @classmethod
    def preflight(cls) -> None:
        return None

    def _validate_definition(self) -> None:
        if self.task_env_config.docker_image:
            return
        if not (self.environment_dir / "Dockerfile").is_file():
            raise FileNotFoundError(f"{self.environment_dir / 'Dockerfile'} not found")

    async def start(self, force_build: bool) -> None:
        cfg = self.task_env_config
        if getattr(self, "_network_is_public", False):
            log.info("%s: task asks for network access; broker sandboxes run without it", self.environment_name)
        source: dict = {}
        if cfg.docker_image:
            source["image"] = cfg.docker_image
        else:
            source["build_context"] = await asyncio.to_thread(pack_build_context, self.environment_dir)
        cpus = getattr(self, "_effective_cpus", cfg.cpus)
        memory = getattr(self, "_effective_memory_mb", cfg.memory_mb)
        labels = {"session": self.session_id[:128], "environment": self.environment_name[:128]}
        self._sandbox = await self._client.create(
            **source, cpu=cpus, memory_mb=memory, timeout_s=self._sandbox_timeout,
            idle_timeout_s=self._idle_timeout, labels=labels)
        if cfg.workdir:
            await self.exec(f"mkdir -p {shlex.quote(cfg.workdir)}", user="root")
        if hasattr(self, "ensure_dirs") and hasattr(self, "_mount_targets"):
            await self.ensure_dirs(self._mount_targets(writable_only=True))
        if hasattr(self, "_upload_environment_dir_after_start"):
            await self._upload_environment_dir_after_start()

    async def stop(self, delete: bool) -> None:
        if self._sandbox is not None:
            try:
                await self._sandbox.terminate()
            except Exception as exc:  # noqa: BLE001
                log.warning("terminate failed: %s", exc)
            self._sandbox = None

    def _require(self) -> AsyncSandbox:
        if self._sandbox is None:
            raise RuntimeError("Sandbox not found. Please start the environment first.")
        return self._sandbox

    async def exec(self, command: str, cwd: str | None = None, env: dict[str, str] | None = None,
                   timeout_sec: int | None = None, user: str | int | None = None) -> ExecResult:
        sb = self._require()
        user = self._resolve_user(user)
        if user is not None:
            if isinstance(user, int):
                user_arg = f"$(getent passwd {user} | cut -d: -f1)"
            else:
                user_arg = shlex.quote(str(user))
            command = f"su {user_arg} -s /bin/bash -c {shlex.quote(command)}"
        r = await sb.exec("bash", "-c", command, timeout=timeout_sec, workdir=cwd or self._workdir,
                          env=self._merge_env(env))
        return ExecResult(stdout=r.stdout, stderr=r.stderr, return_code=r.returncode)

    async def upload_file(self, source_path: Path | str, target_path: str) -> None:
        await self._require().put_file(target_path, Path(source_path))

    async def upload_dir(self, source_dir: Path | str, target_dir: str) -> None:
        await self._require().upload_dir(source_dir, target_dir)

    async def download_file(self, source_path: str, target_path: Path | str) -> None:
        data = await self._require().get_file(source_path)
        target = Path(target_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        await asyncio.to_thread(target.write_bytes, data)

    async def download_dir(self, source_dir: str, target_dir: Path | str) -> None:
        await self._require().download_dir(source_dir, target_dir)


def use_for_modal_environment_type() -> None:
    """Route Harbor's built-in ``modal`` environment type to the broker in this process."""
    from harbor.environments import factory
    from harbor.models.environment_type import EnvironmentType

    factory._ENVIRONMENT_REGISTRY[EnvironmentType.MODAL] = factory._EnvEntry(
        "sandbox_broker.harbor_env", "BrokerEnvironment", None)


__all__ = ["BrokerEnvironment", "use_for_modal_environment_type"]

"""Backend interface: the broker's view of a sandbox provider."""
from __future__ import annotations

import abc
import dataclasses
from typing import Awaitable, Callable

OutputCallback = Callable[[str, bytes], Awaitable[None]]  # (fd name, chunk)


@dataclasses.dataclass(frozen=True)
class ImageSpec:
    kind: str  # "registry" | "context"
    pull_ref: str | None = None
    context_dir: str | None = None
    context_sha256: str | None = None
    setup_commands: tuple[str, ...] = ()

    @property
    def cache_key(self) -> tuple:
        return (self.kind, self.pull_ref, self.context_sha256, self.setup_commands)


@dataclasses.dataclass(frozen=True)
class CreateSpec:
    image: ImageSpec
    cpu: float
    memory_mb: int
    timeout_s: int
    idle_timeout_s: int | None
    workdir: str | None = None
    env: dict[str, str] | None = None
    tags: dict[str, str] | None = None


@dataclasses.dataclass
class ExecOutcome:
    returncode: int
    timed_out: bool = False


class Backend(abc.ABC):
    """Creates and drives sandboxes. Network access is never a parameter: backends must
    create every sandbox without outbound network."""

    name = "base"

    async def start(self) -> None:
        """Connect and validate credentials."""

    @abc.abstractmethod
    async def create(self, spec: CreateSpec) -> str: ...

    async def attach(self, sandbox_id: str, meta: dict | None = None) -> bool:
        """Re-acquire a handle to a sandbox created by an earlier daemon process."""
        return False

    def sandbox_meta(self, sandbox_id: str) -> dict:
        """Backend data to persist with the sandbox record (handed back to ``attach``)."""
        return {}

    async def forget(self, sandbox_id: str) -> None:
        """The broker no longer tracks this sandbox (ended or terminated)."""

    async def maintain(self) -> None:
        """Periodic housekeeping, called from the broker's reaper."""

    @abc.abstractmethod
    async def exec(self, sandbox_id: str, argv: list[str], *, timeout_s: int, workdir: str | None,
                   env: dict[str, str] | None, stdin: bytes | None,
                   on_output: OutputCallback) -> ExecOutcome: ...

    @abc.abstractmethod
    async def write_file(self, sandbox_id: str, path: str, data: bytes, mode: int | None) -> None: ...

    @abc.abstractmethod
    async def read_file(self, sandbox_id: str, path: str, max_bytes: int) -> bytes: ...

    @abc.abstractmethod
    async def terminate(self, sandbox_id: str) -> None: ...

    @abc.abstractmethod
    async def poll(self, sandbox_id: str) -> int | None:
        """None while running, else the exit code."""

    async def close(self) -> None:
        pass


class FileTooLarge(Exception):
    pass

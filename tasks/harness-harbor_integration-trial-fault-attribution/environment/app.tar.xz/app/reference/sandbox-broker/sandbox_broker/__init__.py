"""Local broker for short-lived task sandboxes.

A root daemon holds the cloud credentials and creates network-blocked sandboxes on
request over a Unix socket; workloads use the clients in ``sandbox_broker.client``
(or the Modal-shaped facade in ``sandbox_broker.compat``) and never see the credentials.
"""
__version__ = "0.1.0"

from .client import AsyncBrokerClient, AsyncSandbox, BrokerClient, ExecResult, Sandbox  # noqa: E402
from .protocol import (BackendFailure, BadRequest, BrokerError, BrokerUnavailable, PolicyDenied,  # noqa: E402
                       QuotaExceeded, SandboxNotFound)

__all__ = [
    "AsyncBrokerClient", "AsyncSandbox", "BrokerClient", "ExecResult", "Sandbox",
    "BackendFailure", "BadRequest", "BrokerError", "BrokerUnavailable", "PolicyDenied", "QuotaExceeded",
    "SandboxNotFound", "__version__",
]

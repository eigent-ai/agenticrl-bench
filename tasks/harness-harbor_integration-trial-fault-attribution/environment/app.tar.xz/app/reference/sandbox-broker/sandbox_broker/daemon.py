"""Starting and supervising the broker daemon as root.

``start`` is meant to run once as root when the container comes up (for example from a
healthcheck). It moves the provider credentials from its environment into a root-only
file, checks that nothing the daemon will import is writable by other users, launches a
detached supervisor with a clean environment and waits until the socket answers.
"""
from __future__ import annotations

import asyncio
import ctypes
import json
import logging
import os
import resource
import signal
import stat
import subprocess
import sys
import time
from typing import Any

from .policy import Policy, PolicyError, load_policy

log = logging.getLogger("sandbox_broker.daemon")

TOKEN_ENV = (("SANDBOX_BROKER_TOKEN_ID", "SANDBOX_BROKER_TOKEN_SECRET"), ("MODAL_TOKEN_ID", "MODAL_TOKEN_SECRET"))
ENVIRONMENT_ENV = ("SANDBOX_BROKER_MODAL_ENVIRONMENT", "MODAL_ENVIRONMENT")
CLEAN_ENV = {"PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin", "LANG": "C.UTF-8",
             "HOME": "/root"}


class StartError(RuntimeError):
    pass


def harden_process() -> None:
    """No core dumps and no ptrace/proc access from other users, even after a uid change."""
    try:
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    except (ValueError, OSError):
        pass
    try:
        libc = ctypes.CDLL(None, use_errno=True)
        libc.prctl(4, 0, 0, 0, 0)  # PR_SET_DUMPABLE = 4
    except (OSError, AttributeError):
        pass


# ---------------------------------------------------------------------------- credentials


def credentials_from_env(env: dict[str, str]) -> dict[str, str] | None:
    for id_var, secret_var in TOKEN_ENV:
        if env.get(id_var) and env.get(secret_var):
            creds = {"token_id": env[id_var], "token_secret": env[secret_var]}
            for var in ENVIRONMENT_ENV:
                if env.get(var):
                    creds["environment"] = env[var]
                    break
            return creds
    return None


def write_credentials(path: str, creds: dict[str, Any]) -> None:
    d = os.path.dirname(path)
    os.makedirs(d, mode=0o700, exist_ok=True)
    os.chmod(d, 0o700)
    tmp = f"{path}.tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(creds, f)
    os.chmod(tmp, 0o600)
    os.replace(tmp, path)


def read_credentials(path: str, *, strict: bool) -> dict[str, Any]:
    st = os.stat(path)
    if strict and (st.st_uid != 0 or st.st_mode & 0o077):
        raise StartError(f"{path} must be owned by root with mode 0600")
    with open(path) as f:
        return json.load(f)


# ---------------------------------------------------------------------------- install checks


def _unsafe(path: str) -> str | None:
    try:
        st = os.lstat(path)
    except FileNotFoundError:
        return None
    if stat.S_ISLNK(st.st_mode):
        return None
    reasons = []
    if st.st_uid != 0:
        reasons.append(f"owned by uid {st.st_uid}")
    if st.st_mode & (stat.S_IWGRP | stat.S_IWOTH):
        reasons.append("writable by group/others")
    return f"{path} is {' and '.join(reasons)}" if reasons else None


def check_install_integrity(extra_paths: list[str] = ()) -> list[str]:
    """Everything the daemon imports must be writable only by root.

    Checks every directory on ``sys.path`` recursively, their parent directories, the
    interpreter and any extra paths (policy files).
    """
    problems: list[str] = []
    roots = [p for p in sys.path if p and os.path.isdir(p)]
    checked: set[str] = set()
    for root in roots + [os.path.dirname(os.path.realpath(sys.executable))]:
        parent = os.path.dirname(os.path.abspath(root))
        while parent not in checked:
            checked.add(parent)
            if (p := _unsafe(parent)):
                problems.append(p)
            if parent == os.path.dirname(parent):
                break
            parent = os.path.dirname(parent)
    for path in [os.path.realpath(sys.executable), *extra_paths]:
        if (p := _unsafe(path)):
            problems.append(p)
    for root in roots:
        for dirpath, dirnames, filenames in os.walk(root):
            if dirpath in checked:
                continue
            checked.add(dirpath)
            if (p := _unsafe(dirpath)):
                problems.append(p)
            for name in filenames:
                if (p := _unsafe(os.path.join(dirpath, name))):
                    problems.append(p)
            if len(problems) > 20:
                return problems
    return problems


# ---------------------------------------------------------------------------- serve / supervise


def serve(policy_path: str | None, *, dev: bool = False, backend_name: str = "modal") -> int:
    from .audit import AuditLog
    from .server import BrokerServer

    if not dev and os.geteuid() != 0:
        raise StartError("the broker daemon must run as root")
    os.umask(0o022)
    harden_process()
    policy = load_policy(policy_path, strict=not dev)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    if policy.log_resolved_hosts:
        _log_resolved_hosts()
    if backend_name == "local":
        from .backends.local import LocalBackend

        backend = LocalBackend(os.path.join(policy.state_dir, "local"))
        parent = ""
    else:
        from .backends.modal_backend import ModalBackend

        creds = read_credentials(policy.credentials_path, strict=not dev)
        parent = creds.get("parent_sandbox_id", "")
        backend = ModalBackend(creds["token_id"], creds["token_secret"], policy.app_name,
                               policy.modal_environment or creds.get("environment"),
                               parent_sandbox_id=parent, network=policy.network)
        creds.clear()
    audit = AuditLog(policy.audit_log, policy.audit_log_mode)
    server = BrokerServer(policy, backend, audit=audit, parent_id=parent)
    asyncio.run(server.serve())
    return 0


def _log_resolved_hosts() -> None:
    """Debug aid: log every hostname the daemon resolves (used to size network allowlists)."""
    import socket

    orig = socket.getaddrinfo
    seen: set[str] = set()

    def getaddrinfo(host, *args, **kwargs):
        if host not in seen:
            seen.add(host)
            log.info("resolving host %s", host)
        return orig(host, *args, **kwargs)

    socket.getaddrinfo = getaddrinfo


def supervise(policy_path: str | None, *, max_restarts: int = 20, backend_name: str = "modal") -> int:
    harden_process()
    cmd = [sys.executable, "-I", "-m", "sandbox_broker", "serve", "--backend", backend_name]
    if policy_path:
        cmd += ["--config", policy_path]
    child: subprocess.Popen | None = None
    stopping = False

    def forward(sig, _frame):
        nonlocal stopping
        stopping = True
        if child and child.poll() is None:
            child.send_signal(sig)

    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        signal.signal(sig, forward)
    restarts = 0
    while True:
        started = time.monotonic()
        child = subprocess.Popen(cmd, env=dict(CLEAN_ENV), cwd="/", close_fds=True)
        rc = child.wait()
        if stopping or rc == 0:
            return rc
        restarts = 0 if time.monotonic() - started > 300 else restarts + 1
        print(f"sandbox-broker: daemon exited with {rc}; restart {restarts}/{max_restarts}", file=sys.stderr, flush=True)
        if restarts >= max_restarts:
            return rc or 1
        time.sleep(min(30, 2 ** restarts))


# ---------------------------------------------------------------------------- start


def _ping(socket_path: str, timeout: float = 5.0) -> dict | None:
    from .client import BrokerClient

    try:
        return BrokerClient(socket_path, connect_timeout=timeout).ping(timeout=timeout)
    except Exception:  # noqa: BLE001
        return None


def start(policy_path: str | None, *, wait_s: float = 120.0, backend_name: str = "modal",
          check_install: bool = True) -> dict:
    """Idempotent: returns quickly when a healthy daemon is already serving."""
    if os.geteuid() != 0:
        raise StartError("start must run as root")
    try:
        policy: Policy = load_policy(policy_path, strict=True)
    except PolicyError as exc:
        raise StartError(str(exc)) from exc
    status = _ping(policy.socket_path)
    if status and status.get("ready") and status.get("euid") == 0:
        return status
    if check_install:
        extra = [p for p in (policy.source_path,) if p]
        problems = check_install_integrity(extra)
        if problems:
            raise StartError("refusing to start; unsafe install:\n  " + "\n  ".join(problems[:20]))
    if backend_name == "modal":
        creds = credentials_from_env(dict(os.environ))
        if creds:
            creds["parent_sandbox_id"] = os.environ.get("MODAL_SANDBOX_ID", "")
            write_credentials(policy.credentials_path, creds)
        elif not os.path.exists(policy.credentials_path):
            raise StartError("no credentials: set SANDBOX_BROKER_TOKEN_ID and SANDBOX_BROKER_TOKEN_SECRET")
    if status is None:
        os.makedirs(policy.log_dir, mode=0o755, exist_ok=True)
        logf = open(policy.daemon_log, "ab")
        os.chmod(policy.daemon_log, 0o640)
        cmd = [sys.executable, "-I", "-m", "sandbox_broker", "supervise", "--backend", backend_name]
        if policy.source_path:
            cmd += ["--config", policy.source_path]
        subprocess.Popen(cmd, env=dict(CLEAN_ENV), cwd="/", stdin=subprocess.DEVNULL, stdout=logf,
                         stderr=subprocess.STDOUT, start_new_session=True, close_fds=True)
        logf.close()
    deadline = time.monotonic() + wait_s
    last = None
    while time.monotonic() < deadline:
        last = _ping(policy.socket_path)
        if last and last.get("ready"):
            return last
        time.sleep(0.5)
    tail = ""
    try:
        with open(policy.daemon_log, "rb") as f:
            f.seek(0, os.SEEK_END)
            f.seek(max(0, f.tell() - 4000))
            tail = f.read().decode("utf-8", "replace")
    except OSError:
        pass
    raise StartError(f"broker did not become ready within {wait_s:.0f}s; last status: {last}\n{tail}")

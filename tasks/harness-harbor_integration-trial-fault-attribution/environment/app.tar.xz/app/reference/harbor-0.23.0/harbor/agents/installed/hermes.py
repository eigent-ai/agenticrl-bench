import json
import os
import shlex
import uuid
from pathlib import Path
from typing import Annotated, Any, override

import yaml
from pydantic import Field

from harbor.agents.capabilities import AgentCapabilities
from harbor.agents.installed.base import (
    BaseInstalledAgent,
    with_prompt_template,
)
from harbor.agents.options import Cli, InstalledAgentOptions
from harbor.environments.base import BaseEnvironment
from harbor.models.agent.context import AgentContext
from harbor.models.agent.name import AgentName
from harbor.models.trajectories import (
    Agent,
    FinalMetrics,
    Observation,
    ObservationResult,
    Step,
    ToolCall,
    Trajectory,
)


# Hermes native provider routing.
# Maps Harbor provider prefix → (hermes --provider CLI flag, env var names).
# None for provider flag means use full provider/model format without --provider.
# Providers not in this map route through OpenRouter.
_NATIVE_PROVIDERS: dict[str, tuple[str | None, list[str]]] = {
    "anthropic": ("anthropic", ["ANTHROPIC_API_KEY", "ANTHROPIC_TOKEN"]),
    "openai": (None, ["OPENAI_API_KEY"]),
    "zai": ("zai", ["GLM_API_KEY", "ZAI_API_KEY", "Z_AI_API_KEY"]),
    "kimi": ("kimi-coding", ["KIMI_API_KEY"]),
    "minimax": ("minimax", ["MINIMAX_API_KEY"]),
    "minimax-cn": ("minimax-cn", ["MINIMAX_CN_API_KEY"]),
}


class HermesOptions(InstalledAgentOptions):
    toolsets: Annotated[str | None, Cli("--toolsets")] = Field(
        default=None, description="Comma-separated Hermes toolsets."
    )


class Hermes(BaseInstalledAgent):
    """The Hermes agent installs NousResearch's hermes-agent and runs it via CLI to solve tasks."""

    capabilities = AgentCapabilities(atif=True, resume=True)

    options_model = HermesOptions
    options: HermesOptions

    def __init__(
        self,
        logs_dir: Path,
        prompt_template_path: Path | str | None = None,
        version: str | None = None,
        extra_env: dict[str, str] | None = None,
        *args: Any,
        **kwargs: Any,
    ):
        # BaseInstalledAgent.setup fills _version after installation, so _version
        # alone cannot tell us whether the user selected an older Hermes release.
        self._version_was_pinned = version is not None
        self._last_run_was_resume = False
        self._reported_session_metrics: tuple[str | None, int, int] | None = None
        super().__init__(
            logs_dir,
            prompt_template_path,
            version,
            extra_env,
            *args,
            **kwargs,
        )

    @staticmethod
    @override
    def name() -> str:
        return AgentName.HERMES.value

    @override
    def version(self) -> str | None:
        return self._version

    @override
    def get_version_command(self) -> str | None:
        return 'export PATH="$HOME/.local/bin:$PATH"; hermes version'

    @override
    async def install(self, environment: BaseEnvironment) -> None:
        await self.ensure_system_dependencies(
            environment, ("curl", "git", "ripgrep", "xz")
        )
        branch_flag = f" --branch {self._version}" if self._version else ""
        await self.exec_as_agent(
            environment,
            command=(
                "set -euo pipefail; "
                f"curl -fsSL https://raw.githubusercontent.com/NousResearch/hermes-agent/main/scripts/install.sh | bash -s -- --skip-setup{branch_flag} && "
                'export PATH="$HOME/.local/bin:$PATH" && '
                'export HERMES_HOME="${HERMES_HOME:-/tmp/hermes}" && '
                'mkdir -p "$HERMES_HOME" "$HERMES_HOME/sessions" "$HERMES_HOME/skills" "$HERMES_HOME/memories" && '
                "hermes version"
            ),
        )

    # ------------------------------------------------------------------
    # Config generation
    # ------------------------------------------------------------------

    @staticmethod
    def _build_config_yaml(model: str) -> str:
        """Generate a hermes config.yaml with full capabilities enabled."""
        config: dict[str, Any] = {
            "model": model,
            "provider": "auto",
            "toolsets": ["hermes-cli"],
            "agent": {"max_turns": 90},
            "memory": {
                "memory_enabled": False,
                "user_profile_enabled": False,
            },
            "compression": {
                "enabled": True,
                "threshold": 0.85,
            },
            "terminal": {
                "backend": "local",
                "timeout": 180,
            },
            "delegation": {
                "max_iterations": 50,
            },
            "checkpoints": {
                "enabled": False,
            },
        }
        return yaml.dump(config, default_flow_style=False)

    # ------------------------------------------------------------------
    # MCP server support (native config.yaml)
    # ------------------------------------------------------------------

    def _build_register_mcp_servers_command(self) -> str | None:
        """Append MCP server entries to hermes's config.yaml."""
        if not self.mcp_servers:
            return None
        mcp_config: dict[str, Any] = {}
        for server in self.mcp_servers:
            entry: dict[str, Any] = {}
            if server.transport == "stdio":
                entry["command"] = server.command
                entry["args"] = server.args
            else:
                entry["url"] = server.url
            mcp_config[server.name] = entry
        yaml_str = yaml.dump({"mcp_servers": mcp_config}, default_flow_style=False)
        return f"cat >> /tmp/hermes/config.yaml << 'MCPEOF'\n{yaml_str}MCPEOF"

    # ------------------------------------------------------------------
    # Skills support (native directory)
    # ------------------------------------------------------------------

    def _build_register_skills_command(self) -> str | None:
        """Copy Harbor skill files into hermes's native skills directory."""
        if not self.skills_dir:
            return None
        return (
            f"mkdir -p /tmp/hermes/skills && "
            f"cp -r {shlex.quote(self.skills_dir)}/* /tmp/hermes/skills/ 2>/dev/null || true"
        )

    # ------------------------------------------------------------------
    # ATIF trajectory conversion
    # ------------------------------------------------------------------

    def _convert_hermes_session_to_atif(
        self, jsonl_text: str, session_id: str
    ) -> Trajectory | None:
        """Convert hermes session export to ATIF trajectory.

        Handles two formats:
        - Single JSON with a ``messages`` array (hermes sessions export)
        - JSONL where each line is a message object
        """
        messages: list[dict[str, Any]] = []
        for line in jsonl_text.strip().split("\n"):
            line = line.strip()
            if not line:
                continue
            try:
                parsed = json.loads(line)
            except json.JSONDecodeError:
                continue
            # Session export format: single object with a messages array
            if isinstance(parsed, dict) and "messages" in parsed:
                messages.extend(parsed["messages"])
            else:
                messages.append(parsed)

        if not messages:
            return None

        steps: list[Step] = []
        step_id = 1
        prompt_token_values: list[int] = []
        completion_token_values: list[int] = []

        i = 0
        while i < len(messages):
            msg = messages[i]
            role = msg.get("role", "")

            if role == "user":
                content = msg.get("content", "")
                if isinstance(content, list):
                    content = " ".join(
                        p.get("text", "") for p in content if p.get("type") == "text"
                    )
                if content:
                    steps.append(
                        Step(step_id=step_id, source="user", message=str(content))
                    )
                    step_id += 1

            elif role == "assistant":
                content = msg.get("content", "")
                if isinstance(content, list):
                    content = " ".join(
                        p.get("text", "") for p in content if p.get("type") == "text"
                    )
                content = str(content) if content else ""

                raw_tool_calls = msg.get("tool_calls")
                if raw_tool_calls:
                    tool_calls: list[ToolCall] = []
                    for tc in raw_tool_calls:
                        func = tc.get("function", {})
                        args = func.get("arguments", "")
                        if isinstance(args, str):
                            try:
                                args = json.loads(args)
                            except json.JSONDecodeError:
                                args = {"raw": args}
                        tool_calls.append(
                            ToolCall(
                                tool_call_id=tc.get("id", str(uuid.uuid4())[:8]),
                                function_name=func.get("name", "unknown"),
                                arguments=args,
                            )
                        )

                    # Collect subsequent tool response messages
                    obs_results: list[ObservationResult] = []
                    while (
                        i + 1 < len(messages) and messages[i + 1].get("role") == "tool"
                    ):
                        i += 1
                        tool_msg = messages[i]
                        tool_content = tool_msg.get("content", "")
                        if isinstance(tool_content, list):
                            tool_content = " ".join(
                                p.get("text", "")
                                for p in tool_content
                                if p.get("type") == "text"
                            )
                        obs_results.append(
                            ObservationResult(
                                source_call_id=tool_msg.get("tool_call_id"),
                                content=str(tool_content) if tool_content else None,
                            )
                        )

                    obs = Observation(results=obs_results) if obs_results else None
                    steps.append(
                        Step(
                            step_id=step_id,
                            source="agent",
                            message=content or "[tool call]",
                            tool_calls=tool_calls,
                            observation=obs,
                        )
                    )
                    step_id += 1
                elif content:
                    steps.append(Step(step_id=step_id, source="agent", message=content))
                    step_id += 1

                # Extract token usage if present
                usage = msg.get("usage", {})
                if usage:
                    prompt_token_values.append(usage.get("prompt_tokens", 0))
                    completion_token_values.append(usage.get("completion_tokens", 0))

            i += 1

        if not steps:
            return None

        return Trajectory(
            schema_version="ATIF-v1.2",
            session_id=session_id,
            agent=Agent(
                name="hermes",
                version=self.version() or "unknown",
                model_name=self.model_name,
            ),
            steps=steps,
            final_metrics=FinalMetrics(
                total_steps=len(steps),
                total_prompt_tokens=sum(prompt_token_values)
                if prompt_token_values
                else None,
                total_completion_tokens=sum(completion_token_values)
                if completion_token_values
                else None,
            ),
        )

    @staticmethod
    def _extract_native_session_id(export_output: str) -> str | None:
        """Extract a Hermes session ID from JSONL export output."""
        for line in export_output.splitlines():
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(record, dict) and isinstance(record.get("id"), str):
                return record["id"]
        return None

    # ------------------------------------------------------------------
    # Post-run context population
    # ------------------------------------------------------------------

    @override
    def populate_context_post_run(self, context: AgentContext) -> None:
        session_path = self.logs_dir / "hermes-session.jsonl"
        if not session_path.exists():
            return

        session_id = str(uuid.uuid4())
        jsonl_text = session_path.read_text()
        native_session_id = self._extract_native_session_id(jsonl_text)

        try:
            trajectory = self._convert_hermes_session_to_atif(jsonl_text, session_id)
        except Exception as e:
            self.logger.debug(f"Error converting hermes session to ATIF: {e}")
            return

        if trajectory:
            try:
                atif_path = self.logs_dir / "trajectory.json"
                atif_path.write_text(json.dumps(trajectory.to_json_dict(), indent=2))
                if trajectory.final_metrics:
                    prompt_tokens = trajectory.final_metrics.total_prompt_tokens or 0
                    completion_tokens = (
                        trajectory.final_metrics.total_completion_tokens or 0
                    )
                    previous = self._reported_session_metrics
                    if (
                        self._last_run_was_resume
                        and previous is not None
                        and (
                            native_session_id is None
                            or previous[0] is None
                            or native_session_id == previous[0]
                        )
                        and prompt_tokens >= previous[1]
                        and completion_tokens >= previous[2]
                    ):
                        context.n_input_tokens = prompt_tokens - previous[1]
                        context.n_output_tokens = completion_tokens - previous[2]
                    else:
                        context.n_input_tokens = prompt_tokens
                        context.n_output_tokens = completion_tokens
                    self._reported_session_metrics = (
                        native_session_id,
                        prompt_tokens,
                        completion_tokens,
                    )
            except Exception as e:
                self.logger.debug(f"Error writing ATIF trajectory: {e}")

    # ------------------------------------------------------------------
    # Agent commands
    # ------------------------------------------------------------------

    @with_prompt_template
    async def run(
        self,
        instruction: str,
        environment: BaseEnvironment,
        context: AgentContext,
    ) -> None:

        self._last_run_was_resume = self._resume

        if not self.model_name or "/" not in self.model_name:
            raise ValueError("Model name must be in the format provider/model_name")

        provider, model = self.model_name.split("/", 1)

        env: dict[str, str] = {
            "HERMES_HOME": "/tmp/hermes",
            "TERMINAL_ENV": "local",
        }

        # Try native provider key first, fall back to OpenRouter.
        hermes_provider_flag: str | None = None
        use_native = False

        if provider in _NATIVE_PROVIDERS:
            native_flag, key_names = _NATIVE_PROVIDERS[provider]
            for key_name in key_names:
                key_val = os.environ.get(key_name)
                if key_val:
                    env[key_name] = key_val
                    hermes_provider_flag = native_flag
                    use_native = True
                    break
            # Forward OPENAI_BASE_URL when using native OpenAI key
            if use_native and provider == "openai":
                base_url = os.environ.get("OPENAI_BASE_URL")
                if base_url:
                    env["OPENAI_BASE_URL"] = base_url

        if not use_native:
            openrouter_key = os.environ.get("OPENROUTER_API_KEY")
            if not openrouter_key:
                native_info = _NATIVE_PROVIDERS.get(provider)
                if native_info:
                    key_hint = " or ".join(native_info[1])
                    raise ValueError(
                        f"No API key found. Set {key_hint} or OPENROUTER_API_KEY."
                    )
                raise ValueError("No API key found. Set OPENROUTER_API_KEY.")
            env["OPENROUTER_API_KEY"] = openrouter_key

        # Native providers with --provider flag use just the model name;
        # everything else (OpenRouter, openai direct) uses provider/model.
        cli_model = model if hermes_provider_flag else self.model_name
        config_yaml = self._build_config_yaml(cli_model)

        # Pass instruction via env var (safe from shell escaping issues)
        env["HARBOR_INSTRUCTION"] = instruction

        # Write config.yaml
        await self.exec_as_agent(
            environment,
            command=(
                "mkdir -p /tmp/hermes && "
                f"cat > /tmp/hermes/config.yaml << 'EOF'\n{config_yaml}EOF"
            ),
            env=env,
            timeout_sec=10,
        )

        # Append MCP server config
        mcp_command = self._build_register_mcp_servers_command()
        if mcp_command:
            await self.exec_as_agent(
                environment, command=mcp_command, env=env, timeout_sec=10
            )

        # Copy skills
        skills_command = self._build_register_skills_command()
        if skills_command:
            await self.exec_as_agent(
                environment, command=skills_command, env=env, timeout_sec=10
            )

        # Build hermes CLI command with flags.
        # hermes uses argparse subcommands; "chat" is the agent loop.
        # --yolo bypasses interactive tool-approval prompts.
        cli_parts = [
            'export PATH="$HOME/.local/bin:$PATH"',
            "hermes --yolo chat",
        ]
        if self._resume:
            native_session_id = getattr(self, "_native_session_id", None)
            if native_session_id is None and self._version_was_pinned:
                raise RuntimeError(
                    "Cannot resume the pinned Hermes version because the previous "
                    "run did not export a native session ID."
                )
            cli_parts.extend(["--resume", shlex.quote(native_session_id or "latest")])
        cli_parts.extend(
            [
                '-q "$HARBOR_INSTRUCTION"',
                "-Q",
                f"--model {shlex.quote(cli_model)}",
            ]
        )
        if hermes_provider_flag:
            cli_parts.append(f"--provider {shlex.quote(hermes_provider_flag)}")
        if self.options.toolsets:
            cli_parts.append(f"--toolsets {shlex.quote(str(self.options.toolsets))}")

        run_cmd = (
            f"{cli_parts[0]} && "
            f"{' '.join(cli_parts[1:])} "
            "2>&1 | stdbuf -oL tee /logs/agent/hermes.txt"
        )

        try:
            await self.exec_as_agent(environment, command=run_cmd, env=env)
        finally:
            try:
                export_result = await self.exec_as_agent(
                    environment,
                    command=(
                        'export PATH="$HOME/.local/bin:$PATH" && '
                        "hermes sessions export /logs/agent/hermes-session.jsonl "
                        "--source cli 2>/dev/null && "
                        "head -n 1 /logs/agent/hermes-session.jsonl || true"
                    ),
                    env={"HERMES_HOME": "/tmp/hermes"},
                    timeout_sec=30,
                )
                native_session_id = self._extract_native_session_id(
                    export_result.stdout
                )
                if native_session_id:
                    self._native_session_id = native_session_id
            except Exception:
                pass

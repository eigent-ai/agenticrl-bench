"""NeMo Skills evaluation helpers."""

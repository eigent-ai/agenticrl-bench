import os
import sys


_MILES_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))
if str(_MILES_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_MILES_REPO_ROOT))

from miles.utils.external_utils import command_utils

MODEL_NAME = os.environ.get("MILES_SCRIPT_MODEL_NAME", "Qwen3-0.6B")
assert MODEL_NAME in {"Qwen3-0.6B"}

MODE = os.environ.get("MILES_SCRIPT_MODE", "normal")
assert MODE in {"normal", "debug_minimal", "debug_one_sample"}

NUM_GPUS = int(os.environ.get("MILES_SCRIPT_NUM_GPUS", "1"))


def prepare():
    U = command_utils.default_config().create_backend()
    U.exec_command_cpu("mkdir -p /root/models /root/datasets")
    U.exec_command_cpu(f"hf download Qwen/{MODEL_NAME} --local-dir /root/models/{MODEL_NAME}")
    U.hf_download_dataset("zhuzilin/gsm8k")


def execute():
    U = command_utils.default_config().create_backend()
    ckpt_args = f"--hf-checkpoint /root/models/{MODEL_NAME} "

    rollout_args = (
        "--prompt-data /root/datasets/gsm8k/train.parquet "
        "--input-key messages "
        "--label-key label "
        "--apply-chat-template "
        "--rollout-shuffle "
        "--rm-type math "
        f"--num-rollout {2 if MODE == 'debug_one_sample' else 3000} "
        f"--rollout-batch-size {1 if MODE == 'debug_one_sample' else 32} "
        f"--n-samples-per-prompt {1 if MODE == 'debug_one_sample' else 8} "
        f"--rollout-max-response-len {2 if MODE == 'debug_one_sample' else 1024} "
        "--rollout-temperature 1 "
        # temp remove this to make test easier
        # "--over-sampling-batch-size 64 "
        # "--dynamic-sampling-filter-path miles.rollout.filter_hub.dynamic_sampling_filters.check_reward_nonzero_std "
        f"--global-batch-size {1 if MODE == 'debug_one_sample' else 256} "
    )

    eval_args = ""
    if MODE == "normal":
        eval_args = (
            "--eval-interval 20 "
            "--eval-prompt-data gsm8k /root/datasets/gsm8k/test.parquet "
            "--n-samples-per-eval-prompt 1 "
            "--eval-max-response-len 1024 "
            "--eval-top-k 1 "
        )

    grpo_args = (
        "--advantage-estimator grpo "
        # "--use-kl-loss "
        "--kl-loss-coef 0.00 "
        "--kl-loss-type low_var_kl "
        "--kl-coef 0.00 "
        "--entropy-coef 0.00 "
        "--eps-clip 0.2 "
        "--eps-clip-high 0.28 "
    )

    optimizer_args = (
        "--optimizer adam "
        "--lr 1e-6 "
        "--lr-decay-style constant "
        "--weight-decay 0.1 "
        "--adam-beta1 0.9 "
        "--adam-beta2 0.98 "
    )

    sglang_args = (
        "--rollout-num-gpus-per-engine 1 "
        "--sglang-decode-log-interval 1000 "
        "--sglang-enable-metrics "
        "--sglang-mem-fraction-static 0.4 "
        f"{'--sglang-disable-cuda-graph ' if MODE == 'debug_one_sample' else ''}"
    )

    fsdp_args = (
        # Set to true for FULL_STATE_DICT mode, false for SHARDED_STATE_DICT mode (default)
        # "--fsdp-full-params "  # Uncomment this line to enable full params mode
        # Set the bucket size for weight update
        "--update-weight-buffer-size 536870912 "  # 512MB
    )

    # ci_args = (
    #     "--ci-test "
    #     "--ci-disable-kl-checker "
    #     "--ci-metric-checker-key eval/gsm8k "
    #     "--ci-metric-checker-threshold 0.71 "  # loose threshold at 60 step
    # )
    ci_args = "--ci-test "

    misc_args = "--actor-num-nodes 1 " f"--actor-num-gpus-per-node {NUM_GPUS} " "--colocate " "--train-backend fsdp "

    # NOTE: --attn-implementation triton activates the SGLang Triton attention bridge
    # (apply_sglang_triton_attention_patch), which uses extend_attention_fwd_unified --
    # the same kernel as the SGLang inference-side Triton backend.
    # Both log-prob computation and training step use the same Triton fwd kernel,
    # with a PyTorch backward for gradient flow through q/k/v projections.
    # This ensures true on-policy: fwd is bitwise-identical in both stages.
    true_on_policy_args = (
        "--sglang-enable-deterministic-inference "
        "--sglang-rl-on-policy-target fsdp "
        "--sglang-attention-backend triton "  # inference side: triton (AMD-compatible)
        "--attn-implementation triton "  # training side: SGLang Triton bridge
        "--deterministic-mode "
        "--true-on-policy-mode "
    )
    true_on_policy_envs = {
        "NCCL_ALGO": "allreduce:tree",
        # "NVTE_ALLOW_NONDETERMINISTIC_ALGO": "0",
        # "CUBLAS_WORKSPACE_CONFIG": ":4096:8",
    }

    train_args = (
        f"{ckpt_args} "
        f"{rollout_args} "
        f"{optimizer_args} "
        f"{grpo_args} "
        f"{sglang_args} "
        f"{command_utils.get_default_wandb_args(__file__)} "
        f"{eval_args} "
        f"{fsdp_args} "
        f"{ci_args} "
        f"{misc_args} "
        f"{true_on_policy_args} "
    )

    U.execute_train(
        train_args=train_args,
        num_gpus_per_node=NUM_GPUS,
        megatron_model_type=None,
        extra_env_vars={
            **true_on_policy_envs,
            **{
                k: os.environ[k]
                for k in (
                    "PYTHONPATH",
                    "CUDA_VISIBLE_DEVICES",
                    "HIP_VISIBLE_DEVICES",
                    "HIP_FORCE_DEV_KERNARG",
                    "RAY_EXPERIMENTAL_NOSET_CUDA_VISIBLE_DEVICES",
                    "RAY_EXPERIMENTAL_NOSET_HIP_VISIBLE_DEVICES",
                    "RAY_EXPERIMENTAL_NOSET_ROCR_VISIBLE_DEVICES",
                    "NVTE_USE_HIPBLASLT",
                )
                if k in os.environ
            },
            "SGLANG_DUMPER_ENABLE": "1" if MODE == "debug_one_sample" else "0",
            "SGLANG_TEMP_UTILS_ENABLE_DEBUG_PRINT": "1" if MODE == "debug_one_sample" else "0",
        },
    )


if __name__ == "__main__":
    prepare()
    execute()

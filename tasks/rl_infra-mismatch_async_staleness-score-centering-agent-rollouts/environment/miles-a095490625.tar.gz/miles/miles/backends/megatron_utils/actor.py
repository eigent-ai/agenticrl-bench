import atexit
import logging
import os
import shutil
from contextlib import ExitStack, nullcontext

import torch
import torch.distributed as dist
from megatron.training.async_utils import maybe_finalize_async_save
from torch_memory_saver import torch_memory_saver

from miles.backends.megatron_utils.hf_export import save_hf_model
from miles.backends.megatron_utils.lora.utils import is_lora_enabled, lora_rollout_enabled
from miles.backends.megatron_utils.rematerialize_utils import build_main_cast_context
from miles.backends.megatron_utils.update_weight.hf_weight_iterator import get_hf_weight_iterator
from miles.backends.training_utils.checkpoint.tracker import read_checkpoint_tracker_iteration
from miles.backends.training_utils.data.rollout import (
    DataIterator,
    get_data_iterator,
    get_num_rollouts,
    get_rollout_data,
)
from miles.backends.training_utils.loss.objective import (
    compute_advantages_and_returns,
    get_log_probs_and_entropy,
    get_values,
    log_train_advantage_computation_event,
)
from miles.backends.training_utils.metrics import train_dump
from miles.backends.training_utils.metrics.log_utils import log_cpu_memory, log_perf_data, log_rollout_data
from miles.backends.training_utils.replay.data import fill_replay_data, register_replay_list_sequential
from miles.backends.training_utils.types import TrainStepOutput
from miles.backends.training_utils.weight_update.hf_weight_iterator import WeightUpdatePlacement
from miles.backends.training_utils.weight_update.snapshot_publisher import SnapshotPublisher
from miles.backends.training_utils.weight_update.updater import WeightUpdater
from miles.dashboard import hooks as dashboard_hooks
from miles.ray.rollout.inference_controller import UpdatableEngines
from miles.ray.specs.train import compute_trainer_pool_id
from miles.ray.train_actor import TrainRayActor
from miles.utils import object_store
from miles.utils.argparse_utils import inplace_modify_args
from miles.utils.audit_utils.event_logger.logger import event_logger_context
from miles.utils.audit_utils.witness.allocator import WitnessInfo
from miles.utils.context_utils import with_defer
from miles.utils.distributed_utils import get_gloo_group
from miles.utils.ft_utils.indep_dp import IndepDPInfo
from miles.utils.lora.utils import build_lora_config, is_multi_lora_enabled
from miles.utils.memory_utils import clear_memory, print_memory
from miles.utils.object_store import StoreObjectRef, ValueSpec
from miles.utils.reloadable_process_group import destroy_process_groups, monkey_patch_torch_dist, reload_process_groups
from miles.utils.replay_base import all_replay_managers, routing_replay_manager
from miles.utils.test_utils.ft_test_actions import FTTestActionActorExecutor
from miles.utils.timer import Timer, inverse_timer, timer
from miles.utils.tracking_utils.structured_log import with_logs
from miles.utils.tracking_utils.tracking import init_tracking
from miles.utils.types import RolloutBatch
from miles.utils.workers.naming import compute_cell_id
from miles.utils.workers.rpc.common.wire_types import Pickled

from ...utils.profile_utils import TrainProfiler
from ...utils.tensor_backper import TensorBackuper
from ..training_utils.parallel import get_parallel_state
from .checkpoint import load_checkpoint
from .ft.checkpoint_transfer import recv_ckpt
from .ft.checkpoint_transfer import send_ckpt as _send_ckpt
from .ft.in_memory_checkpoint import InMemoryCheckpointManager
from .ft.indep_dp import reconfigure_indep_dp_group
from .initialize import RandomState, init, is_first_replica_megatron_main_rank
from .model import (
    LoadCheckpointOutput,
    TrainStepOutcome,
    build_model_and_optimizer,
    forward_only,
    load_model_state,
    save,
    train,
)
from .named_weights import named_params_and_buffers
from .optimizer_utils import reset_optimizer_state
from .parallel import verify_megatron_parallel_state
from .replay_utils import register_replay_list_moe

logging.getLogger("megatron").setLevel(logging.WARNING)

logger = logging.getLogger(__name__)

CRITIC_VALUES_VALUE_SPEC: dict[str, ValueSpec] = {"values": ValueSpec(codec="typed_ragged")}


def _setup_disk_offload_reclaim(disk_dir: str) -> None:
    """Wipe this rank's train disk-offload dir on startup and re-arm the atexit wipe.

    torch_memory_saver unlinks each backup file as its allocation is freed on a
    graceful teardown, but a SIGKILL'd run leaves stale files behind. The dir is
    per-rank (see actor_factory), so clearing it wholesale touches nobody else.
    """
    if not disk_dir:
        return
    shutil.rmtree(disk_dir, ignore_errors=True)
    os.makedirs(disk_dir, exist_ok=True)
    atexit.register(shutil.rmtree, disk_dir, ignore_errors=True)
    logger.info(f"Train disk-offload reclaim armed for {disk_dir} (startup wipe + atexit)")


class MegatronTrainRayActor(TrainRayActor):
    @with_logs
    @with_defer(lambda: Timer().start("train_wait"))
    def init(
        self,
        args: Pickled,
        role: str,
        *,
        with_ref: bool = False,
        with_opd_teacher: bool = False,
        recv_ckpt_src_rank: int | None = None,
        indep_dp_info: IndepDPInfo,
        indep_dp_store_addr: str | None,
    ) -> int | None:
        self.weight_updater: WeightUpdater | None = None
        self.snapshot_publisher: SnapshotPublisher | None = None
        monkey_patch_torch_dist()

        self._last_rollout_id: int | None = None
        super()._init_common(args, role, with_ref, with_opd_teacher=with_opd_teacher)

        for m in all_replay_managers:
            m.register_replay_list_func = register_replay_list_sequential
        routing_replay_manager.register_replay_list_func = register_replay_list_moe

        init(
            args,
            indep_dp_store_addr=indep_dp_store_addr,
            indep_dp_info=indep_dp_info,
        )

        trainer_pool_id = compute_trainer_pool_id(args.trainer_id)
        self._ft_test_action_executor = FTTestActionActorExecutor.from_args(
            args,
            cell_id=compute_cell_id(pool_id=trainer_pool_id, cell_index=indep_dp_info.cell_index),
            rank=self._rank,
        )

        if args.dumper_enable:
            from sglang.srt.debug_utils.dumper import dumper

            dumper.apply_source_patches()

        self._is_first_replica_megatron_main_rank = is_first_replica_megatron_main_rank()

        if self._is_first_replica_megatron_main_rank:
            init_tracking(args, primary=False)

        dashboard_hooks.register_train_actor(args)

        unsupported = {"train_actor", "train_log_probs"} & set(args.profile_target)
        if unsupported and args.use_pytorch_profiler:
            raise NotImplementedError(
                f"--profile-target {' '.join(sorted(unsupported))} is not supported for Megatron backend"
            )
        self.prof = TrainProfiler(args)

        self.load_hf_assets()

        self.train_parallel_config = (
            {}
            if args.indep_dp
            else {
                "dp_size": get_parallel_state().intra_dp.size,
                "cp_size": get_parallel_state().cp.size,
                "vpp_size": get_parallel_state().vpp_size,
                "microbatch_group_size_per_vp_stage": get_parallel_state().microbatch_group_size_per_vp_stage,
            }
        )
        dist.barrier(group=get_gloo_group())

        if args.offload_train:
            if (x := args.train_memory_margin_bytes) > 0:
                # --train-memory-margin-bytes can tune this
                logger.info(f"Set torch_memory_saver.memory_margin_bytes to {x}")
                torch_memory_saver.memory_margin_bytes = x
            if args.offload_train_target == "disk":
                _setup_disk_offload_reclaim(os.environ.get("TMS_DISK_BACKUP_DIR"))

        if self.args.debug_rollout_only:
            return 0

        if role != "critic":
            for m in all_replay_managers:
                m.enabled = getattr(self.args, f"use_{m.name}_replay", False)
                m.enable_check_replay_result = m.enabled and self.args.ci_test

        checkpointing_context = None
        if recv_ckpt_src_rank is not None:
            ckpt_manager = recv_ckpt(
                indep_dp=get_parallel_state().indep_dp,
                src_rank=recv_ckpt_src_rank,
            )
            checkpointing_context = {"local_checkpoint_manager": ckpt_manager}
        elif args.non_persistent_ckpt_type == "local":
            checkpointing_context = {"local_checkpoint_manager": InMemoryCheckpointManager()}

        heal_load_overrides: dict[str, object] = (
            dict(no_load_optim=False, no_load_rng=False, finetune=False) if recv_ckpt_src_rank is not None else {}
        )
        self.model, self.optimizer, self.opt_param_scheduler = build_model_and_optimizer(args, role=role)
        self._post_init_random_state = RandomState.capture()

        parallel_state = get_parallel_state()
        if parallel_state.cp.size > 1:
            from miles_plugins.models.hf_attention import detect_and_setup_hybrid_cp

            for model_chunk in self.model:
                detect_and_setup_hybrid_cp(
                    model_chunk, parallel_state.cp.group, parallel_state.cp.rank, parallel_state.cp.size
                )

        verify_megatron_parallel_state(self.model)

        self._asleep = False
        self._grad_buffer_paused = False

        if role == "critic":
            load_output = self._load_state_core(
                checkpointing_context=checkpointing_context, overrider_for_loading=heal_load_overrides
            )
            if self.args.offload_train:
                self.sleep()
            return load_output.start_rollout_id

        main_cast_ctx = None
        if args.rematerialize_param_from_master_weight:
            main_cast_ctx = build_main_cast_context(args, model=self.model, optimizer=self.optimizer)

        self.weights_backuper = TensorBackuper.create(
            source_getter=self._named_actor_weights,
            main_cast_ctx=main_cast_ctx,
        )
        self._active_model_tag: str | None = "actor"

        if self.args.vocab_size is None:
            self.args.vocab_size = self.tokenizer.vocab_size

        load_output = self._load_state_core(
            checkpointing_context=checkpointing_context, overrider_for_loading=heal_load_overrides
        )

        self._init_training_state()

        self.rollout_data_postprocess = None
        if (x := self.args.rollout_data_postprocess_path) is not None:
            from miles.utils.function_registry import load_function

            self.rollout_data_postprocess = load_function(x)

        if self.args.offload_train:
            self.sleep()

        self.prof.on_init_end()

        return load_output.start_rollout_id

    def _init_training_state(self) -> None:
        args = self.args
        self._init_weight_updater_and_publisher(
            update_weights=not args.debug_train_only,
            publish_snapshots=(
                args.save_hf is not None
                or (args.eval_uses_snapshots and args.eval_hf_dir is not None)
                or (is_lora_enabled(args) and args.save is not None and args.megatron_to_hf_mode != "raw")
            ),
        )

    def _init_weight_updater_and_publisher(self, *, update_weights: bool, publish_snapshots: bool) -> None:
        args = self.args
        model_name = type(self.hf_config).__name__.lower() if args.model_name is None else args.model_name
        quantization_config = getattr(self.hf_config, "quantization_config", None)
        self.weight_updater = None
        self.snapshot_publisher = None

        if update_weights:
            is_lora = lora_rollout_enabled(args)
            if is_lora and not args.colocate:
                assert args.megatron_to_hf_mode == "bridge", (
                    "LoRA weight sync over distributed engines requires "
                    f"--megatron-to-hf-mode bridge (got {args.megatron_to_hf_mode!r})."
                )
            self.weight_updater = WeightUpdater(
                args,
                self.model,
                weights_getter=self._get_actor_weights,
                model_name=model_name,
                quantization_config=quantization_config,
                iterator_factory=get_hf_weight_iterator,
                parallel_state=get_parallel_state(),
                is_lora=is_lora,
                lora_sync_config=(
                    build_lora_config(args, target_modules=args.lora_adapter_targets) if is_lora else None
                ),
            )

        if publish_snapshots:
            is_lora = is_lora_enabled(args)
            iterator = get_hf_weight_iterator(
                args,
                self.model,
                required_placement=WeightUpdatePlacement(gather_pp=True),
                model_name=model_name,
                quantization_config=None if is_lora else quantization_config,
            )
            self.snapshot_publisher = SnapshotPublisher(
                iterator, build_lora_config(args, target_modules=args.lora_adapter_targets) if is_lora else None
            )

    def _clear_quantized_weight_workspaces(self) -> None:
        if not (
            self.args.clear_quantized_weight_workspaces_on_offload
            and self.args.transformer_impl == "transformer_engine"
            # A captured CUDA graph replays with the workspace address baked in.
            and self.args.cuda_graph_impl == "none"
        ):
            return
        from transformer_engine.pytorch.module.base import TransformerEngineBaseModule

        for model_chunk in self.model:
            for module in model_chunk.modules():
                if isinstance(module, TransformerEngineBaseModule):
                    module._fp8_workspaces.clear()

    @with_logs
    def load_state(self) -> int:
        assert self.is_initialized()

        # reloading does not support things like these
        assert not self.args.debug_rollout_only
        assert not is_lora_enabled(self.args)
        assert not is_multi_lora_enabled(self.args)
        assert not self.args.colocate
        assert not self.args.rematerialize_param_from_master_weight
        assert self.args.non_persistent_ckpt_type != "local"
        assert not self.args.offload_train
        assert not self.args.use_pytorch_profiler
        assert not self.args.record_memory_history
        assert not self.args.keep_old_actor, (
            "--keep-old-actor holds a second copy of the actor this reload does not roll back, so the run would "
            "compare the reloaded actor against weights of a rollout it no longer stands at"
        )
        assert not (
            self.with_ref and self.args.ref_update_interval is not None
        ), "--ref-update-interval keeps the reference in memory only, and no checkpoint holds it"
        assert (requested_load := self.args.requested_load) is not None, "a hot restart needs --load"

        self._finalize_pending_async_save()

        resume_from_ckpt = read_checkpoint_tracker_iteration(requested_load) is not None
        if not resume_from_ckpt:
            assert not self.args.fp16
            assert not self.args.use_precision_aware_optimizer
            assert not self.args.optimizer_cpu_offload
            assert not self.args.offload_optimizer_states
            assert self.args.megatron_to_hf_mode != "bridge", "bridge mode unsupported"
            assert self.args.finetune
            assert self.args.no_load_optim
            assert self.args.no_load_rng
            assert self.args.ckpt_step == self.args.ref_ckpt_step

        if self.opt_param_scheduler is not None:
            self.opt_param_scheduler.num_steps = 0

        if resume_from_ckpt:
            overrider_for_loading: dict[str, object] = dict(
                load=requested_load, ckpt_step=None, finetune=False, no_load_optim=False, no_load_rng=False
            )
        else:
            logger.info(
                f"load_state found no checkpoint under --load {requested_load!r}; loading the state the run "
                f"started from"
            )
            overrider_for_loading = {}
            self._post_init_random_state.restore()
            if self.optimizer is not None:
                reset_optimizer_state(
                    self.optimizer,
                    stream_optimizer_state_to_disk=self.args.stream_optimizer_state_to_disk,
                    chunked_optimizer_state_offload=self.args.chunked_optimizer_state_offload,
                )

        load_output = self._load_state_core(
            checkpointing_context=None,
            overrider_for_loading=overrider_for_loading,
        )
        self._last_rollout_id = None

        logger.info(f"load_state rolled this trainer back to checkpoint iteration {load_output.loaded_rollout_id}")
        return load_output.start_rollout_id

    def _load_state_core(
        self, *, checkpointing_context: dict | None, overrider_for_loading: dict[str, object]
    ) -> LoadCheckpointOutput:
        with inplace_modify_args(self.args, overrider_for_loading):
            load_output = load_model_state(
                self.args,
                model=self.model,
                optimizer=self.optimizer,
                opt_param_scheduler=self.opt_param_scheduler,
                role=self.role,
                checkpointing_context=checkpointing_context,
            )

        if self.role != "critic":
            self._load_auxiliary_checkpoints()
            self._switch_model("actor")

        # empty cache after initialization
        clear_memory()

        return load_output

    def _load_auxiliary_checkpoints(self) -> None:
        if self._enable_weight_backup:
            self.weights_backuper.backup("actor")

        if self.with_ref:
            self.load_other_checkpoint("ref", self.args.ref_load)

        # Load teacher model for Megatron-based on-policy distillation
        if self.with_opd_teacher:
            self.load_other_checkpoint("teacher", self.args.opd_teacher_load)

        if self.args.keep_old_actor:
            # Load old_actor checkpoint
            self.load_other_checkpoint("old_actor", self.args.load)
            # Create rollout_actor as a copy of current actor
            if self.args.update_weights_interval == 1:
                self.weights_backuper.backup("rollout_actor")

    def _finalize_pending_async_save(self) -> None:
        if not self.args.async_save:
            return

        maybe_finalize_async_save(blocking=True)

    @with_logs
    @timer
    def sleep(self) -> None:
        assert self.args.offload_train
        if self._asleep:
            logger.info("sleep() called while already offloaded; skipping")
            return

        self._clear_quantized_weight_workspaces()
        clear_memory(clear_host_memory=True)
        print_memory("before offload model")
        should_log_cpu_memory = is_first_replica_megatron_main_rank() and self._last_rollout_id is not None

        destroy_process_groups()

        if self.args.rematerialize_param_from_master_weight and self.role == "actor":
            # Params stay resident for update_weights, which pauses them afterwards.
            torch_memory_saver.pause(tag="grad_buffer")
            torch_memory_saver.pause(tag="default")
        elif lora_rollout_enabled(self.args):
            # adapter params keep their host backup in "default"; the grad buffers have none
            if not self._grad_buffer_paused:
                torch_memory_saver.pause(tag="grad_buffer")
                self._grad_buffer_paused = True
            torch_memory_saver.pause(tag="default")
        else:
            torch_memory_saver.pause(tag=None)

        self._asleep = True
        print_memory("after offload model")

        if should_log_cpu_memory:
            log_cpu_memory(self._last_rollout_id, self.args, "after_offload_train")

    @with_logs
    @timer
    def offload_grad_buffer(self) -> None:
        """Free the LoRA grad buffers ahead of sleep(), so the engine can resume its weights first."""
        assert self.args.offload_train
        assert lora_rollout_enabled(self.args), "only LoRA keeps its grad buffers in a no-backup region"
        if self._asleep or self._grad_buffer_paused:
            return
        print_memory("before offload grad buffer")
        torch_memory_saver.pause(tag="grad_buffer")
        self._grad_buffer_paused = True
        print_memory("after offload grad buffer")

    @with_logs
    @timer
    def wake_up(self) -> None:
        assert self.args.offload_train
        if not self._asleep:
            logger.info("wake_up() called while already resident; ensuring process groups only")
            reload_process_groups()
            return
        print_memory("before wake_up model")

        if lora_rollout_enabled(self.args):
            torch_memory_saver.resume(tag="default")
            torch_memory_saver.resume(tag="grad_buffer")
            self._grad_buffer_paused = False
        else:
            torch_memory_saver.resume(tag=None)

        clear_memory()
        reload_process_groups()
        self._asleep = False
        print_memory("after wake_up model")

    @property
    def _weight_sync_reads_tms_backup(self) -> bool:
        """Under colocated LoRA the frozen base already has a memory-saver host backup; a
        pinned "actor" copy of it would duplicate the whole base per rank. Model switching
        still needs the real backups, and a disk offload target leaves no host backup to read."""
        return (
            self.args.colocate
            and is_lora_enabled(self.args)
            and self.args.offload_train_target == "cpu"
            and not (self.with_ref or self.with_opd_teacher or self.args.keep_old_actor)
        )

    @property
    def _enable_weight_backup(self) -> bool:
        """Keep host weights for model switching and weight sync while offloaded."""
        if self._weight_sync_reads_tms_backup:
            return False
        return (
            self.with_ref
            or self.with_opd_teacher
            or self.args.keep_old_actor
            or self.args.colocate
            or self.args.offload_train
        )

    def _switch_model(self, target_tag: str) -> None:
        if not self._enable_weight_backup:
            return
        if target_tag not in self.weights_backuper.backup_tags:
            raise ValueError(f"Cannot switch to unknown model tag: {target_tag}")
        self.weights_backuper.restore(target_tag)
        self._active_model_tag = target_tag

    def _set_replay_stage(self, stage: str) -> None:
        for m in all_replay_managers:
            m.stage = stage

    @with_logs
    def _compute_log_prob(
        self,
        data_iterator: list[DataIterator],
        num_microbatches: list[int],
        rollout_id: int,
        store_prefix: str = "",
    ) -> dict[str, list[torch.Tensor]]:

        with timer(f"{store_prefix}log_probs"):
            return forward_only(
                get_log_probs_and_entropy,
                self.args,
                self.model,
                data_iterator,
                num_microbatches,
                rollout_id=rollout_id,
                store_prefix=store_prefix,
                fp32_output=False,
                use_rollout_sampling_mask=store_prefix == "" and self.args.use_sampling_support_replay,
            )

    @with_logs
    @event_logger_context(
        lambda _self, rollout_id, rollout_data_ref, witness_info=None, attempt=0, external_data=None: dict(
            rollout_id=rollout_id, attempt=attempt
        )
    )
    def train(
        self,
        rollout_id: int,
        rollout_data_ref: StoreObjectRef | list[StoreObjectRef],
        witness_info: WitnessInfo | None = None,
        attempt: int = 0,
        external_data: TrainStepOutput | None = None,
    ) -> TrainStepOutput:
        self._heartbeat.bump()
        self._last_rollout_id = rollout_id
        if self.args.offload_train and self._asleep:
            self.wake_up()

        with ExitStack() as stack:
            with timer("data_preprocess"):
                rollout_data, store_get_result = get_rollout_data(
                    self.args, rollout_data_ref, witness_info=witness_info
                )
                stack.enter_context(store_get_result)
                if self.args.debug_rollout_only:
                    log_rollout_data(rollout_id, self.args, rollout_data)
                    return TrainStepOutput(outcome=TrainStepOutcome.NORMAL)

            if self.role == "critic":
                with timer("critic_train"):
                    result = self._train_critic(rollout_id, rollout_data)
            else:
                result = self._train_actor(
                    rollout_id,
                    rollout_data,
                    external_data=external_data,
                    witness_info=witness_info,
                    attempt=attempt,
                )

            return result

    @with_logs
    def _train_critic(self, rollout_id: int, rollout_data: RolloutBatch) -> TrainStepOutput:
        # Create data iterator for log_probs and train.
        data_iterator, num_microbatches = get_data_iterator(self.args, self.model, rollout_data)
        rollout_data.update(
            forward_only(
                get_values,
                self.args,
                self.model,
                data_iterator,
                num_microbatches,
                rollout_id=rollout_id,
            )
        )

        compute_advantages_and_returns(self.args, rollout_data)

        self.args.loss_type = "value_loss"
        train_step_outcome: TrainStepOutcome = train(
            rollout_id,
            self.model,
            self.optimizer,
            self.opt_param_scheduler,
            data_iterator,
            num_microbatches,
            get_num_rollouts(self.args, rollout_data, len(num_microbatches)),
            witness_info=None,
            attempt=0,
        )

        self._heartbeat.bump()
        values = None
        if get_parallel_state().is_pp_last_stage and "values" in rollout_data:
            # Ship by object reference
            values = object_store.get_instance().put(
                value={"values": [value.detach().cpu() for value in rollout_data["values"]]},
                value_spec=CRITIC_VALUES_VALUE_SPEC,
            )
        return TrainStepOutput(outcome=train_step_outcome, values=values)

    def _use_rollout_replay(self, m) -> bool:
        return getattr(self.args, f"use_rollout_{m.name}_replay", False)

    @with_logs
    def _train_actor(
        self,
        rollout_id: int,
        rollout_data: RolloutBatch,
        external_data=None,
        *,
        witness_info: WitnessInfo | None,
        attempt: int,
    ) -> TrainStepOutput:
        # Create data iterator for log_probs and train.
        data_iterator, num_microbatches = get_data_iterator(self.args, self.model, rollout_data)
        num_optimizer_steps = len(num_microbatches)
        skip_actor_forward_only = self.args.skip_actor_forward_only
        if skip_actor_forward_only:
            option = "--skip-actor-forward-only"
            assert num_optimizer_steps == 1, f"{option} requires 1 optimizer step, got {num_optimizer_steps}"
            assert rollout_data.get("log_probs") is None, f"{option} requires rollout data without actor log probs"

        for m in all_replay_managers:
            if self._use_rollout_replay(m):
                fill_replay_data(
                    args=self.args,
                    models=self.model,
                    data_iterator=data_iterator,
                    num_microbatches=num_microbatches,
                    rollout_data=rollout_data,
                    data_key=m.data_key,
                    replay_list=m.replays,
                    register_replay_list_func=m.register_replay_list_func,
                    if_sp_region=m.if_sp_region,
                    indices_are_token_positions=m.replay_indices_are_token_positions,
                )

        with inverse_timer("train_wait"), timer("train"):
            if self.args.compute_advantages_and_returns:
                if "ref" in self.weights_backuper.backup_tags:
                    self._set_replay_stage("fallthrough")
                    self._switch_model("ref")
                    rollout_data.update(
                        self._compute_log_prob(
                            data_iterator,
                            num_microbatches,
                            rollout_id=rollout_id,
                            store_prefix="ref_",
                        )
                    )
                # Forward teacher model to get teacher_log_probs for Megatron-based OPD
                if "teacher" in self.weights_backuper.backup_tags:
                    self._set_replay_stage("fallthrough")
                    self._switch_model("teacher")
                    rollout_data.update(
                        self._compute_log_prob(
                            data_iterator,
                            num_microbatches,
                            rollout_id=rollout_id,
                            store_prefix="teacher_",
                        )
                    )
                self._switch_model("old_actor" if self.args.keep_old_actor else "actor")
                if not skip_actor_forward_only and (
                    not self.args.use_rollout_logprobs or self.args.get_mismatch_metrics
                ):
                    for m in all_replay_managers:
                        if m.enabled:
                            if self._use_rollout_replay(m):
                                m.stage = "replay_forward"
                            else:
                                m.stage = "record"
                    rollout_data.update(
                        self._compute_log_prob(
                            data_iterator,
                            num_microbatches,
                            rollout_id=rollout_id,
                            store_prefix="",
                        )
                    )
                    for m in all_replay_managers:
                        if self._use_rollout_replay(m):
                            m.clear_all_forward()

                if self.args.use_critic:
                    if external_data is not None and get_parallel_state().is_pp_last_stage:
                        values_ref = external_data.values
                        assert values_ref is not None, (
                            "actor and critic share the same parallel topology, so the critic rank "
                            "paired with a pp-last-stage actor rank must have shipped 'values'"
                        )
                        with object_store.get_instance().get(values_ref) as shipped:
                            rollout_data["values"] = _materialize_critic_values(
                                values=shipped["values"], device=torch.cuda.current_device()
                            )
                if self._active_model_tag != "actor":
                    self._switch_model("actor")

                # Calculate adv and returns. Need to performed before training (instead of on the fly),
                # because we may need normalize the whole rollout.
                compute_advantages_and_returns(self.args, rollout_data)
                log_train_advantage_computation_event(rollout_data)

            if self.rollout_data_postprocess is not None:
                self.rollout_data_postprocess(self.args)

            log_rollout_data(rollout_id, self.args, rollout_data)

            # Train
            num_rollouts = get_num_rollouts(self.args, rollout_data, num_optimizer_steps)
            self._set_replay_stage("replay_backward")
            with timer("actor_train"):
                train_step_outcome = train(
                    rollout_id,
                    self.model,
                    self.optimizer,
                    self.opt_param_scheduler,
                    data_iterator,
                    num_microbatches,
                    num_rollouts,
                    witness_info=witness_info,
                    attempt=attempt,
                    ft_test_action_executor=self._ft_test_action_executor,
                )

            self.prof.step(rollout_id=rollout_id)

        train_dump.save_debug_train_data(self.args, rollout_id=rollout_id, rollout_data=rollout_data)

        for m in all_replay_managers:
            if m.enabled:
                m.clear_all()

        if train_step_outcome == TrainStepOutcome.NORMAL:
            # update the cpu actor weight to the latest model
            if self._enable_weight_backup:
                self.weights_backuper.backup("actor")
            else:
                torch.cuda.synchronize()

            # Update ref model if needed
            if (
                self.args.ref_update_interval is not None
                and (rollout_id + 1) % self.args.ref_update_interval == 0
                and "ref" in self.weights_backuper.backup_tags
            ):
                with timer("ref_model_update"):
                    if is_first_replica_megatron_main_rank():
                        logger.info(f"Updating ref model at rollout_id {rollout_id}")
                    self.weights_backuper.backup("ref")

        log_perf_data(
            rollout_id,
            self.args,
            extra_metrics=self.weight_updater.pop_metrics() if self.weight_updater is not None else {},
        )

        self._heartbeat.bump()
        return TrainStepOutput(outcome=train_step_outcome)

    @timer
    def save_model(self, rollout_id: int, force_sync: bool = False) -> None:
        self._heartbeat.bump()
        if self.args.debug_rollout_only:
            return

        self._finalize_pending_async_save()

        save(
            rollout_id,
            self.model,
            self.optimizer,
            self.opt_param_scheduler,
            snapshot_publisher=self.snapshot_publisher,
        )

        if self.args.save_hf is not None and self.role == "actor":
            assert self.snapshot_publisher is not None, "HF export requires a snapshot publisher"
            save_hf_model(self.args, rollout_id, self.model, publisher=self.snapshot_publisher)

        if force_sync:
            self._finalize_pending_async_save()

        if self.args.custom_megatron_post_save_hook_path is not None and dist.get_rank() == 0:
            self._finalize_pending_async_save()

            from megatron.training.checkpointing import get_checkpoint_name

            from miles.utils.function_registry import load_function

            checkpoint_dir = get_checkpoint_name(self.args.save, rollout_id, return_base_dir=True)
            hf_checkpoint_dir = (
                self.args.save_hf.format(rollout_id=rollout_id)
                if self.args.save_hf is not None and self.role == "actor"
                else None
            )
            post_save_hook = load_function(self.args.custom_megatron_post_save_hook_path)
            post_save_hook(self.args, rollout_id, checkpoint_dir, hf_checkpoint_dir)

    @with_logs
    @timer
    def export_hf(self, rollout_id: int, path: str) -> None:
        """Export current weights as an HF checkpoint to ``path`` (collective).

        Uses the direct megatron->HF converters (the weight updater's machinery), so
        export coverage matches weight-sync coverage. Unlike the periodic --save-hf
        path inside save_model, failures propagate to the caller so an eval snapshot
        that failed to export can be skipped loudly.
        """
        self._heartbeat.bump()
        assert self.snapshot_publisher is not None, "HF export requires a snapshot publisher"
        save_hf_model(
            self.args, rollout_id, self.model, publisher=self.snapshot_publisher, path=path, raise_on_error=True
        )

    def _named_actor_weights(self, *, translate_gpu_to_cpu: bool = False):
        return named_params_and_buffers(
            self.args,
            self.model,
            convert_to_global_name=self.args.megatron_to_hf_mode == "raw",
            translate_gpu_to_cpu=translate_gpu_to_cpu,
        )

    def _get_actor_weights(self):
        if self._weight_sync_reads_tms_backup:
            return dict(self._named_actor_weights(translate_gpu_to_cpu=True))
        # use cpu backup only when weight is not live on gpu
        if self.args.colocate or self._asleep or self._active_model_tag != "actor":
            return self.weights_backuper.get("actor")
        return dict(self._named_actor_weights())

    @with_logs
    @timer
    def update_weights(self, info: UpdatableEngines) -> int | None:
        self._heartbeat.bump()
        if self.args.debug_train_only or self.args.debug_rollout_only:
            return None

        assert self.weight_updater is not None, "weight update requires a weight updater"
        rollout_engines = info.rollout_engines

        process_groups_are_temporary = self.args.offload_train and self._asleep
        if process_groups_are_temporary:
            reload_process_groups()

        needs_reconnect = self.weight_updater.conn_status.needs_reconnect(info.snapshot_cell_id_to_hashes)
        if needs_reconnect:
            # Connection setup also allocates CUDA tensors (e.g. NCCL object
            # collectives). Do not reuse unmapped, offloaded allocator blocks.
            with torch_memory_saver.disable() if self.args.offload_train else nullcontext():
                self.weight_updater.reconnect(info)

        if self.args.debug_skip_weight_update:
            if dist.get_rank() == 0:
                logger.warning("Skipping actor-to-rollout weight update because " "--debug-skip-weight-update is set.")
            if self.args.rematerialize_param_from_master_weight:
                torch_memory_saver.pause(tag="param_buffer")
            if process_groups_are_temporary:
                destroy_process_groups()
            return None

        with torch_memory_saver.disable() if self.args.offload_train else nullcontext():
            print_memory("before update_weights")
            self.weight_updater.update_weights()
            print_memory("after update_weights")

            if self.args.ci_test and not is_lora_enabled(self.args):
                self.weight_updater.verify_engine_version(rollout_engines)

            if getattr(self.args, "keep_old_actor", False):
                if self.args.update_weights_interval == 1:
                    logger.info("updating model queue: rollout_actor -> old_actor, actor -> rollout_actor")
                    # Queue-style update: rollout_actor params -> old_actor, actor params -> rollout_actor
                    # First copy rollout_actor to old_actor
                    self.weights_backuper.copy(src_tag="rollout_actor", dst_tag="old_actor")
                    # Then copy current actor to rollout_actor
                    self.weights_backuper.backup("rollout_actor")
                else:
                    self.weights_backuper.backup("old_actor")

        if self.args.rematerialize_param_from_master_weight:
            torch_memory_saver.pause(tag="param_buffer")
        if process_groups_are_temporary:
            destroy_process_groups()

        return self.weight_updater.weight_version

    @with_logs
    def load_other_checkpoint(self, model_tag: str, path: str) -> None:
        old_args = self.args.load, self.args.no_load_optim, self.args.no_load_rng, self.args.finetune
        self.args.load = path
        self.args.no_load_optim = True
        self.args.no_load_rng = True
        self.args.finetune = True

        # load_checkpoint reads self.args.ckpt_step to pick which iteration to load.
        # Temporarily override it for ref/teacher loads, then restore after the load below.
        if model_tag == "ref" and self.args.ref_ckpt_step is not None:
            old_ckpt_step = self.args.ckpt_step
            self.args.ckpt_step = self.args.ref_ckpt_step

        if model_tag == "teacher" and self.args.opd_teacher_ckpt_step is not None:
            old_ckpt_step = self.args.ckpt_step
            self.args.ckpt_step = self.args.opd_teacher_ckpt_step

        load_checkpoint(
            self.model,
            None,
            None,
            checkpointing_context={},
            skip_load_to_model_and_opt=False,
        )
        self.args.load, self.args.no_load_optim, self.args.no_load_rng, self.args.finetune = old_args

        if model_tag == "ref" and self.args.ref_ckpt_step is not None:
            self.args.ckpt_step = old_ckpt_step

        if model_tag == "teacher" and self.args.opd_teacher_ckpt_step is not None:
            self.args.ckpt_step = old_ckpt_step

        self.weights_backuper.backup(model_tag)
        self._active_model_tag = model_tag

    @with_logs
    def send_ckpt(self, dst_rank: int) -> None:
        # These states are not handled
        assert not self.args.keep_old_actor
        assert self._last_rollout_id is not None, "healing before the first train step is unsupported"

        _send_ckpt(
            indep_dp=get_parallel_state().indep_dp,
            model=self.model,
            optimizer=self.optimizer,
            opt_param_scheduler=self.opt_param_scheduler,
            iteration=self._last_rollout_id,
            dst_rank=dst_rank,
        )

    @with_logs
    def reconfigure_indep_dp(self, indep_dp_info: IndepDPInfo, indep_dp_store_addr: str | None) -> None:
        reconfigure_indep_dp_group(
            parallel_state=get_parallel_state(),
            store_addr=indep_dp_store_addr,
            indep_dp_info=indep_dp_info,
            megatron_rank=dist.get_rank(),
            megatron_world_size=dist.get_world_size(),
        )
        if self.weight_updater is not None:
            self.weight_updater.conn_status.mark_trainer_stale()


def _materialize_critic_values(
    values: list[list[float] | torch.Tensor], device: torch.device | int
) -> list[torch.Tensor]:
    return [torch.as_tensor(value, dtype=torch.float32, device=device).clone() for value in values]

---
title: LoRA Training and Serving
description: Train LoRA adapters with miles, synchronize them to SGLang, and run dense, MoE, quantized-rollout, multi-LoRA, and agentic recipes.
---

miles trains the adapter matrices in Megatron and serves the same live adapter
from SGLang. The base model stays frozen; at each configured weight-update
boundary, miles exports and synchronizes the updated LoRA weights. The default
boundary is once per rollout/train iteration. No merge-to-base or checkpoint
conversion is required inside the training-rollout loop.

## Training and rollout lifecycle

For a single adapter, miles exports the updated LoRA tensors at each configured
publish boundary. Colocated jobs load them through the local tensor/IPC path;
disaggregated Bridge jobs broadcast them to remote SGLang engines over NCCL.
Rollout requests then select the live named adapter with `lora_path`.

Multi-LoRA currently supports disaggregated rollout only and rejects
`--colocate` at launch. Each SGLang engine keeps the base checkpoint resident;
adapter weights reach the engines through explicit pushes: each push registers
an immutable version under its own engine-side name, so in-flight sampling
against an older version is never disturbed.

Model support is therefore a three-way contract rather than a hard-coded
allowlist:

1. Megatron-Bridge (or a model-specific provider) must build and wrap the
   training model.
2. miles must map and export the selected module names correctly.
3. SGLang must be able to allocate and apply the same adapter modules.

A model can support attention-only LoRA while still having caveats for expert,
linear-attention, or model-specific projections. Start from a validated recipe
instead of assuming that any checkpoint with familiar module names will work.

## LoRA training implementations

Both implementations use `--train-backend megatron`. The difference is how
LoRA is attached to the Megatron model and converted for serving; this is
separate from SGLang's serving-side `--sglang-lora-backend` choice.

| Implementation | How the adapter is built | Model coverage on current `main` | Status |
|---|---|---|---|
| **Megatron-Bridge PEFT** | `AutoBridge` builds the provider, applies Bridge LoRA before DDP, and exports HF-named adapter tensors. Select it with `--megatron-to-hf-mode bridge`. | Qwen2.5, Qwen3, GPT-OSS, Kimi K2.5, GLM-5/5.1/5.2, and Qwen3.5/3.6, subject to the evidence and module caveats below. | General production path. Current multi-LoRA also requires this path. |
| **Native / raw-mode LoRA** | Under `--megatron-to-hf-mode raw`, miles builds the model with its own Megatron provider and attaches model-aware adapter modules directly before DDP. | Inkling and Inkling-Small. The current implementation is an Inkling-specific integration, including custom attention, MLP, routed/shared experts, LM head, adapter import, and export. | Specialized path on current `main`; use the Inkling launcher rather than assuming `raw` works for another model. |

<Note>
The planned maintenance direction is native-first: after the generalized native plugin
lands, new model enablement and ongoing LoRA maintenance will primarily target
the native path. Bridge remains the compatibility path for existing validated
recipes during the transition; this is not an immediate Bridge deprecation.
</Note>

### Native LoRA

Native LoRA attaches adapter modules directly to raw-mode Megatron models
instead of relying on Bridge PEFT conversion. The implementation on `main` is
model-specific to Inkling and Inkling-Small. Generalized model-provider support
is under development in open [PR #1792](https://github.com/radixark/miles/pull/1792)
and is not released on `main`.

## Validated models and recipes

The table distinguishes CI-tested configurations from maintained recipes or
full-scale experiment evidence. It is not an exhaustive model whitelist.

| Implementation | Model family | Architecture exercised | Evidence | Notes |
|---|---|---|---|---|
| Bridge | Qwen2.5 0.5B / 3B | Dense | [0.5B CUDA and ROCm E2E](https://github.com/radixark/miles/blob/main/tests/e2e/lora/test_lora_qwen2.5_0.5B.py), [3B disaggregated recipe](https://github.com/radixark/miles/blob/main/examples/lora/run-qwen2.5-3B-megatron-lora-disaggregated.sh) | The simplest starting point; `all-linear` works. |
| Bridge | Qwen3 4B | Dense | [Single-LoRA recipe](https://github.com/radixark/miles/blob/main/examples/lora/run-qwen3-4B-megatron-lora.sh), [AMD launcher](https://github.com/radixark/miles/blob/main/scripts/amd/run_qwen3_4b_lora.py) | The AMD launcher uses Triton attention and LoRA backends. |
| Bridge | Qwen3-30B-A3B | MoE | [Multi-LoRA gateway example](https://github.com/radixark/miles/tree/main/examples/multi_lora) | Disaggregated Tinker training and versioned sampling. |
| Bridge | GPT-OSS 20B | MoE | [Recipe](https://github.com/radixark/miles/blob/main/examples/lora/run-gpt-oss-20B-megatron-moe-lora.sh), [AMD launcher](https://github.com/radixark/miles/blob/main/scripts/amd/run_gpt_oss_20b_lora.py), [MoE LoRA E2E](https://github.com/radixark/miles/blob/main/tests/e2e/megatron/model_scripts/test_gpt_oss_20b_moe_lora_ci.py) | Uses the SGLang `triton` LoRA backend; the AMD launcher also uses Triton attention and MoE backends. |
| Bridge | Kimi K2.5 | Multimodal MoE + MLA | [16-node recipe](https://github.com/radixark/miles/blob/main/examples/lora/run-kimi-k25-megatron-lora.sh) | Demonstrates shared-outer expert LoRA and an INT4 rollout / fake-QAT setup. |
| Bridge | GLM-5 / 5.1 / 5.2 744B-A40B | MoE + MLA + DSA | [GLM-5.1 launcher](https://github.com/radixark/miles/blob/main/scripts/run_glm5_1_744b_a40b_lora.py), [GLM-5.2 launcher](https://github.com/radixark/miles/blob/main/scripts/run_glm5_2_744b_a40b_lora.py) | CI covers reduced 6-layer / 5-layer checkpoints; historical full-744B results are described below. |
| Bridge | Qwen3.5 / Qwen3.6 35B-A3B | Hybrid GDN + MoE | [Launcher](https://github.com/radixark/miles/blob/main/scripts/run_qwen3_5_35b_a3b_lora.py), [Qwen3.5 E2E](https://github.com/radixark/miles/blob/main/tests/e2e/megatron/test_qwen3_5_35b_a3b_lora_ci.py) | Uses explicit wildcard targets to exclude MTP and vision modules. |
| Native / raw | Inkling / Inkling-Small | Native multimodal MoE | [Launcher](https://github.com/radixark/miles/blob/main/scripts/run_inkling.py), [Inkling-Small 4-layer E2E](https://github.com/radixark/miles/blob/main/tests/e2e/megatron/model_scripts/test_inkling_small_4layer_lora_ci.py) | Current `main` model-specific native path; larger profiles are launcher/experiment evidence rather than LoRA CI. |

## Quick start

Append the following to a Megatron dense-model recipe:

```bash
LORA_ARGS=(
  --lora-rank 32
  --lora-alpha 32
  --lora-dropout 0.0
  --target-modules all-linear
  --megatron-to-hf-mode bridge
)
```

`--lora-rank 0` is the default and disables LoRA when no adapter path is
provided. For RL, dropout is normally set to zero. Alpha is recipe-dependent:
maintained recipes use both `alpha = rank` and `alpha = 2 * rank`.

<Warning>
This quick start is the current Bridge path. On `main`, non-Inkling models must
use `--train-backend megatron --megatron-to-hf-mode bridge`; the Inkling launcher
uses its model-specific native/raw path. The generalized native flags described
in PR #1792 are not released on `main` yet. FSDP does not currently implement
LoRA training.
</Warning>

Omitting `--target-modules` or passing `all-linear` uses the model defaults from
`miles/utils/lora/hf_lora_targets.py`: attention + MLP, with model-specific exclusions
and output-head defaults. Multi-LoRA without explicit targets selects all three
training groups. Use `--target-modules attn,mlp,unembed` to select groups explicitly.
Ordinary LoRA also accepts specific HF targets mixed with group names, such as
`--target-modules attn,lm_head`; Tinker accepts only group names.

### Core arguments

| Flag | Default | Purpose |
|---|---:|---|
| `--lora-rank` | `0` | Adapter rank; a positive value enables LoRA. Supplying an adapter path also marks LoRA enabled, but still requires matching positive-rank configuration. |
| `--lora-alpha` | `16` | Adapter scaling factor. |
| `--lora-dropout` | `0.0` | Dropout on the adapter path. |
| `--lora-type` | `lora` | `lora` uses fused Megatron projections; `canonical_lora` uses split Q/K/V and gate/up projections. The canonical path is implemented and covered by fast name-mapping tests, but has no maintained recipe or E2E validation. |
| `--target-modules` | none | Uses HF model defaults when omitted. Accepts `all-linear`, `attn/mlp/unembed` groups, HF leaf names or scoped HF paths; Bridge also accepts Megatron selectors. |
| `--exclude-modules` | none | Comma-separated HF leaf names or scoped HF paths removed after selection; Bridge also accepts Megatron selectors. |
| `--lora-adapter-path` | none | Warm-start/resume path. Also provide the matching positive rank, alpha, and target modules. Bridge training resume currently requires miles' per-rank adapter shards and the same parallel topology; an HF PEFT-only adapter cannot yet be loaded directly into the Bridge model. Inkling native has its own HF adapter loader. |
| `--lora-base-cpu-backup` | off | Colocated mode only: keep a CPU mirror of the frozen SGLang base and avoid re-sending base weights. This trades host RAM for faster and more reliable pause/resume. |
| `--lora-train-only` | off | Train the adapter while keeping ordinary rollout engines on the frozen base policy. |
| `--experts-shared-outer-loras` | off | Use shared outer factors for grouped MoE experts. This layout is not checkpoint-compatible with per-expert LoRA. |
| `--check-lora-weight-equal` | off | On the colocated path, verify each synchronized adapter tensor with SHA-256. |
| `--update-weights-interval` | `1` | Publish new weights every N rollout/train iterations. This is not LoRA-specific, but it controls when the live adapter is synchronized. |

### HF target source of truth

`miles/utils/lora/hf_lora_targets.py` owns **HF target groups and defaults** for all
backends. It derives attention, MLP, and output-head paths from the model config,
including nested text models, optional MLA projections, expert layouts, and
hybrid attention. Vision towers, routers, norms, and GDN convolutions are excluded.

| Model layout | Attention | MLP | Ordinary LoRA default |
|---|---|---|---|
| Llama, Qwen2/2.5, Qwen3 | Q/K/V/O | Dense gate/up/down | Attention + MLP |
| Qwen3 MoE | Q/K/V/O | Routed experts; dense layers when configured | Attention + MLP |
| Qwen3-Next | Q/K/V/O + GDN qkvz/ba/out | Routed + shared experts; configured dense layers | Attention + MLP |
| Qwen3.5/3.6, text and multimodal | Q/K/V/O + GDN qkv/z/b/a/out | Dense or packed routed + shared experts | Attention + MLP |
| GPT-OSS | Q/K/V/O | Packed gate_up/down experts | Attention + MLP |
| DeepSeek V2/V3, Kimi K2/K2.5 | MLA | Dense + routed + shared experts as configured | Attention + MLP |
| DeepSeek V3.2, GLM-5/5.1/5.2 | MLA + DSA indexer | Dense + routed + shared experts as configured | Attention + MLP, excluding indexer |
| GLM-4 MoE | Q/K/V/O | Dense + routed + shared experts as configured | Attention + MLP |
| Inkling | Q/K/V/R/O | Dense + packed routed + shared expert projections | Attention + MLP + output head |

`--target-modules` accepts comma-separated `attn`, `mlp`, and `unembed` groups,
explicit HF targets, or a mix of both. Group names expand through the model's HF
definition, so `mlp` includes dense, shared, and routed expert projections, including
packed `gate_up_proj` weights. Only exact group names expand; full paths remain
literal target patterns. Duplicates are removed, then `--exclude-modules` applies.
Explicit module selections must not overlap exclusions; defaults and group
selections may still be narrowed with exclusions.

A matching pair of `gate_proj` and `up_proj` selectors also selects
`gate_up_proj` when the HF model has packed projections, with a warning.
Scoped pairs retain their path prefix; selecting only gate or only up does not
expand to the packed projection. Split selectors remain where the model has
split modules and are replaced where it has only packed modules.

Without explicit targets, ordinary LoRA uses its model defaults and multi-LoRA
selects all three groups. `all-linear` selects the ordinary model defaults and
must be used alone. Explicit lists replace the defaults.

Packed expert entries identify HF parameters rather than `nn.Linear` modules.
Inkling entries follow the native HF model namespace. Its native Megatron LoRA
implementation requires the complete fixed layout. SGLang discovers its adapter
modules with `all`, and online weight-sync config uses `all-linear`; adapter
checkpoints derive explicit names from exported tensors. Adapter factors, tensor
packing, and checkpoint names are unchanged. The pinned Transformers version does
not yet include native Inkling, so its HF structure is not covered by the native
meta-model tests. A layout entry is not a backend support claim.

Ordinary LoRA and Tinker share these HF target groups. HF targets retain their
meaning throughout training and serving. `miles/utils/hf_utils/weight_mapping.py`
uses Transformers conversion rules and a meta model's parameter names to relate
checkpoint keys to the current HF model namespace, without loading base weights.
This resolves renamed and packed parameter names. Custom models absent from
native Transformers keep their existing checkpoint namespace.

Bridge resolves mappings against parameters that actually exist across PP/EP
ranks before checking fused selections. Explicit Megatron selectors retain a
compatibility conversion at startup. Adapter factories receive only Megatron
targets; they do not overwrite the HF selection. Arbitrary layer/expert subsets
within a registry template are not implemented and are rejected.
Standard LoRA requires all projections of a fused weight together;
`canonical_lora` supports individual Q/K/V and dense gate/up selections.
Grouped-expert FC1 and GDN input projections remain fused and require all of
their HF projections even in canonical mode.

Tinker uses `--target-modules attn,mlp,unembed` by default; for example,
`--target-modules attn,mlp` disables output-head training. Client SDK flags must
match the selected server groups. Tinker rejects explicit module names,
`all-linear`, and `--exclude-modules` because the SDK describes only whole groups.

For Bridge, SGLang receives the selected HF paths and normalizes them into buffer types
(for example, Q/K/V become `qkv_proj`); it does not own the selection policy.
Adapter checkpoints derive their concrete `target_modules` from exported tensor
keys rather than a separate Megatron-to-HF name table. Online adapter registration
uses the resolved HF selection for Bridge and `all-linear` for native Inkling,
without an extra tensor export.
This requires [SGLang's HF-path normalization support](https://github.com/sgl-project/sglang/pull/40242),
including GDN split names. FSDP LoRA injection remains
unsupported.

Native Inkling
uses a fixed model-specific adapter schema: defaults select that complete schema,
and partial/custom layouts or `canonical_lora` are rejected before injection.
Use the Inkling launcher defaults.

### Rollout topology

| Topology | Adapter transport | Requirements |
|---|---|---|
| Colocated | Local tensor serialization / CUDA IPC | Add `--colocate`; large-model recipes generally also use `--lora-base-cpu-backup`. Pipeline parallel adapter shards are assembled before the load. |
| Disaggregated, including multi-node | NCCL broadcast to remote SGLang engines | Use `--update-weight-transfer-mode broadcast`, Bridge mode, and `--pipeline-model-parallel-size 1`. |

The current native Inkling path is colocated only. Remote/disaggregated LoRA
sync on `main` requires Bridge.

LoRA is not supported by the P2P/RDMA or disk-delta weight-transfer modes. A
hybrid job with both colocated and additional remote rollout engines also cannot
send LoRA weights to the remote engines today.

The legacy `--lora-sync-from-tensor` flag is still accepted by the parser but is
not consumed by the implementation. The topology selects the synchronization
path automatically; do not rely on this flag.

## MoE adapters

This section describes the Bridge path; native Inkling uses its fixed custom
expert layout. For grouped MoE experts, the training and serving layouts must
agree. A typical Bridge configuration is:

```bash
LORA_ARGS=(
  --lora-rank 32
  --lora-alpha 32
  --lora-dropout 0.0
  --target-modules "gate_up_proj,down_proj"
  --sglang-lora-backend triton
  --megatron-to-hf-mode bridge
)
```

The SGLang `triton` backend is required by the maintained MoE recipes; the
default backend can skip MoE layers. Per-expert adapters are the default.
`--experts-shared-outer-loras` selects the shared-outer layout, and miles enables
SGLang virtual-expert serving for expert adapters by default. Use
`--no-sglang-lora-use-virtual-experts` only when intentionally selecting the
alternative aligned-expert path.

## Supported features

- **Losses and algorithms.** LoRA wraps the actor model independently of the
  policy loss. The maintained RL recipes use critic-free estimators such as
  GRPO. The SFT loss path can use the same adapter hooks, although the repository
  does not yet have a dedicated LoRA-SFT E2E test. Shared actor/critic PPO with
  Bridge LoRA is untested: the critic is always built as a full model without
  adapters.
- **Checkpoints.** miles saves native per-rank adapter shards and
  optimizer/scheduler state. Exact resume expects the same TP/PP topology. It
  also attempts a best-effort HF PEFT `adapter_model.safetensors` plus
  `adapter_config.json` export in Bridge mode, through the same snapshot publisher
  used by Tinker. HF export errors are logged while native checkpoint saving
  continues. Raw mode saves native shards and a rank-sharded adapter config without
  HF export. `--save-hf` exports a merged model and an HF adapter without native
  training shards. Direct HF PEFT-to-Bridge resume is not implemented yet; native
  Inkling supplies a model-specific HF adapter importer.
- **Weight synchronization.** Colocated IPC and remote NCCL broadcast both ship
  adapter tensors at each configured update boundary without merging them into
  the base. A checksum checker is available for the colocated path.
- **Model structures.** Dense attention/MLP, MLA, GDN, multimodal models, models
  containing DSA, and both per-expert and shared-outer MoE adapters have
  validated recipes or tests. DSA-indexer adapters themselves are not validated;
  see the model-specific caveats in the table above.
- **Agentic sessions.** Session-server requests carry the active single-LoRA
  name, so multi-turn trajectories are generated by the updated policy rather
  than the frozen base. See the experimental example below.

### Quantized rollout

Precision support is asymmetric: the validated FP8 configuration trains the
LoRA actor in BF16 while SGLang serves a separately quantized FP8 base
checkpoint. Adapter tensors remain unquantized and are synchronized at each
configured weight-update boundary. The GLM-5.2 launcher exposes this as its
`--fp8-rollout` option and writes an SGLang config with `update_weights: true`.
See [Low Precision RL](/advanced/low-precision) and
[INT4 QAT](/advanced/int4-qat) for the underlying precision features.

Historical GLM-5.2 validation measured:

| Configuration | Train/rollout abs diff | KL |
|---|---:|---:|
| 5-layer GLM-5.2, BF16 rollout | `0.0104` | `1.2e-4` |
| 5-layer GLM-5.2, FP8 rollout | `0.0347` | `9.8e-4` |
| Full GLM-5.2 744B, FP8 rollout, two 16-GPU engines | `0.0196` | `2.7e-3` |

These values are configuration-specific rather than universal FP8 thresholds.
The full-744B row is historical multi-node evidence and cannot be reproduced
directly by the current single-node `main` launcher; multi-node launcher work is
tracked in [PR #2033](https://github.com/radixark/miles/pull/2033).

The same work also produced the following curves from a different, longer
validation run. The exact configuration for these curves was not published, so
their plotted levels should not be mapped to any one of the final point
measurements in the table:

![GLM-5.2 LoRA FP8 rollout train-rollout log-prob difference](/assets/images/lora-glm5-2-fp8-logprob.png)

*Train/rollout log-prob difference in the longer FP8 rollout validation.*

![GLM-5.2 LoRA FP8 rollout reward](/assets/images/lora-glm5-2-fp8-reward.png)

*Raw reward in the longer FP8 rollout validation.*

Kimi K2.5 provides a separate model-specific INT4 example: SGLang serves the
INT4 checkpoint while the trainer uses BF16 fake-QAT and TIS correction. Do not
generalize these two recipes into blanket support for FP8, MXFP8, or INT4 LoRA
training on every model. In particular, multi-LoRA on MoE expert leaves rejects
FP8/FP4 experts.

## GLM-5.2 744B BF16 validation

Historical full-scale runs validated the GLM-5/5.1/5.2 Bridge LoRA path across
MoE and MLA on models containing DSA; the DSA indexer itself was excluded from
the adapter targets. The full GLM-5.2 744B run used 64 GPUs and completed more
than 50 rollout -> train -> save steps. The validation also compared expert
target selections, including a run that excluded `down_proj`.

Treat this as historical implementation and scale evidence. The reported
train/rollout log-prob gaps are configuration-specific and are not established
as a portable acceptance threshold, so the corresponding curves are not
reproduced here.

<Warning>
This historical validation is not a claim that the current `main` launcher
reproduces the 744B run on one node. The checked-in launcher is single-node; the
repository's copy-paste validation path uses a reduced checkpoint. Multi-node
full-744B launcher work is tracked in
[PR #2033](https://github.com/radixark/miles/pull/2033).
</Warning>

## Agentic RL with LoRA (experimental)

Agentic rollout has one extra correctness requirement: every turn sent through
the session server must select the newly synchronized adapter. The session
server therefore attaches `lora_path=miles_lora` to its requests; otherwise the
trainer could update LoRA while the agent continues collecting trajectories
from the frozen base policy. The current session integration selects the fixed
single-adapter name; it is not multi-LoRA slot routing, and it should not be
combined with `--lora-train-only`.

[Draft PR #2280](https://github.com/radixark/miles/pull/2280) adds the first
LoRA-specific agentic recipe: GLM-5.2 744B-A40B with synchronous GRPO on
Terminal-Bench-2-style tasks, a Harbor agent server, and Daytona sandboxes. Its
reference configuration uses:

- 4 nodes x 8 H200, TP8 / EP32 / PP1 / CP1;
- BF16 training with an FP8 rollout checkpoint;
- rank 16, alpha 32, attention/MLA-only targets;
- 64K sessions, TileLang DSA, full recompute, and disk actor offload; and
- two 16-GPU rollout engines with `--lora-base-cpu-backup`.

The author reports 30+ 64K-context GRPO rollouts with stable rewards and no
NaN/OOM, but the PR does not publish a reward value, solve rate, or learning
curve. It remains a draft and depends on an open memory-headroom companion
change ([PR #2199](https://github.com/radixark/miles/pull/2199)), so treat it as
stability evidence rather than a released benchmark.

## Multi-LoRA training

Multi-LoRA training is served through the Tinker protocol: `serve_tinker.py`
turns a miles deployment into a training service where each client drives its
own adapter slot with explicit forward_backward / optim_step operations (the
server owns no datasets or schedules). The gateway lives in `miles/tinker/`,
the slot mechanics in `miles/backends/megatron_utils/lora/`. The dataset-driven
multi-LoRA v1 backend (fully-async driver, adapter controller, per-adapter data
sources) has been removed.

Clients use the official `tinker` SDK with the gateway URL and a distinct API key
per tenant. The key identifies ownership of models, futures, and checkpoints.
Each adapter accumulates gradients until its client submits an optimizer step;
saving weights for sampling publishes an immutable adapter version.

`save_state` saves adapter parameters and optimizer state, including FP32 masters.
It waits for preceding commands but neither steps nor saves pending gradients;
call it after `optim_step` to save the effect of the accumulated training work.
Sampler saves commit an immutable adapter directory on shared storage, without
contacting inference engines. Engines load the same frozen base at startup and
load adapter snapshots from disk on demand. A failed engine load fails sampling
without invalidating the saved snapshot or model training.

Futures, model leases, and sequence deduplication are in memory and are lost on
gateway restart. Saved checkpoints retain their ownership and adapter metadata
and can be used to create a new training or sampling client.

See the [gateway example](/examples/multi-lora) for the launcher and smoke client.

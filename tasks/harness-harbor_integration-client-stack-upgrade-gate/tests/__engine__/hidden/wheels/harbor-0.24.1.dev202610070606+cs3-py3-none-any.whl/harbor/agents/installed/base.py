import functools
import json
import os
import re
import shlex
import tempfile
import uuid
from abc import ABC, abstractmethod
from collections.abc import Callable, Mapping
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, ClassVar, Literal, Self, override

from harbor.agents.base import BaseAgent
from harbor.agents.options import (
    InstalledAgentOptions,
    cli_annotation,
    compile_cli_from_options,
    compile_env_from_options,
    sensitive_option_values,
)
from harbor.environments.base import BaseEnvironment
from harbor.models.agent.context import AgentContext
from harbor.models.trajectories import Trajectory
from harbor.utils.env import (
    is_sensitive_env_key,
    parse_bool_env_value,
    redact_sensitive_value,
)
from harbor.utils.templating import render_prompt_template


class NonZeroAgentExitCodeError(RuntimeError):
    """Raised when the agent process exits with a non-zero exit code."""

    pass


class ApiError(NonZeroAgentExitCodeError):
    """Base class for model provider API errors detected in agent output."""

    pass


class ApiRateLimitError(ApiError):
    """Raised when a failed command's output indicates the model provider
    rate-limited a request.

    The distinct type name lets retry policy target it, e.g.
    ``harbor run --max-retries 3 --retry-include ApiRateLimitError``.
    """

    pass


class ApiUsageLimitError(ApiError):
    """Raised when a failed command's output indicates the model provider
    rejected the request because an account or project usage limit is exhausted.
    """

    pass


class ApiInternalServerError(ApiError):
    """Raised when a failed command's output indicates the model provider
    returns a 500 Internal Server Error.
    """

    pass


class ApiOverloadedError(ApiError):
    """Raised when a failed command's output indicates the model provider
    is temporarily overloaded or unavailable.
    """

    pass


class ApiConnectionClosedError(ApiError):
    """Raised when a failed command's output indicates the model provider
    closed the connection before the response completed.
    """

    pass


class ApiResponseStalledError(ApiError):
    """Raised when a failed command's output indicates the model provider
    response stalled mid-stream before completing.
    """

    pass


class OutputTokenExceededError(ApiError):
    """Raised when a failed command's output indicates the model response
    exceeded the configured output token maximum.
    """

    pass


class ContextWindowExceededError(ApiError):
    """Raised when a failed command's output indicates the request exceeded
    the model's context window.
    """

    pass


class UnknownApiError(ApiError):
    """Raised when a failed command's output indicates an unclassified
    model provider API error.
    """

    pass


class ApiProviderResourceNotFoundError(ApiError):
    """Raised when a model provider reports that a requested resource could
    not be found (e.g. Cursor's ``NonRetriableError: Provider Error ...``).

    Unlike a transient ``UnknownApiError``, this may still be retried when job
    retry policy allows ``ApiError`` subclasses.
    """

    pass


class AgentSafetyRefusalError(ApiError):
    """Raised when the model provider blocks a request on safety grounds (e.g.
    Anthropic's Cyber Verification Program safeguard on cybersecurity content).

    A deterministic, request-level decision -- unlike a transient
    ``UnknownApiError`` it will not succeed on retry, so it is excluded from
    retries by default. The distinct type also keeps a legitimate model refusal
    (a real ``reward 0`` outcome) from reading as an unknown/flaky API error.
    """

    pass


class AgentAuthenticationError(NonZeroAgentExitCodeError):
    """Raised when the agent CLI reports that no login, usually because of API key absence"""

    pass


class ModelNotFoundError(NonZeroAgentExitCodeError):
    """Raised when the agent CLI reports that the requested model cannot be
    used, typically because it is unknown or unavailable to the account.
    """

    pass


class UnsupportedModelParametersError(NonZeroAgentExitCodeError):
    """Raised when the model route rejects a request parameter the agent sent
    (e.g. LiteLLM's ``UnsupportedParamsError`` for ``reasoning_effort``).
    """

    pass


class NetworkConnectionError(NonZeroAgentExitCodeError):
    """Raised when a failed command's output indicates a network or TLS
    transport failure (DNS, connection refused, SSL handshake, curl errors).
    """

    pass


_F = Any  # Use Any to keep the decorator signature-transparent to type checkers


def with_prompt_template(fn: _F) -> _F:
    """Decorator for ``run()`` that applies prompt-template rendering.

    Usage::

        @with_prompt_template
        async def run(self, instruction, environment, context):
            # instruction is already rendered through the prompt template
            ...
    """

    @functools.wraps(fn)
    async def wrapper(
        self: BaseInstalledAgent, instruction: str, *args: Any, **kwargs: Any
    ) -> None:
        instruction = self.render_instruction(instruction)
        return await fn(self, instruction, *args, **kwargs)

    return wrapper


@dataclass
class CliFlag:
    """Declarative CLI flag that maps a kwarg to a command-line flag.

    Omitted kwargs use env_fallback/default values. Explicit ``None`` is treated
    as an opt-out and omits the flag.
    """

    kwarg: str
    cli: str
    type: Literal["str", "int", "bool", "enum"] = "str"
    choices: list[str] | None = None
    default: Any = None
    env_fallback: str | None = None
    format: str | None = None


@dataclass
class EnvVar:
    """Declarative env var that maps a kwarg to an environment variable."""

    kwarg: str
    env: str
    type: Literal["str", "int", "bool", "enum"] = "str"
    choices: list[str] | None = None
    default: Any = None
    env_fallback: str | None = None
    bool_true: str = "true"
    bool_false: str = "false"


@dataclass
class ErrorPattern:
    """Declarative regex that classifies failed command output into a
    specific error. Searched case-insensitively over stdout and stderr; the
    match furthest toward the end of the output wins."""

    pattern: str
    exception: type[NonZeroAgentExitCodeError]


def filter_jsonl_events(
    output: str | None, keep: Callable[[dict[str, Any]], bool]
) -> str:
    """Drop JSONL events from ``output`` unless ``keep`` accepts them.

    Lets a harness adapter hand ``_classify_exec_error`` only the events the
    harness itself emitted about the failure, so tool output and model text
    embedded in the stream cannot match ``ERROR_PATTERNS``. Non-JSON lines
    (CLI crashes, install errors) are kept as-is.
    """
    kept: list[str] = []
    for line in (output or "").splitlines():
        stripped = line.strip()
        if not stripped.startswith("{"):
            kept.append(line)
            continue
        try:
            event = json.loads(stripped)
        except json.JSONDecodeError:
            continue
        if isinstance(event, dict) and keep(event):
            kept.append(line)
    return "\n".join(kept)


def _coerce_value(
    value: Any,
    type: Literal["str", "int", "bool", "enum"],
    choices: list[str] | None,
    kwarg_name: str,
) -> Any:
    """Coerce a value to the specified type, raising ValueError on failure."""
    match type:
        case "str":
            if isinstance(value, bool):
                raise ValueError(
                    f"Invalid value for '{kwarg_name}': expected str, got bool"
                )
            if isinstance(value, (int, float)):
                return str(value)
            if not isinstance(value, str):
                raise ValueError(
                    f"Invalid value for '{kwarg_name}': expected str, got {value.__class__.__name__}"
                )
            return value

        case "int":
            if isinstance(value, bool):
                raise ValueError(
                    f"Invalid value for '{kwarg_name}': expected int, got bool"
                )
            if isinstance(value, int):
                return value
            if isinstance(value, float):
                if value != int(value):
                    raise ValueError(
                        f"Invalid value for '{kwarg_name}': float {value} is not an integer"
                    )
                return int(value)
            if isinstance(value, str):
                try:
                    return int(value)
                except ValueError:
                    raise ValueError(
                        f"Invalid value for '{kwarg_name}': cannot parse '{value}' as int"
                    )
            raise ValueError(
                f"Invalid value for '{kwarg_name}': expected int, got {value.__class__.__name__}"
            )

        case "bool":
            return parse_bool_env_value(value, name=kwarg_name)

        case "enum":
            if not isinstance(value, str):
                raise ValueError(
                    f"Invalid value for '{kwarg_name}': expected str for enum, got {value.__class__.__name__}"
                )
            normalized = value.strip().lower()
            if not choices:
                return normalized
            for choice in choices:
                if normalized == choice.lower():
                    return choice
            raise ValueError(
                f"Invalid value for '{kwarg_name}': '{value}'. "
                f"Valid values: {', '.join(sorted(choices))}"
            )

        case _:
            raise ValueError(f"Unknown type '{type}' for kwarg '{kwarg_name}'")


@dataclass(frozen=True)
class PackageSpec:
    """Describe how a system dependency is checked and installed."""

    commands: tuple[str, ...]
    packages: dict[str, tuple[str, ...]]
    always_install: bool = False

    @classmethod
    def standard(cls, name: str) -> Self:
        return cls(
            commands=(name,),
            packages={
                "apt-get": (name,),
                "dnf": (name,),
                "yum": (name,),
                "apk": (name,),
            },
        )


class BaseInstalledAgent(BaseAgent, ABC):
    """
    An interface for agents that are installed and run in the environment.
    """

    @property
    def remote_session_logs_dir(self) -> PurePosixPath | None:
        """Native JSONL directory to sync for ATIF previews, if supported."""
        return None

    def convert_trajectory(self, logs_dir: Path) -> Trajectory | None:
        """Convert downloaded native logs without updating run results."""
        return None

    CLI_FLAGS: ClassVar[list[CliFlag]] = []
    ENV_VARS: ClassVar[list[EnvVar]] = []
    options_model: ClassVar[type[InstalledAgentOptions] | None] = None
    SYSTEM_PACKAGES: ClassVar[dict[str, PackageSpec]] = {
        "curl": PackageSpec.standard("curl"),
        "bash": PackageSpec.standard("bash"),
        "git": PackageSpec.standard("git"),
        "build_tools": PackageSpec(
            commands=("gcc", "make"),
            packages={
                "apt-get": ("build-essential",),
                "dnf": ("gcc", "gcc-c++", "make"),
                "yum": ("gcc", "gcc-c++", "make"),
                "apk": ("build-base",),
            },
        ),
        "tmux": PackageSpec.standard("tmux"),
        "ripgrep": PackageSpec(
            commands=("rg",),
            packages={
                "apt-get": ("ripgrep",),
                "dnf": ("ripgrep",),
                "yum": ("ripgrep",),
                "apk": ("ripgrep",),
            },
        ),
        "xz": PackageSpec(
            commands=("xz",),
            packages={
                "apt-get": ("xz-utils",),
                "dnf": ("xz",),
                "yum": ("xz",),
                "apk": ("xz",),
            },
        ),
        "ca_certificates": PackageSpec(
            commands=(),
            packages={
                "apt-get": ("ca-certificates",),
                "dnf": ("ca-certificates",),
                "yum": ("ca-certificates",),
                "apk": ("ca-certificates",),
            },
            always_install=True,
        ),
        "procps": PackageSpec(
            commands=("pgrep",),
            packages={
                "apt-get": ("procps",),
                "dnf": ("procps-ng",),
                "yum": ("procps-ng",),
                "apk": ("procps",),
            },
        ),
        "coreutils": PackageSpec(
            commands=("stdbuf",),
            packages={
                "apt-get": ("coreutils",),
                "dnf": ("coreutils",),
                "yum": ("coreutils",),
                "apk": ("coreutils",),
            },
        ),
        "bzip2": PackageSpec.standard("bzip2"),
        "tar": PackageSpec.standard("tar"),
        "unzip": PackageSpec.standard("unzip"),
        "wget": PackageSpec.standard("wget"),
        "gnupg": PackageSpec(
            commands=("gpg",),
            packages={
                "apt-get": ("gnupg2",),
                "dnf": ("gnupg2",),
                "yum": ("gnupg2",),
                "apk": ("gnupg",),
            },
        ),
        "python3": PackageSpec.standard("python3"),
        "python_pip": PackageSpec(
            commands=("pip3",),
            packages={
                "apt-get": ("python3-pip",),
                "dnf": ("python3-pip",),
                "yum": ("python3-pip",),
                "apk": ("py3-pip",),
            },
        ),
        "python_venv": PackageSpec(
            commands=(),
            packages={
                "apt-get": ("python3-venv",),
                "dnf": ("python3",),
                "yum": ("python3",),
                "apk": ("py3-virtualenv",),
            },
            always_install=True,
        ),
        "nodejs": PackageSpec(
            commands=("node",),
            packages={
                "apt-get": ("nodejs",),
                "dnf": ("nodejs",),
                "yum": ("nodejs",),
                "apk": ("nodejs",),
            },
        ),
        "npm": PackageSpec.standard("npm"),
        "libxcb": PackageSpec(
            commands=(),
            packages={
                "apt-get": ("libxcb1",),
                "dnf": ("libxcb",),
                "yum": ("libxcb",),
                "apk": ("libxcb",),
            },
            always_install=True,
        ),
        "libgomp": PackageSpec(
            commands=(),
            packages={
                "apt-get": ("libgomp1",),
                "dnf": ("libgomp",),
                "yum": ("libgomp",),
                "apk": ("libgomp",),
            },
            always_install=True,
        ),
    }
    ERROR_PATTERNS: ClassVar[list[ErrorPattern]] = [
        ErrorPattern(r"rate.?limit", ApiRateLimitError),
        ErrorPattern(r"too many requests", ApiRateLimitError),
        ErrorPattern(r"specified API usage limits", ApiUsageLimitError),
        ErrorPattern(r"You've hit your usage limit", ApiUsageLimitError),
        ErrorPattern(r"You have an unpaid invoice", ApiUsageLimitError),
        ErrorPattern(r"Quota exceeded.", ApiUsageLimitError),
        ErrorPattern(r"You have no credits remaining", ApiUsageLimitError),
        ErrorPattern(
            r"Free tier users do not have access|Upgrade to paid credits",
            ApiUsageLimitError,
        ),
        ErrorPattern(
            r"Budget has been exceeded![\s\S]{0,300}?Max\s+budget:",
            ApiUsageLimitError,
        ),
        ErrorPattern(r"API Error: 500 Internal server error", ApiInternalServerError),
        ErrorPattern(r"API Error: Server error mid-response", ApiInternalServerError),
        ErrorPattern(r"RetriableError: \[internal\] Error", ApiInternalServerError),
        ErrorPattern(r"API Error: Overloaded", ApiOverloadedError),
        ErrorPattern(r"ServiceUnavailableError", ApiOverloadedError),
        ErrorPattern(
            r"Selected model is at capacity\. Please try a different model\.",
            ApiOverloadedError,
        ),
        ErrorPattern(
            r"API Error: (?:Connection closed|Connection lost) mid-response",
            ApiConnectionClosedError,
        ),
        # OpenRouter-style phrasing of the same mid-stream disconnect.
        ErrorPattern(
            r"API Error: stream closed before completion",
            ApiConnectionClosedError,
        ),
        ErrorPattern(
            r"API Error: (?:Response stalled mid-stream|Stream idle timeout)",
            ApiResponseStalledError,
        ),
        ErrorPattern(
            r"response exceeded .+ output token maximum",
            OutputTokenExceededError,
        ),
        ErrorPattern(
            r"input token count exceeds the maximum number of tokens|"
            r"prompt is too long: \d+ tokens > \d+ maximum",
            ContextWindowExceededError,
        ),
        ErrorPattern(r"Not logged in", AgentAuthenticationError),
        ErrorPattern(
            r"\binvalid_api_key\b|Invalid API key\b|API key is invalid\b|"
            r"Incorrect API key provided\b|unexpected status 401 Unauthorized\b",
            AgentAuthenticationError,
        ),
        ErrorPattern(
            r"could not read Username for ['\"]https://github\.com",
            AgentAuthenticationError,
        ),
        ErrorPattern(r"Cannot use this model", ModelNotFoundError),
        ErrorPattern(
            r"\blitellm\.UnsupportedParamsError\b|"
            r"does not support parameters:\s*\[[^\]]*\],\s*for\s+model=|"
            r"Unsupported parameter: '[\w.]+'[\s\S]{0,300}?\bunsupported_parameter\b|"
            r"_map_reasoning_effort_to_thinking_level\b[\s\S]{0,300}?"
            r"Invalid reasoning effort",
            UnsupportedModelParametersError,
        ),
        ErrorPattern(r"\blitellm\.NotFoundError\b", ModelNotFoundError),
        # Codex patterns match its final turn.failed event, not reconnect retries.
        ErrorPattern(
            r"Invalid proxy server token passed|\btoken_not_found_in_db\b|"
            r'"turn\.failed"[^\n]{0,60}?unexpected status 403\b',
            AgentAuthenticationError,
        ),
        ErrorPattern(
            r'"turn\.failed"[^\n]{0,60}?unexpected status 500\b',
            ApiInternalServerError,
        ),
        ErrorPattern(
            r'"turn\.failed"[^\n]{0,60}?unexpected status 50[234]\b',
            ApiOverloadedError,
        ),
        ErrorPattern(
            r"Provider Error We.re having trouble finding the resource you requested",
            ApiProviderResourceNotFoundError,
        ),
        # Must precede the generic "API Error" catch-all below.
        # High-precision safety hard-stop needles only. Do NOT match:
        # - bare "Request blocked" (infra/provider noise; also FP-matches prose
        #   like "a request blocked ~3.9s during the drain")
        # - soft Claude "model_refusal_fallback" retries that continue the run
        #   (skipped in ``_classify_exec_error`` when no hard-stop subtype)
        # - bare provider "400" / stream errors without refusal language
        # - bare ``api_refusal_category":"cyber"`` (appears on soft divert /
        #   timeout streams; hard stops also emit cyber safeguard / CVP text)
        ErrorPattern(
            r"safety measures that flagged|Cyber Verification Program|"
            r"flagged for possible cybersecurity risk|"
            # Codex Trusted Access / cybersecurity program hard-stop.
            r"Trusted Access for Cyber|chatgpt\.com/cyber|"
            r"This request was blocked by our safety systems\.|"
            r"API Error: [^\r\n]{1,80} can.t help with this\. "
            r"Start a new session to continue\.|"
            r"Output blocked by content filtering policy|"
            # Anthropic AUP / cyber API refusal hard-stops.
            r"violate our Usage Policy|"
            r"https://www\.anthropic\.com/legal/aup|"
            r"triggered cyber-related safeguards|"
            r"model_refusal_no_fallback|"
            # opencode surfaces a provider content-filter block as a structured
            # ContentFilterError event rather than any of the phrases above.
            r"ContentFilterError|blocked by the provider.s content filter|"
            r'"reason"\s*:\s*"content-filter"',
            AgentSafetyRefusalError,
        ),
        ErrorPattern(r"API Error", UnknownApiError),
        ErrorPattern(
            r"Error when talking to Gemini API\s+Full report available at:",
            UnknownApiError,
        ),
        ErrorPattern(r"SSL_ERROR_SYSCALL", NetworkConnectionError),
        ErrorPattern(r"SSL_connect", NetworkConnectionError),
        ErrorPattern(r"Could not resolve host", NetworkConnectionError),
        ErrorPattern(
            r"Fatal: Could not connect to the release server to download the manifest",
            NetworkConnectionError,
        ),
        ErrorPattern(r"Connection refused", NetworkConnectionError),
        ErrorPattern(r"Connection timed out", NetworkConnectionError),
        ErrorPattern(r"Request timed out", NetworkConnectionError),
        ErrorPattern(r"No route to host", NetworkConnectionError),
        ErrorPattern(r"curl: \(\d+\)", NetworkConnectionError),
    ]

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        if cls.options_model is not None and (cls.CLI_FLAGS or cls.ENV_VARS):
            raise ValueError(
                f"{cls.__name__} declares options_model together with CLI_FLAGS or "
                "ENV_VARS. Move those options onto the model and leave the "
                "constants empty."
            )

    def __init__(
        self,
        logs_dir: Path,
        prompt_template_path: Path | str | None = None,
        version: str | None = None,
        extra_env: dict[str, str] | None = None,
        *,
        config: Path | str | dict[str, Any] | None = None,
        **kwargs,
    ):
        self._flag_kwargs: dict[str, Any] = {
            descriptor.kwarg: kwargs[descriptor.kwarg]
            for descriptor in [*self.CLI_FLAGS, *self.ENV_VARS]
            if descriptor.kwarg in kwargs
        }

        self._resolved_env_vars: dict[str, str] = {}
        super().__init__(
            logs_dir,
            extra_env=extra_env,
            version=version,
            prompt_template_path=prompt_template_path,
            config=config,
            **kwargs,
        )

        if config is not None and not self.capabilities.native_config:
            raise ValueError(
                f"Agent '{self.name()}' does not support config. You can implement it."
            )

        self._config: Path | dict[str, Any] | None
        if isinstance(config, dict):
            try:
                serialized_config = json.dumps(config, allow_nan=False)
            except (TypeError, ValueError) as exc:
                raise ValueError(
                    f"Invalid value for 'config': expected a JSON object: {exc}"
                ) from exc
            normalized_config = json.loads(serialized_config)
            if normalized_config != config:
                raise ValueError(
                    "Invalid value for 'config': expected a JSON object that can "
                    "be represented without conversion"
                )
            self._config = normalized_config
        elif isinstance(config, (str, Path)):
            config_path = Path(config)
            if not config_path.is_file():
                raise FileNotFoundError(f"Agent config file not found: {config_path}")
            self._config = config_path
        elif config is None:
            self._config = None
        else:
            raise ValueError(
                "Invalid value for 'config': expected a local file path or JSON "
                f"object, got {config.__class__.__name__}"
            )

        # Resolve and validate all descriptor values eagerly
        self._resolved_flags = (
            self._flags_from_options()
            if self.options is not None
            else self._resolve_flag_values()
        )
        self._resolved_env_vars = self._resolve_env_values()
        self._resolved_env_vars.update(self._env_from_options())
        self._compiled_error_patterns = [
            (re.compile(p.pattern, re.IGNORECASE), p.exception)
            for p in self.ERROR_PATTERNS
        ]

        if isinstance(self.options, InstalledAgentOptions):
            version = self.options.version
            prompt_template_path = self.options.prompt_template_path
        self._prompt_template_path = (
            Path(prompt_template_path) if prompt_template_path else None
        )
        self._version = version
        self._atif_load_trajectory: Trajectory | None = self._validate_load_trajectory()

    @override
    def _env_sources(self) -> tuple[Mapping[str, str], ...]:
        """Environment sources in runtime precedence order."""
        return (
            self._resolved_env_vars,
            self._extra_env,
            os.environ,
        )

    @property
    def config_source(self) -> Path | dict[str, Any] | None:
        """Optional native config source: a host path or inline JSON object."""
        return deepcopy(self._config)

    def _env_from_options(self) -> dict[str, str]:
        if self.options is None:
            return {}
        return compile_env_from_options(self.options)

    def _flags_from_options(self) -> dict[str, Any]:
        if self.options is None:
            return {}
        resolved: dict[str, Any] = {}
        for name, field in type(self.options).model_fields.items():
            if cli_annotation(field) is None:
                continue
            value = getattr(self.options, name)
            if value is not None:
                resolved[name] = value
        return resolved

    async def _get_system_package_manager(
        self,
        environment: BaseEnvironment,
    ) -> str | None:
        result = await environment.exec(
            command=(
                "for manager in apt-get dnf yum apk; do "
                'if command -v "$manager" >/dev/null 2>&1; then '
                'printf "%s" "$manager"; '
                "break; "
                "fi; "
                "done"
            ),
            user="root",
        )
        return result.stdout.strip() if result.stdout else None

    async def ensure_system_dependencies(
        self,
        environment: BaseEnvironment,
        dependencies: tuple[str, ...],
    ) -> None:
        if not dependencies:
            return

        unknown_dependencies = set(dependencies) - self.SYSTEM_PACKAGES.keys()
        if unknown_dependencies:
            raise ValueError(
                "Unknown system dependencies: "
                f"{', '.join(sorted(unknown_dependencies))}"
            )

        specs: list[PackageSpec] = []
        for dependency in dict.fromkeys(dependencies):
            spec = self.SYSTEM_PACKAGES[dependency]
            if not spec.always_install:
                command_check = " && ".join(
                    f"command -v {shlex.quote(command)} >/dev/null 2>&1"
                    for command in spec.commands
                )
                check_result = await environment.exec(
                    command=command_check,
                    user="root",
                )
                if check_result.return_code == 0:
                    continue
            specs.append(spec)

        if not specs:
            return

        manager = await self._get_system_package_manager(environment)
        if manager is None:
            self.logger.warning(
                "No supported package manager found; cannot ensure system "
                "dependencies: %s",
                ", ".join(dependencies),
            )
            return

        packages = tuple(
            dict.fromkeys(
                package for spec in specs for package in spec.packages[manager]
            )
        )
        package_args = shlex.join(packages)

        if manager == "apt-get":
            command = f"apt-get update && apt-get install -y {package_args}"
            env = {"DEBIAN_FRONTEND": "noninteractive"}
        elif manager == "dnf":
            command = f"dnf install -y {package_args}"
            env = None
        elif manager == "yum":
            command = f"yum install -y {package_args}"
            env = None
        elif manager == "apk":
            command = f"apk add --no-cache {package_args}"
            env = None
        else:
            raise ValueError(f"Unsupported package manager: {manager}")

        await self.exec_as_root(environment, command=command, env=env)

    def _resolve_raw_value(
        self,
        descriptor: CliFlag | EnvVar,
    ) -> Any:
        """Get the raw value for a descriptor from kwargs, then env_fallback, then default."""
        if descriptor.kwarg in self._flag_kwargs:
            return self._flag_kwargs[descriptor.kwarg]
        # env_fallback must see --ae/extra_env values, not just the host
        # environment, so `--ae SOME_FLAG_ENV=...` configures the flag too.
        if descriptor.env_fallback:
            value = self._get_env(descriptor.env_fallback)
            if value is not None:
                return value
        return descriptor.default

    def _resolve_flag_values(self) -> dict[str, Any]:
        """Resolve all CLI_FLAGS to their final coerced values (non-None only)."""
        resolved: dict[str, Any] = {}
        for flag in self.CLI_FLAGS:
            raw = self._resolve_raw_value(flag)
            if raw is None:
                continue
            resolved[flag.kwarg] = _coerce_value(
                raw, flag.type, flag.choices, flag.kwarg
            )
        return resolved

    def compile_cli_flags(self) -> str:
        """Render CLI flags from ``options_model`` or legacy ``CLI_FLAGS``."""
        if self.options is not None:
            return " ".join(compile_cli_from_options(self.options))
        parts: list[str] = []
        for flag in self.CLI_FLAGS:
            value = self._resolved_flags.get(flag.kwarg)
            if value is None:
                continue
            if flag.format is not None:
                parts.append(flag.format.format(value=value))
            elif flag.type == "bool":
                if value:
                    parts.append(flag.cli)
            else:
                parts.append(f"{flag.cli} {value}")
        return " ".join(parts)

    def build_cli_flags(self) -> str:
        """Build the CLI flags string from descriptors and ``Cli`` annotations."""
        return self.compile_cli_flags()

    def _resolve_env_values(self) -> dict[str, str]:
        """Resolve all ENV_VARS to their final {env_name: string_value} dict (non-None only)."""
        resolved: dict[str, str] = {}
        for env_var in self.ENV_VARS:
            raw = self._resolve_raw_value(env_var)
            if raw is None:
                continue
            coerced = _coerce_value(raw, env_var.type, env_var.choices, env_var.kwarg)
            if env_var.type == "bool":
                resolved[env_var.env] = (
                    env_var.bool_true if coerced else env_var.bool_false
                )
            else:
                resolved[env_var.env] = str(coerced)
        return resolved

    def compile_env_vars(self) -> dict[str, str]:
        """Render env vars from ``options_model`` or legacy ``ENV_VARS``."""
        if self.options is not None:
            return compile_env_from_options(self.options)
        return {
            env_var.env: value
            for env_var in self.ENV_VARS
            if (value := self._resolved_env_vars.get(env_var.env)) is not None
        }

    def resolve_env_vars(self) -> dict[str, str]:
        """Public access to resolved env vars dict."""
        return self.compile_env_vars()

    @override
    def version(self) -> str | None:
        return self._version

    def get_version_command(self) -> str | None:
        """Return a shell command that prints the agent version to stdout.
        Override in subclasses to enable auto-detection after setup."""
        return None

    def parse_version(self, stdout: str) -> str:
        """Parse the output of get_version_command into a version string.
        Override in subclasses if the command output needs parsing."""
        return stdout.strip()

    def _truncate_output(self, text: str | None, max_len: int = 1000) -> str:
        if not text:
            return "None"
        if len(text) <= max_len:
            return text
        # Keep the tail as well as the head: CLI agents emit boilerplate first
        # (init banners, config dumps) and report the actual failure at the end
        # of the stream, so head-only truncation drops the useful part.
        head_len = max_len // 4
        tail_len = max_len - head_len
        omitted = len(text) - head_len - tail_len
        return (
            f"{text[:head_len]} ... [{omitted} chars truncated] ... {text[-tail_len:]}"
        )

    def _redact_command(self, command: str) -> str:
        """Mask values of ``Cli(sensitive=True)`` options wherever they appear.

        Sensitive flag values (e.g. auth headers in ``completion_kwargs``) are
        rendered onto the command line, so any log or persisted record of the
        command should scrub them.
        """
        if self.options is None:
            return command
        for secret in sensitive_option_values(self.options):
            if secret:
                command = command.replace(secret, "****")
        return command

    def _classify_exec_error(
        self, command: str, result: Any
    ) -> NonZeroAgentExitCodeError:
        """Map a failed command to the last matching error in ERROR_PATTERNS,
        falling back to NonZeroAgentExitCodeError.
        """
        detail = (
            f"Command failed (exit {result.return_code}): "
            f"{self._redact_command(command)}\n"
            f"stdout: {self._truncate_output(result.stdout)}\n"
            f"stderr: {self._truncate_output(result.stderr)}"
        )
        output = f"{result.stdout or ''}\n{result.stderr or ''}"
        # Soft Claude divert continues the run; never ASR from free-text needles
        # alone (explanatory content can mention Usage Policy / filter phrases).
        skip_asr = (
            "model_refusal_fallback" in output
            and "model_refusal_no_fallback" not in output
        )
        last_match: (
            tuple[int, re.Pattern[str], type[NonZeroAgentExitCodeError]] | None
        ) = None
        for compiled, exception in self._compiled_error_patterns:
            if skip_asr and exception is AgentSafetyRefusalError:
                continue
            for match in compiled.finditer(output):
                if last_match is None or match.end() > last_match[0]:
                    last_match = (match.end(), compiled, exception)

        if last_match is not None:
            _, compiled, exception = last_match
            self.logger.debug(
                f"Classified failed command as {exception.__name__} "
                f"(pattern: {compiled.pattern!r})"
            )
            return exception(detail)
        return NonZeroAgentExitCodeError(detail)

    async def _exec(
        self,
        environment: BaseEnvironment,
        command: str,
        user: str | int | None = None,
        env: dict[str, str] | None = None,
        cwd: str | None = None,
        timeout_sec: int | None = None,
    ) -> Any:
        """Execute a command with logging and error handling.

        Agent ``extra_env`` is wired into the real environment by ``Trial`` with
        a scoped exec-env context. Keeping this method limited to per-exec env
        preserves one precedence rule for both installed and import-path agents.

        Returns the ExecResult on success, raises RuntimeError on failure.
        """
        self.logger.debug(
            f"Running command: {self._redact_command(command)}",
            extra={
                "user": str(user),
                # Whether a formatter renders this extra is configuration-
                # dependent, so credentials (API keys etc.) are redacted
                # before they reach the logging layer at all.
                "env": {
                    key: redact_sensitive_value(value)
                    if is_sensitive_env_key(key)
                    else value
                    for key, value in (env or {}).items()
                },
            },
        )

        result = await environment.exec(
            command=f"set -o pipefail; {command}",
            user=user,
            env=env,
            cwd=cwd,
            timeout_sec=timeout_sec,
        )
        if result.return_code != 0:
            self.logger.debug(
                "Command failed",
                extra={
                    "return_code": result.return_code,
                    "stdout": self._truncate_output(result.stdout),
                    "stderr": self._truncate_output(result.stderr),
                },
            )
            raise self._classify_exec_error(command, result)

        self.logger.debug(
            "Command outputs captured",
            extra={
                "stdout": self._truncate_output(result.stdout),
                "stderr": self._truncate_output(result.stderr),
            },
        )
        return result

    async def exec_as_root(
        self,
        environment: BaseEnvironment,
        command: str,
        env: dict[str, str] | None = None,
        cwd: str | None = None,
        timeout_sec: int | None = None,
    ) -> Any:
        """Execute a command as root (for system packages, symlinks, etc.)."""
        return await self._exec(
            environment, command, user="root", env=env, cwd=cwd, timeout_sec=timeout_sec
        )

    async def exec_as_agent(
        self,
        environment: BaseEnvironment,
        command: str,
        env: dict[str, str] | None = None,
        cwd: str | None = None,
        timeout_sec: int | None = None,
    ) -> Any:
        """Execute a command as the default agent user."""
        return await self._exec(
            environment, command, env=env, cwd=cwd, timeout_sec=timeout_sec
        )

    async def _upload_config_text(
        self,
        environment: BaseEnvironment,
        *,
        content: str,
        remote_path: str,
        filename: str,
    ) -> None:
        """Upload rendered agent configuration with private file permissions."""
        with tempfile.TemporaryDirectory(prefix="harbor-agent-config-") as temp_dir:
            local_path = Path(temp_dir) / filename
            local_path.write_text(content)
            await environment.upload_file(local_path, remote_path)

        if environment.default_user is not None:
            owner = shlex.quote(str(environment.default_user))
            quoted_remote_path = shlex.quote(remote_path)
            await self.exec_as_root(
                environment,
                command=(
                    f"chown {owner} {quoted_remote_path} && "
                    f"chmod 600 {quoted_remote_path}"
                ),
            )

    def render_instruction(self, instruction: str) -> str:
        """Render the instruction through the prompt template, if configured."""
        if self._prompt_template_path:
            return render_prompt_template(self._prompt_template_path, instruction)
        return instruction

    @abstractmethod
    async def install(self, environment: BaseEnvironment) -> None:
        """Install the agent in the environment.

        Use ``exec_as_root`` for system packages and ``exec_as_agent``
        for user-level installs.
        """
        pass

    @override
    async def setup(self, environment: BaseEnvironment) -> None:
        await environment.exec(
            command="[ -d /installed-agent ] || mkdir -p /installed-agent",
            user="root",
        )

        setup_dir = self.logs_dir / "setup"
        setup_dir.mkdir(parents=True, exist_ok=True)

        try:
            await self.install(environment)
        except RuntimeError:
            raise
        except Exception as exc:
            raise RuntimeError(f"Agent install failed: {exc}") from exc

        if self._version is None:
            version_cmd = self.get_version_command()
            if version_cmd:
                try:
                    version_result = await environment.exec(command=version_cmd)
                    if version_result.return_code == 0 and version_result.stdout:
                        self._version = self.parse_version(version_result.stdout)
                except Exception:
                    pass  # Version detection is best-effort

    # Transient flag set by resume() around run(); command builders read it to
    # add the agent's native continue-session flag. Declare resume capability
    # with ``capabilities.resume``, not by setting this.
    _resume: bool = False

    # Transient flag set by load() around run(); run() implementations read it
    # to seed the session from ``load_trajectory`` and resume it. Declare the
    # capability with ``capabilities.load_native_trajectory`` and/or
    # ``capabilities.load_atif_trajectory``, not by setting this.
    _load: bool = False

    def _validate_load_trajectory(self) -> Trajectory | None:
        """Validate ``load_trajectory`` at construction.

        Returns the parsed trajectory when it is ATIF, else None.
        """
        path = self.load_trajectory
        if path is None:
            return None
        if path.suffix == ".json":
            if not self.capabilities.load_atif_trajectory:
                return None
            try:
                return Trajectory.model_validate_json(path.read_text())
            except FileNotFoundError as exc:
                raise ValueError(f"load_trajectory file not found: {path}") from exc
            except (OSError, UnicodeError, ValueError) as exc:
                raise ValueError(
                    f"load_trajectory is not a valid ATIF trajectory file "
                    f"({path}): {exc}"
                ) from exc
        if self.capabilities.load_native_trajectory:
            self._validate_native_load_trajectory(path)
        return None

    def _validate_native_load_trajectory(self, path: Path) -> None:
        """Validate a native trajectory file at construction. Agents that
        declare ``capabilities.load_native_trajectory`` should override."""

    @staticmethod
    def _atif_session_id(trajectory: Trajectory) -> str:
        """Reuse the trajectory's session id when it is a UUID; else mint one."""
        session_id = trajectory.session_id
        if session_id:
            try:
                uuid.UUID(session_id)
                return session_id
            except ValueError:
                pass
        return str(uuid.uuid4())

    @override
    async def resume(
        self,
        instruction: str,
        environment: BaseEnvironment,
        context: AgentContext,
    ) -> None:
        if not self.capabilities.resume:
            return await super().resume(instruction, environment, context)
        self._resume = True
        try:
            await self.run(instruction, environment, context)
        finally:
            self._resume = False

    @override
    async def load(
        self,
        instruction: str,
        environment: BaseEnvironment,
        context: AgentContext,
    ) -> None:
        if not (
            self.capabilities.load_native_trajectory
            or self.capabilities.load_atif_trajectory
        ):
            return await super().load(instruction, environment, context)
        if self.load_trajectory is None:
            raise ValueError(
                "load() requires the agent to be constructed with a "
                "load_trajectory path"
            )
        self._load = True
        try:
            await self.run(instruction, environment, context)
        finally:
            self._load = False

    async def _seed_load_trajectory(self, environment: BaseEnvironment) -> str:
        """Seed the agent's session in the environment from ``load_trajectory``.

        Native files upload as-is; ATIF files are converted with
        ``atif_to_native_trajectory`` first. Returns the seeded session id (the
        file stem for native files).
        """
        if (trajectory := self._atif_load_trajectory) is not None:
            session_id = self._atif_session_id(trajectory)
            filename, content = self.atif_to_native_trajectory(trajectory, session_id)
            with tempfile.TemporaryDirectory() as tmp_dir:
                source = Path(tmp_dir) / filename
                source.write_text(content)
                await self._upload_load_trajectory(environment, source)
            return session_id
        source = self.load_trajectory
        if source is None:
            raise ValueError("load_trajectory is not set")
        await self._upload_load_trajectory(environment, source)
        return source.stem

    def atif_to_native_trajectory(
        self, trajectory: Trajectory, session_id: str
    ) -> tuple[str, str]:
        """Convert an ATIF trajectory into the agent's native trajectory format.

        Returns ``(filename, content)``. Agents that declare
        ``capabilities.load_atif_trajectory`` must implement this.
        """
        raise NotImplementedError(
            f"Agent '{self.name()}' does not support converting an ATIF trajectory"
        )

    async def _upload_load_trajectory(
        self, environment: BaseEnvironment, source: Path
    ) -> None:
        """Place a native trajectory file where the agent expects sessions.

        Agents that declare load support must implement this.
        """
        raise NotImplementedError(
            f"Agent '{self.name()}' does not support loading a trajectory"
        )

    async def _upload_agent_owned_file(
        self, environment: BaseEnvironment, source: Path, target: str
    ) -> None:
        await environment.upload_file(source, target)
        # upload_file copies as root; the agent user must be able to read it
        if environment.default_user is not None:
            user = shlex.quote(str(environment.default_user))
            await self.exec_as_root(
                environment,
                command=f"chown {user} {shlex.quote(target)}",
            )

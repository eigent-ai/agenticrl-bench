import copy
import json
import shlex
from datetime import datetime, timezone
from typing import Annotated, Any, override

from pydantic import Field

from harbor.agents.capabilities import AgentCapabilities
from harbor.agents.installed.base import (
    BaseInstalledAgent,
    NonZeroAgentExitCodeError,
    with_prompt_template,
)
from harbor.agents.model_connection import (
    ResolvedModelConnection,
    ModelConnectionSpec,
    without_inferred_base_url,
)
from harbor.agents.options import Cli, InstalledAgentOptions
from harbor.environments.base import BaseEnvironment
from harbor.models.agent.context import AgentContext
from harbor.models.agent.name import AgentName
from harbor.models.trajectories import (
    Agent,
    FinalMetrics,
    Metrics,
    Observation,
    ObservationResult,
    Step,
    ToolCall,
    Trajectory,
)
from harbor.utils.trajectory_utils import format_trajectory_json


_WEB_TOOLS = ("websearch", "webfetch")


class MiMoOptions(InstalledAgentOptions):
    variant: Annotated[str | None, Cli("--variant")] = Field(
        default=None, description="Model variant."
    )
    mimo_config: dict[str, Any] | None = Field(
        default=None, description="MiMo config overlay."
    )
    disable_web_search: bool = Field(
        default=False, description="Deny the websearch and webfetch tools."
    )


class MiMo(BaseInstalledAgent):
    """
    The MiMo agent uses the mimo tool to solve tasks.

    Parses the JSON lines emitted by ``mimo run --format=json`` (captured
    to ``mimo.txt``) into an ATIF trajectory.

    Stdout JSON line types:
        text          - agent text output (part.type == "text")
        reasoning     - optional explicit reasoning text (part.type == "reasoning")
        tool_use      - tool call with input/output (part.type == "tool")
        step_start    - marks the beginning of an agent turn
        step_finish   - marks the end of a turn, carries cost & token data
        error         - error event
    """

    capabilities = AgentCapabilities(
        atif=True, resume=True, skills=True, mcp_servers=True
    )
    MODEL_CONNECTION = ModelConnectionSpec(passthrough=True)

    @property
    @override
    def model_connection(self) -> ResolvedModelConnection:
        access = super().model_connection
        if self._mimo_config:
            return without_inferred_base_url(access)
        return access

    _OUTPUT_FILENAME = "mimo.txt"

    options_model = MiMoOptions
    options: MiMoOptions

    # Base config written to mimocode.json before each run.
    # Extend per-job via ``mimo_config`` in agents[].kwargs, e.g.:
    #
    #   mimo_config:
    #     experimental:
    #       continue_loop_on_deny: true
    _DEFAULT_CONFIG: dict[str, Any] = {}

    def __init__(self, *args, mimo_config: dict[str, Any] | None = None, **kwargs):
        super().__init__(*args, mimo_config=mimo_config, **kwargs)
        self._mimo_config: dict[str, Any] = mimo_config or {}

    @staticmethod
    def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
        """Merge *override* into *base* in place, recursing into nested dicts."""
        for key, value in override.items():
            if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                MiMo._deep_merge(base[key], value)
            else:
                base[key] = value
        return base

    @staticmethod
    @override
    def name() -> str:
        return AgentName.MIMO.value

    @override
    def get_version_command(self) -> str | None:
        return 'export PATH="$HOME/.mimocode/bin:$PATH" && mimo --version'

    @override
    async def install(self, environment: BaseEnvironment) -> None:
        await self.ensure_system_dependencies(environment, ("curl",))
        await self.exec_as_agent(
            environment,
            command=(
                "set -euo pipefail; "
                "curl -fsSL https://mimo.xiaomi.com/install | bash && "
                'export PATH="$HOME/.mimocode/bin:$PATH" && '
                "mimo --version"
            ),
        )

    @staticmethod
    def _millis_to_iso(timestamp_ms: int | float | None) -> str | None:
        """Convert a millisecond Unix timestamp to ISO 8601 string."""
        if timestamp_ms is None:
            return None
        try:
            return datetime.fromtimestamp(
                timestamp_ms / 1000, tz=timezone.utc
            ).isoformat()
        except (OSError, ValueError, OverflowError):
            return None

    def _parse_stdout(self) -> list[dict[str, Any]]:
        """Read and parse JSON lines from the mimo stdout file."""
        output_path = self.logs_dir / self._OUTPUT_FILENAME
        if not output_path.exists():
            return []

        events: list[dict[str, Any]] = []
        for line in output_path.read_text().splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        return events

    def _error_messages(self) -> list[str]:
        """Return messages from MiMo error events in stdout."""
        messages: list[str] = []
        for event in self._parse_stdout():
            if event.get("type") != "error":
                continue
            error = event.get("error")
            if isinstance(error, dict):
                data = error.get("data")
                message = data.get("message") if isinstance(data, dict) else None
                messages.append(str(message or error.get("name") or error))
            else:
                messages.append(str(error))
        return messages

    def _convert_events_to_trajectory(
        self, events: list[dict[str, Any]]
    ) -> Trajectory | None:
        """Convert mimo stdout JSON events into an ATIF trajectory.

        Events are grouped into agent steps by ``step_start`` / ``step_finish``
        boundaries.  Each group of events between a ``step_start`` and
        ``step_finish`` becomes one ATIF Step with source="agent".  A user Step
        is synthesised at the beginning (the instruction is in mimo.txt only
        as a CLI arg, not as an event, so we use a placeholder).
        """
        if not events:
            return None

        session_id: str | None = None
        for event in events:
            sid = event.get("sessionID")
            if sid:
                session_id = sid
                break

        # Group events into turns delimited by step_start / step_finish
        turns: list[dict[str, Any]] = []
        current_turn: dict[str, Any] | None = None

        for event in events:
            etype = event.get("type")

            if etype == "step_start":
                current_turn = {
                    "parts": [],
                    "finish": None,
                    "timestamp": event.get("timestamp"),
                }
                continue

            if etype == "step_finish":
                if current_turn is not None:
                    current_turn["finish"] = event.get("part", {})
                    turns.append(current_turn)
                    current_turn = None
                continue

            if current_turn is not None and etype in ("text", "reasoning", "tool_use"):
                current_turn["parts"].append(event.get("part", {}))

        steps: list[Step] = []
        step_id = 1
        total_cost = 0.0
        total_input_tokens = 0
        total_output_tokens = 0
        total_cache_read = 0

        for turn in turns:
            text_parts: list[str] = []
            reasoning_parts: list[str] = []
            tool_calls_list: list[ToolCall] = []
            observation_results: list[ObservationResult] = []
            timestamp = self._millis_to_iso(turn.get("timestamp"))

            for part in turn["parts"]:
                ptype = part.get("type")

                if ptype == "text":
                    text = part.get("text", "")
                    if text:
                        text_parts.append(text)

                elif ptype == "reasoning":
                    reasoning = part.get("text", "")
                    if reasoning:
                        reasoning_parts.append(reasoning)

                elif ptype == "tool":
                    state = part.get("state", {})
                    tool_name = part.get("tool", "")
                    tool_input = state.get("input", {})
                    tool_output = state.get("output")
                    call_id = part.get("callID", part.get("id", ""))

                    if not isinstance(tool_input, dict):
                        tool_input = {"value": tool_input} if tool_input else {}

                    tool_calls_list.append(
                        ToolCall(
                            tool_call_id=call_id,
                            function_name=tool_name,
                            arguments=tool_input,
                        )
                    )

                    if tool_output is not None:
                        observation_results.append(
                            ObservationResult(
                                source_call_id=call_id or None,
                                content=str(tool_output),
                            )
                        )

            # Extract metrics from step_finish
            finish = turn.get("finish", {})
            tokens = finish.get("tokens", {})
            cost = finish.get("cost", 0) or 0
            input_tok = tokens.get("input", 0) or 0
            output_tok = tokens.get("output", 0) or 0
            reasoning_tok = tokens.get("reasoning", 0) or 0
            cache = tokens.get("cache", {})
            cache_read = cache.get("read", 0) or 0
            cache_write = cache.get("write", 0) or 0

            total_cost += cost
            total_input_tokens += input_tok + cache_read
            total_output_tokens += output_tok
            total_cache_read += cache_read

            metrics: Metrics | None = None
            if input_tok or output_tok or cache_read:
                metrics = Metrics(
                    prompt_tokens=input_tok + cache_read,
                    completion_tokens=output_tok,
                    cached_tokens=cache_read if cache_read else None,
                    cost_usd=cost if cost else None,
                    extra={
                        k: v
                        for k, v in {
                            "reasoning_tokens": reasoning_tok,
                            "cache_write_tokens": cache_write,
                        }.items()
                        if v
                    }
                    or None,
                )

            message_text = "\n".join(text_parts) if text_parts else ""
            observation = (
                Observation(results=observation_results)
                if observation_results
                else None
            )

            step_kwargs: dict[str, Any] = {
                "step_id": step_id,
                "timestamp": timestamp,
                "source": "agent",
                "message": message_text or "(tool use)",
                "model_name": self.model_name,
            }
            if reasoning_parts:
                step_kwargs["reasoning_content"] = "\n\n".join(reasoning_parts)
            if tool_calls_list:
                step_kwargs["tool_calls"] = tool_calls_list
            if observation:
                step_kwargs["observation"] = observation
            if metrics:
                step_kwargs["metrics"] = metrics

            steps.append(Step(**step_kwargs))
            step_id += 1

        if not steps:
            return None

        final_metrics = FinalMetrics(
            total_prompt_tokens=total_input_tokens or None,
            total_completion_tokens=total_output_tokens or None,
            total_cached_tokens=total_cache_read or None,
            total_cost_usd=total_cost if total_cost else None,
            total_steps=len(steps),
        )

        return Trajectory(
            schema_version="ATIF-v1.6",
            session_id=session_id or "unknown",
            agent=Agent(
                name="mimo",
                version=self.version() or "unknown",
                model_name=self.model_name,
            ),
            steps=steps,
            final_metrics=final_metrics,
        )

    @override
    def populate_context_post_run(self, context: AgentContext) -> None:
        """Parse mimo stdout and convert to ATIF trajectory."""
        events = self._parse_stdout()
        if not events:
            return

        try:
            trajectory = self._convert_events_to_trajectory(events)
        except Exception:
            self.logger.exception("Failed to convert mimo events to trajectory")
            return

        if not trajectory:
            return

        trajectory_path = self.logs_dir / "trajectory.json"
        try:
            trajectory_path.write_text(
                format_trajectory_json(trajectory.to_json_dict())
            )
            self.logger.debug(f"Wrote mimo trajectory to {trajectory_path}")
        except OSError as exc:
            self.logger.debug(
                f"Failed to write trajectory file {trajectory_path}: {exc}"
            )

        if trajectory.final_metrics:
            fm = trajectory.final_metrics
            context.cost_usd = fm.total_cost_usd
            context.n_input_tokens = fm.total_prompt_tokens or 0
            context.n_output_tokens = fm.total_completion_tokens or 0
            context.n_cache_tokens = fm.total_cached_tokens or 0

    def _build_register_skills_command(self) -> str | None:
        """Return a shell command that copies skills to MiMoCode's skills directory."""
        if not self.skills_dir:
            return None
        return (
            f"mkdir -p ~/.config/mimocode/skills && "
            f"cp -r {shlex.quote(self.skills_dir)}/* "
            f"~/.config/mimocode/skills/ 2>/dev/null || true"
        )

    def _build_register_config_command(self) -> str | None:
        """Return a shell command that writes the mimo config to ~/.config/mimocode/mimocode.json.

        The config may include MCP server definitions and/or a provider model
        registration so mimo recognises models not in its built-in registry.
        """
        config: dict[str, Any] = {}

        if self.mcp_servers:
            mcp: dict[str, dict[str, Any]] = {}
            for server in self.mcp_servers:
                if server.transport == "stdio":
                    cmd_list = [server.command] + server.args if server.command else []
                    mcp[server.name] = {"type": "local", "command": cmd_list}
                else:  # sse or streamable-http
                    mcp[server.name] = {"type": "remote", "url": server.url}
            config["mcp"] = mcp

        if self.model_name and "/" in self.model_name:
            provider, model_id = self.model_name.split("/", 1)
            provider_config: dict[str, Any] = {"models": {model_id: {}}}
            base_url = self.model_connection.configured_base_url
            if base_url:
                # mimo reads baseURL from provider.options, not the provider root.
                # See: https://github.com/anomalyco/opencode config.ts ProviderConfig schema.
                provider_config.setdefault("options", {})["baseURL"] = base_url
                provider_config.setdefault("npm", "@ai-sdk/openai-compatible")
            if (
                provider != "mimo"
            ):  # mimo provider config is only needed for non-mimo providers
                config["provider"] = {provider: provider_config}

        # Layer: defaults → auto-generated → job-level overrides.
        # Deep-merge preserves sibling keys within nested dicts (e.g. provider, experimental).
        config = self._deep_merge(copy.deepcopy(self._DEFAULT_CONFIG), config)
        config = self._deep_merge(config, self._mimo_config)
        if self.options.disable_web_search:
            permission = config.get("permission")
            if not isinstance(permission, dict):
                permission = {"*": permission} if permission else {}
            # Later rules win, so the denies must come after any user rule.
            config["permission"] = {
                **{k: v for k, v in permission.items() if k not in _WEB_TOOLS},
                **{tool: "deny" for tool in _WEB_TOOLS},
            }

        if not config:
            return None

        config_json = json.dumps(config, indent=2)
        escaped = shlex.quote(config_json)
        return f"mkdir -p ~/.config/mimocode && echo {escaped} > ~/.config/mimocode/mimocode.json"

    @override
    @with_prompt_template
    async def run(
        self,
        instruction: str,
        environment: BaseEnvironment,
        context: AgentContext,
    ) -> None:
        escaped_instruction = shlex.quote(instruction)

        if not self.model_name or "/" not in self.model_name:
            raise ValueError("Model name must be in the format provider/model_name")

        env = dict(self.model_connection.env)

        # Enable fake VCS for MiMoCode
        env["MIMOCODE_FAKE_VCS"] = "git"
        env["XDG_DATA_HOME"] = "/logs/agent/mimo/xdg-data"
        env["XDG_STATE_HOME"] = "/logs/agent/mimo/xdg-state"

        skills_command = self._build_register_skills_command()
        if skills_command:
            await self.exec_as_agent(environment, command=skills_command, env=env)

        mcp_command = self._build_register_config_command()
        if mcp_command:
            await self.exec_as_agent(environment, command=mcp_command, env=env)

        cli_flags = self.build_cli_flags()
        cli_flags_arg = (cli_flags + " ") if cli_flags else ""
        resume_flag = "--continue " if self._resume else ""

        await self.exec_as_agent(
            environment,
            # Note that the --thinking flag just means thinking blocks will be included in the json formatted output
            command=(
                'export PATH="$HOME/.mimocode/bin:$PATH"; '
                f"mimo --model={self.model_name} run --format=json "
                f"{resume_flag}{cli_flags_arg}--thinking "
                f"--dangerously-skip-permissions -- {escaped_instruction} "
                f"2>&1 </dev/null | stdbuf -oL tee /logs/agent/mimo.txt"
            ),
            env=env,
        )

        if messages := self._error_messages():
            raise NonZeroAgentExitCodeError(
                "MiMo emitted error event(s): " + "; ".join(messages[:3])
            )

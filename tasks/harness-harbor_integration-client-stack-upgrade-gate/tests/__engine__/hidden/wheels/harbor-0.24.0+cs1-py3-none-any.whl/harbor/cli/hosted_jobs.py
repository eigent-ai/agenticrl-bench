from __future__ import annotations

import logging
import os
import sys
from pathlib import Path
from typing import TYPE_CHECKING
from uuid import UUID

from dotenv import dotenv_values
from rich.console import Console

from harbor.cli.utils import run_async, parse_env_vars
from harbor.hosted.config import (
    CredentialMode,
    HostedAgentConfig,
    HostedJobConfig,
    HostedRegradeSource,
)
from harbor.models.job.config import DatasetConfig, JobConfig
from harbor.models.trial.config import TaskConfig, VerifierConfig

if TYPE_CHECKING:
    from harbor.hosted.preflight import PreflightWarnings

logger = logging.getLogger(__name__)

# Agents that drive no model, so a launch naming no credential for them is
# intentional rather than an omission.
_NO_CREDENTIAL_AGENTS = frozenset({"oracle", "nop"})


def _collect_launch_job_secrets(
    env_file: Path,
    console: Console,
) -> dict[str, str] | None:
    """Parse an env file into job-scoped secrets for a hosted launch.

    Every key in the file becomes a job credential: encrypted by the launch
    API, injected into this job's trials ahead of account-wide secrets, and
    revoked when the job finishes. The key names are surfaced in the
    pre-launch summary; only names are ever displayed.
    """
    values = {
        key: value
        for key, value in dotenv_values(env_file).items()
        if key is not None and value
    }
    if not values:
        console.print(f"[yellow]Env file {env_file} has no values; ignoring.[/yellow]")
        return None
    return values


def _parse_launch_secrets(values: list[str], console: Console) -> dict[str, str]:
    """Parse repeated ``--one-off-secret NAME[=VALUE]`` flags into job credentials.

    Same channel as ``--env-file``, one name at a time: encrypted by the launch
    API, injected into this job's trials ahead of account-wide secrets, and
    revoked when the job finishes. A bare ``NAME`` takes the value from the
    caller's environment so a secret never has to appear in shell history.
    """
    from harbor.hosted.api import ENV_VAR_RE

    secrets: dict[str, str] = {}
    for raw in values:
        name, sep, value = raw.partition("=")
        name = name.strip()
        if not ENV_VAR_RE.match(name):
            console.print(
                f"[red]Error:[/red] --one-off-secret name {name!r} must look like "
                "ANTHROPIC_API_KEY (uppercase letters, digits, underscores)."
            )
            raise SystemExit(1)
        if name in secrets:
            console.print(f"[red]Error:[/red] --one-off-secret given twice for {name}.")
            raise SystemExit(1)
        if not sep:
            value = os.environ.get(name, "")
            if not value:
                console.print(
                    f"[red]Error:[/red] --one-off-secret {name} reads {name} from your "
                    f"environment, but it is unset or empty. Pass "
                    f"--one-off-secret {name}=VALUE instead."
                )
                raise SystemExit(1)
        elif not value:
            console.print(
                f"[red]Error:[/red] --one-off-secret {name}= has an empty value. Drop the "
                f"'=' to read {name} from your environment."
            )
            raise SystemExit(1)
        secrets[name] = value
    return secrets


def _resolve_config_job_secrets(config: HostedJobConfig) -> dict[str, str]:
    resolved: dict[str, str] = {}
    for name, secret in config.job_secrets.items():
        value = os.environ.get(secret.from_env)
        if not value:
            raise ValueError(
                f"{secret.from_env} is unset or empty; it supplies "
                f"one-off secret {name}"
            )
        resolved[name] = value
    return resolved


def _parse_stored_secret_names(values: list[str], console: Console) -> list[str]:
    """Parse repeated ``--stored-secret NAME`` flags into an agent selection.

    These are names of secrets already stored in the owning organization, not
    values: the runner grants the matching credentials to the job's trials.
    Duplicates collapse (the selection is a set server-side) while preserving
    the order given, which is the order the summary lists them in.
    """
    from harbor.hosted.api import ENV_VAR_RE

    selection: list[str] = []
    for raw in values:
        name = raw.strip()
        if not ENV_VAR_RE.match(name):
            console.print(
                f"[red]Error:[/red] --stored-secret name {name!r} must look like "
                "ANTHROPIC_API_KEY (uppercase letters, digits, underscores)."
            )
            raise SystemExit(1)
        if name not in selection:
            selection.append(name)
    return selection


def _parse_registry_credential_selections(
    values: list[str],
    console: Console,
) -> dict[str, str]:
    """Parse repeated ``--registry-secret HOST=NAME_OR_ID`` flags.

    The mapping travels as a sibling of ``config`` on hosted submit and pins
    which stored pull secret authenticates each host's private images.
    """
    from harbor.hosted.registry_credentials import GAR_HOST_RE

    selections: dict[str, str] = {}
    for raw in values:
        host, sep, selector = raw.partition("=")
        host, selector = host.strip(), selector.strip()
        if not sep or not host or not selector:
            console.print(
                "[red]Error:[/red] --registry-secret entries look like "
                "HOST=NAME_OR_ID (e.g. us-east1-docker.pkg.dev=my-puller)."
            )
            raise SystemExit(1)
        if not GAR_HOST_RE.match(host):
            console.print(
                f"[red]Error:[/red] --registry-secret host {host!r} must be "
                "a Google Artifact Registry docker host like "
                "us-east1-docker.pkg.dev."
            )
            raise SystemExit(1)
        if host in selections:
            console.print(
                f"[red]Error:[/red] --registry-secret given twice for {host}."
            )
            raise SystemExit(1)
        selections[host] = selector
    return selections


def _route_sensitive_env_to_credentials(config) -> dict[str, str]:
    """Pull secret-sounding env vars out of the config into job credentials.

    Hosted launch persists agent/environment/verifier ``env`` verbatim in the
    stored job config, so plaintext secrets must never live there. Any env key
    that looks sensitive (``OPENAI_API_KEY``, ``*_TOKEN``, ...) is resolved and
    moved into the encrypted, job-scoped credentials channel instead, then
    stripped from the config. This lets ``--ae OPENAI_API_KEY=...`` "just work"
    without the caller having to know about ``--env-file``.
    """
    # ENV_VAR_RE is the edge contract for a credential env var name; sensitive
    # keys that don't fit it can't be routed, so they fall through to the
    # validator's secret-key rejection instead.
    from harbor.hosted.api import ENV_VAR_RE
    from harbor.utils.env import is_sensitive_env_key, resolve_env_vars

    routed: dict[str, str] = {}

    def _drain(env: dict[str, str]) -> None:
        sensitive = {
            key: value
            for key, value in env.items()
            if is_sensitive_env_key(key) and ENV_VAR_RE.fullmatch(key)
        }
        if not sensitive:
            return
        # Resolve ${VAR} templates now: a credential must carry a concrete
        # value, and load_dotenv has already populated the host env.
        for key, value in resolve_env_vars(sensitive).items():
            routed[key] = value
        for key in sensitive:
            del env[key]

    for agent in config.agents:
        _drain(agent.env)
    _drain(config.environment.env)
    _drain(config.verifier.env)
    return routed


async def _gather_preflight_warnings(
    config,
    job_secrets: dict[str, str] | None,
    registry_credentials: dict[str, str] | None = None,
    organization: str | None = None,
) -> "PreflightWarnings | None":
    """Collect advisory warnings for a hosted launch that looks misconfigured.

    Prefers the hosted preflight API, which also covers task-declared env
    requirements, per-agent secret selections, and the selected organization's
    active secrets. Returns None when the advisory API check is unavailable;
    it never fails the launch on its own. ``--registry-secret`` selections are
    checked against stored credentials independently.
    """
    from dataclasses import replace

    from harbor.hosted.preflight import (
        PreflightWarnings,
        format_preflight_warnings,
        registry_credential_warnings,
        run_hosted_preflight,
    )

    registry_lines: list[str] = []
    if registry_credentials:
        try:
            registry_lines = await registry_credential_warnings(registry_credentials)
        except Exception as exc:
            logger.debug("Skipping registry secret preflight: %s", exc)

    declared = set(job_secrets or {})
    warnings: PreflightWarnings | None = None
    try:
        report = await run_hosted_preflight(config, declared, organization=organization)
        warnings = format_preflight_warnings(report)
    except Exception as exc:
        logger.debug("Skipping unavailable hosted launch preflight: %s", exc)

    if not registry_lines:
        return warnings
    if warnings is None:
        return PreflightWarnings(
            agent_lines=[], task_lines=[], registry_lines=registry_lines
        )
    return replace(warnings, registry_lines=registry_lines)


def _prompt_launch_concurrency(config, console: Console) -> None:
    """Ask for n_concurrent_trials when the config never set it.

    The hosted scheduler runs at most n_concurrent_trials of a job's trials
    at a time, so silently inheriting the default surprises anyone launching
    a large job. The chosen value (Enter keeps the default) is assigned to
    the config, making the submitted value explicit.
    """
    default = config.n_concurrent_trials
    console.print(
        "\n[yellow]n_concurrent_trials is not set[/yellow] — hosted jobs run "
        f"at most that many trials at a time (default {default}). Set it in "
        "your job config or pass --n-concurrent to skip this prompt."
    )
    while True:
        response = console.input(
            f"Run with how many concurrent trials? [{default}]: "
        ).strip()
        if not response:
            config.n_concurrent_trials = default
            return
        try:
            value = int(response)
        except ValueError:
            value = 0
        if value < 1:
            console.print("[red]Enter a whole number of at least 1.[/red]")
            continue
        config.n_concurrent_trials = value
        return


def _describe_launch_trials(config) -> str:
    n_agents = max(len(config.agents), 1)
    if config.tasks and not config.datasets:
        total = config.n_attempts * len(config.tasks) * n_agents
        return (
            f"{total} ({len(config.tasks)} task(s) × {n_agents} agent(s) × "
            f"{config.n_attempts} attempt(s))"
        )
    sources = []
    if config.datasets:
        sources.append(f"tasks from {len(config.datasets)} dataset(s)")
    if config.tasks:
        sources.append(f"{len(config.tasks)} task(s)")
    source = " + ".join(sources) if sources else "no tasks"
    return f"{source} × {n_agents} agent(s) × {config.n_attempts} attempt(s)"


def _print_launch_summary(
    console: Console,
    config,
    job_secrets: dict[str, str] | None,
    credential_sources: list[str] | None,
    warnings: "PreflightWarnings | None",
    registry_credentials: dict[str, str] | None = None,
    organization: str | None = None,
    regrade: HostedRegradeSource | None = None,
) -> bool:
    """Print the pre-launch summary. Returns True when warnings were shown."""
    console.print("\n[bold]Hosted launch[/bold]")
    console.print(f"  Job:         {config.job_name}")
    console.print(f"  Owner:       {organization or 'personal organization'}")
    trials = (
        f"{len(regrade.source_trial_ids)} selected trial(s), verifier only"
        if regrade
        else _describe_launch_trials(config)
    )
    console.print(f"  Trials:      {trials}")
    if "n_concurrent_trials" in config.model_fields_set:
        console.print(f"  Concurrency: {config.n_concurrent_trials} trials at a time")
    else:
        console.print(
            f"  Concurrency: [yellow]{config.n_concurrent_trials} trials at a "
            "time (default — set n_concurrent_trials in your config or pass "
            "--n-concurrent to change)[/yellow]"
        )
    if config.credential_mode is not None:
        # Worth stating plainly: direct hands the credential to the agent
        # rather than proxying it, so where the key ends up differs.
        detail = (
            "given to the agent, native provider endpoint"
            if config.credential_mode is CredentialMode.DIRECT
            else "proxied through Harbor Hub"
        )
        if regrade:
            detail = "available to the verifier"
        console.print(f"  Credentials: {config.credential_mode.value} ({detail})")
    if job_secrets:
        origin = " and ".join(credential_sources or ["config env"])
        console.print(
            f"  Job secrets: {', '.join(job_secrets)} (from {origin}; "
            "encrypted, revoked when the job finishes)"
        )
    # A selection is per-agent, but the flag sets one for the whole job, so
    # collapse it when every agent agrees and list per agent when they differ.
    selections = {
        agent.name or "?": tuple(agent.secrets)
        for agent in config.agents
        if agent.secrets is not None
    }
    if selections and regrade is None:
        # Names resolve from the owning org's stored secrets or from this
        # launch's own job secrets, so the line names the selection rather
        # than claiming a source for it.
        distinct = set(selections.values())
        if len(distinct) == 1:
            names = ", ".join(next(iter(distinct)))
            console.print(f"  Agent secrets: {names or 'none selected'}")
        else:
            console.print("  Agent secrets:")
            for agent_name, names in selections.items():
                console.print(
                    f"    {agent_name}: {', '.join(names) or 'none selected'}"
                )
    if registry_credentials:
        pins = ", ".join(
            f"{host} → {selector}"
            for host, selector in sorted(registry_credentials.items())
        )
        console.print(f"  Registry:    {pins} (pinned pull secrets)")

    if not warnings:
        return False
    console.print(
        "\n[yellow]Warning:[/yellow] this launch looks like it is missing "
        "configuration:"
    )
    for line in [*warnings.agent_lines, *warnings.task_lines, *warnings.registry_lines]:
        console.print(line)
    if warnings.agent_lines or warnings.task_lines:
        console.print(
            "Add account-wide keys with [bold]harbor hub secrets add[/bold], or "
            "attach one to this job with [bold]--one-off-secret NAME[/bold] "
            "([bold]--env-file[/bold] for a whole file); secrets reach both "
            "the agent and task-declared environment/verifier env vars."
        )
    if warnings.registry_lines:
        console.print(
            "Store pull secrets with "
            "[bold]harbor hub secrets registry add[/bold]; the submit API rejects "
            "selections that do not match an active credential."
        )
    return True


def _discard_pending_stdin(console: Console) -> None:
    """Drop keystrokes typed while an interactive launch check was running."""
    if not sys.stdin.isatty():
        return

    try:
        import os
        import select

        fileno = sys.stdin.fileno()
        discarded = False
        while select.select([sys.stdin], [], [], 0)[0]:
            os.read(fileno, 4096)
            discarded = True
    except (ImportError, OSError, ValueError):
        return
    if discarded:
        console.print(
            "[dim]Ignoring keystrokes entered while checks were running.[/dim]"
        )


def run_hosted_launch(
    *,
    config: HostedJobConfig,
    credential_mode: CredentialMode | None,
    org: str | None,
    stored_secret: list[str] | None,
    env_file: Path | None,
    one_off_secret: list[str] | None,
    registry_credential: list[str] | None,
    no_secrets: bool,
    yes: bool,
    dry_run: bool,
    console: Console,
    regrade: HostedRegradeSource | None = None,
    share_org: list[str] | None = None,
    share_user: list[str] | None = None,
) -> None:
    from harbor.auth.errors import AuthenticationError
    from harbor.hosted.submit import (
        HostedNotApprovedError,
        HostedQuotaExceededError,
        hosted_access_request_url,
        submit_hosted_job,
    )

    hosted_agents: list[HostedAgentConfig] = config.agents

    # The flag wins over a config file, matching every other launch flag.
    if credential_mode is not None:
        config.credential_mode = credential_mode
    organization = org if org is not None else config.organization

    try:
        configured_credentials = _resolve_config_job_secrets(config)
    except ValueError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise SystemExit(1) from None

    chose_no_secrets = {
        id(agent)
        for agent in hosted_agents
        if agent.secrets is not None and not agent.secrets
    }
    for agent in hosted_agents:
        if agent.secrets is None:
            agent.secrets = []

    if stored_secret:
        # Names join whatever the agent already selected: granting one org
        # secret must not drop the keys a config file scoped per agent.
        stored_secrets = _parse_stored_secret_names(stored_secret, console)
        for agent in hosted_agents:
            existing = agent.secrets or []
            agent.secrets = [
                *existing,
                *dict.fromkeys(name for name in stored_secrets if name not in existing),
            ]

    env_file_credentials = (
        _collect_launch_job_secrets(env_file, console) if env_file is not None else None
    )
    secret_credentials = (
        _parse_launch_secrets(one_off_secret, console) if one_off_secret else {}
    )
    # Auto-route secret-sounding env vars (e.g. from --ae) into the
    # encrypted credentials channel so they never persist in the config.
    routed_credentials = _route_sensitive_env_to_credentials(config)

    # Gateway mode grants a credential only if its name is in the agent's
    # selection, and that filter covers job-scoped credentials too — so a
    # supplied name that joins no selection is uploaded and then never reaches
    # an agent. Supplying a value is itself a request to use it, so union every
    # supplied name into every agent.
    supplied_names = [
        *secret_credentials,
        *(env_file_credentials or {}),
        *routed_credentials,
    ]
    if supplied_names:
        for agent in hosted_agents:
            existing = agent.secrets or []
            agent.secrets = [
                *existing,
                *dict.fromkeys(name for name in supplied_names if name not in existing),
            ]

    # Nothing derives a credential from the model provider any more, so an
    # agent that selected nothing runs uncredentialed. Reject that rather than
    # burning a launch, unless the caller said they meant it. `oracle` and `nop`
    # drive no model and never need one.
    uncredentialed = [
        agent
        for agent in hosted_agents
        if not agent.secrets
        and agent.name not in _NO_CREDENTIAL_AGENTS
        and id(agent) not in chose_no_secrets
    ]
    if no_secrets:
        selected = sorted(
            {name for agent in hosted_agents for name in (agent.secrets or [])}
        )
        if selected:
            console.print(
                "[red]Error:[/red] --no-secrets launches with no credentials, but "
                f"this job selects {', '.join(selected)}. Drop --no-secrets, or "
                "remove the credential flags and config `secrets` entries."
            )
            raise SystemExit(1)
    elif uncredentialed:
        names = ", ".join(
            sorted({agent.name or "<custom>" for agent in uncredentialed})
        )
        console.print(
            f"[red]Error:[/red] no credentials selected for {names}. A hosted "
            "launch injects only the secrets it names, so this job would run "
            "uncredentialed.\n"
            "  Name a secret stored in the owning org with --stored-secret NAME, "
            "supply one for this job with --one-off-secret NAME, or set `secrets` "
            "on the agent in your config.\n"
            "  To launch with no credentials on purpose, pass --no-secrets."
        )
        raise SystemExit(1)

    # Lowest to highest precedence on a name collision: the config env is
    # swept up implicitly, --env-file is bulk, --one-off-secret is one deliberate
    # name typed at the command line.
    job_secrets = {
        **configured_credentials,
        **routed_credentials,
        **(env_file_credentials or {}),
        **secret_credentials,
    } or None
    credential_sources = [
        source
        for source, values in (
            ("hosted config", configured_credentials),
            ("config env", routed_credentials),
            (str(env_file), env_file_credentials),
            ("--one-off-secret", secret_credentials),
        )
        if values
    ]

    registry_credentials: dict[str, str] | None = None
    if registry_credential:
        registry_credentials = _parse_registry_credential_selections(
            registry_credential, console
        )

    # A dry run commits nothing, so neither confirmation gate applies: the
    # warnings it would gate on are exactly what the caller asked to see.
    interactive = not yes and not dry_run and sys.stdin.isatty()
    if interactive and "n_concurrent_trials" not in config.model_fields_set:
        _prompt_launch_concurrency(config, console)

    async def _submit_hosted():
        from harbor.cli.job_sharing import (
            confirm_non_member_org_shares,
            normalize_share_values,
        )
        from harbor.hosted.submit import HostedSubmitResult
        from harbor.models.task.id import LocalTaskId
        from harbor.publisher.publisher import Publisher
        from harbor.upload.db_client import UploadDB

        share_orgs = normalize_share_values(share_org)
        share_users = normalize_share_values(share_user)
        confirm_non_member_orgs = False
        if not dry_run and (share_orgs or share_users):
            confirm_non_member_orgs = await confirm_non_member_org_shares(
                share_orgs, yes=yes
            )

        launch_config = config.model_copy(deep=True)
        launch_config.datasets = []
        for dataset in config.datasets:
            if dataset.is_local():
                launch_config.tasks.extend(
                    await dataset.get_task_configs(config.verifier.disable)
                )
            else:
                launch_config.datasets.append(dataset.model_copy(deep=True))
        local_tasks = [
            task
            for task in launch_config.tasks
            if isinstance(task.get_task_id(), LocalTaskId)
        ]
        local = bool(local_tasks) or any(d.is_local() for d in config.datasets)
        launch_config.extra_instructions = [
            *(
                path.read_text(encoding="utf-8")
                for path in config.extra_instruction_paths
            ),
            *config.extra_instructions,
        ]
        launch_config.extra_instruction_paths = []
        if local and not yes and not dry_run and not interactive:
            raise ValueError(
                "Local task uploads require --yes without an interactive terminal."
            )
        if dry_run:
            from harbor.cli.config_validation import (
                print_validation_report,
                validate_job_config,
                validate_local_sources,
            )

            print_validation_report(await validate_job_config(config, hub=True))
            if local:
                print_validation_report(await validate_local_sources(launch_config))

        # Preflight shares this coroutine (and event loop) with the submit
        # because the Supabase auth client is loop-bound; see the comment
        # above about cross-loop reuse.
        console.print("[dim]Checking hosted launch readiness...[/dim]")
        with console.status(
            "[bold]Checking hosted launch readiness...[/bold]",
            spinner="dots",
        ):
            warnings = await _gather_preflight_warnings(
                launch_config,
                job_secrets,
                registry_credentials,
                organization,
            )
        has_warnings = _print_launch_summary(
            console,
            config,
            job_secrets,
            credential_sources,
            warnings,
            registry_credentials,
            organization,
            regrade,
        )
        if interactive:
            _discard_pending_stdin(console)
            # A clean summary defaults to launching; one with warnings
            # defaults to aborting (preserving the old missing-keys gate).
            default_yes = not has_warnings
            prompt = "Launch? (Y/n): " if default_yes else "Launch? (y/N): "
            response = console.input(f"[yellow]{prompt}[/yellow]").strip().lower()
            accepted = response in ("y", "yes") or (default_yes and response == "")
            if not accepted:
                raise SystemExit(1)
        elif has_warnings and not yes and not dry_run:
            # Same defaults without a TTY to ask: a clean summary launches,
            # one with warnings aborts unless --yes explicitly overrides.
            console.print(
                "[red]Aborting launch:[/red] the summary above has warnings "
                "and there is no terminal to confirm them. Re-run with "
                "--yes to launch anyway."
            )
            raise SystemExit(2)
        if local and dry_run:
            console.print(
                "[dim]Local tasks checked without uploading; hosted source validation runs after publishing.[/dim]"
            )
            return HostedSubmitResult(
                job_id=None,
                job_name=config.job_name,
                viewer_url=None,
                n_trials=(
                    len(regrade.source_trial_ids)
                    if regrade
                    else (
                        len(launch_config.tasks)
                        * len(config.agents)
                        * config.n_attempts
                        if not launch_config.datasets
                        else None
                    )
                ),
                owner_org=organization,
            )
        if local:
            console.print("[dim]Publishing temporary private task packages...[/dim]")
            batch = await Publisher().publish_tasks(
                [task.path for task in local_tasks if task.path is not None],
                temporary=True,
                organization=organization,
            )
            for task, result in zip(local_tasks, batch.results, strict=True):
                task.path = None
                task.name = result.name
                task.ref = f"sha256:{result.content_hash}"
        action = "Validating hosted launch" if dry_run else "Submitting hosted launch"
        console.print(f"[dim]{action}...[/dim]")
        with console.status(f"[bold]{action}...[/bold]", spinner="dots"):
            result = await submit_hosted_job(
                launch_config,
                job_secrets=job_secrets,
                registry_credentials=registry_credentials,
                organization=organization,
                dry_run=dry_run,
                regrade=regrade,
            )

        if not dry_run and result.job_id is not None and (share_orgs or share_users):
            try:
                await UploadDB().add_job_shares(
                    job_id=result.job_id,
                    org_names=share_orgs,
                    usernames=share_users,
                    confirm_non_member_orgs=confirm_non_member_orgs,
                )
            except Exception as exc:
                raise RuntimeError(
                    f"Job {result.job_id} was launched, but sharing failed: {exc}. "
                    f"View at {result.viewer_url}. "
                    "Retry sharing with `harbor job share`; do not relaunch the job."
                ) from exc
        return result

    try:
        result = run_async(_submit_hosted())
    except HostedQuotaExceededError as exc:
        console.print(f"[red]Launch quota exceeded:[/red] {exc}")
        raise SystemExit(2) from None
    except HostedNotApprovedError as exc:
        console.print(
            "[yellow]Hosted rollouts are an alpha feature.[/yellow] "
            "To request access, fill out this google form:"
        )
        console.print(f"  [bold]{hosted_access_request_url(exc.user_id)}[/bold]")
        raise SystemExit(2) from None
    except (AuthenticationError, RuntimeError, ValueError) as exc:
        console.print(f"[red]{exc}[/red]")
        raise SystemExit(1) from None

    if dry_run:
        console.print(
            f"[green]Dry run OK[/green] — [bold]{result.job_name}[/bold] "
            "validated; nothing was queued."
        )
        if result.owner_org:
            console.print(f"Owner org: {result.owner_org}")
        if result.n_trials is not None:
            console.print(f"Would queue: {result.n_trials} trial(s)")
        console.print("Re-run without --dry-run to launch.")
        return

    console.print(
        f"[green]Launched job[/green] [bold]{result.job_id}[/bold] ({result.job_name})"
    )
    if result.n_trials is not None:
        console.print(f"Queued trials: {result.n_trials}")
    console.print(f"View at {result.viewer_url}")
    return


async def prepare_hosted_job_regrade(
    job_id: UUID,
    tasks: list[TaskConfig],
    datasets: list[DatasetConfig],
) -> tuple[HostedRegradeSource, list[TaskConfig]]:
    """Reuse local job inputs and Hub download selection without source downloads."""
    from harbor.job_plan import JobPlan
    from harbor.upload.db_client import UploadDB

    # This is the same paginated, retry-ranked selection as job download.
    rows = await UploadDB().list_trial_downloads_for_job(job_id)
    trial_ids = [row.id for row in rows if row.archive_path]
    if not trial_ids:
        raise ValueError("No recorded trials found to regrade in this job.")
    selection = HostedRegradeSource(source_job_id=job_id, source_trial_ids=trial_ids)
    resolved = await JobPlan.resolve_task_configs(
        JobConfig(tasks=tasks, datasets=datasets)
    )
    # Overlapping selectors may resolve the exact same task more than once.
    resolved = list({task.get_task_id(): task for task in resolved}.values())
    git_tasks = [task for task in resolved if task.is_git_task()]
    if git_tasks:
        # Legacy datasets contain Git tasks. Materialize their pinned definitions
        # and reuse the same temporary publication as an explicit local path.
        downloaded = await JobPlan.cache_tasks(git_tasks)
        resolved = [
            TaskConfig(path=downloaded[task.get_task_id()].path, source=task.source)
            if task.is_git_task()
            else task
            for task in resolved
        ]
    return selection, resolved


def run_hosted_regrade(
    *,
    source: HostedRegradeSource,
    tasks: list[TaskConfig],
    org: str | None,
    stored_secret: list[str] | None,
    one_off_secret: list[str] | None,
    registry_credential: list[str] | None,
    use_static_ip: bool,
    verifier_env: list[str] | None,
    job_name: str | None,
    n_concurrent_trials: int | None,
    yes: bool,
    dry_run: bool,
    console: Console,
) -> None:
    """Share verifier-only launch construction between job and trial regrade."""
    from harbor.trial.regrade import check_task_regradable

    if not org:
        raise ValueError("--launch regrade requires --org matching the source trial.")
    if not tasks:
        raise ValueError("Provide verifier tasks with -p/--task-path or -t/--task.")
    for task in tasks:
        if task.path is not None:
            if not (task.path / "task.toml").is_file():
                raise ValueError("Hosted trial regrade requires one task directory.")
            # A job's verifier collection may contain unrelated tasks. Only
            # matched tasks must be regradable, as in local job regrade.
            if source.source_job_id is None:
                if reason := check_task_regradable(task.path):
                    raise ValueError(reason)
    config = HostedJobConfig(
        tasks=tasks,
        agents=[HostedAgentConfig(name="nop", secrets=[])],
        credential_mode=CredentialMode.DIRECT,
        static_outbound_ip=True if use_static_ip else None,
        n_attempts=1,
        verifier=VerifierConfig(env=parse_env_vars(verifier_env or [])),
    )
    if job_name is not None:
        config.job_name = job_name
    if n_concurrent_trials is not None:
        if n_concurrent_trials < 1:
            raise ValueError("--n-concurrent must be at least 1.")
        config.n_concurrent_trials = n_concurrent_trials
    run_hosted_launch(
        config=config,
        credential_mode=CredentialMode.DIRECT,
        org=org,
        stored_secret=stored_secret,
        one_off_secret=one_off_secret,
        env_file=None,
        registry_credential=registry_credential,
        no_secrets=False,
        yes=yes,
        dry_run=dry_run,
        console=console,
        regrade=source,
    )

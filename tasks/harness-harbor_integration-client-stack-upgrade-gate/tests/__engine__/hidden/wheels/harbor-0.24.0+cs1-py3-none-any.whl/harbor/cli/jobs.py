import json
from copy import deepcopy
from functools import wraps
from inspect import signature
import logging
import os
import shutil
import signal
from datetime import datetime
from pathlib import Path
from typing import Annotated, Any
from uuid import UUID

from click import get_current_context
from dotenv import dotenv_values, load_dotenv
from pydantic import ValidationError
from rich.console import Console
from rich.table import Table
from typer import Argument, Option, Typer, confirm
from yaml import YAMLError

from harbor.cli.config_init import job_init, job_schema
from harbor.cli.config_sources import load_config_source, merge_config
from harbor.cli.job_plugins import plugin_configs_from_cli
from harbor.cli.notifications import show_registry_hint_if_first_run
from harbor.cli.utils import (
    DATASET_RESOLUTION_ERRORS,
    abort_dataset_resolution,
    load_mcp_servers,
    parse_env_vars,
    parse_kwargs,
    parse_tpu_spec,
    resolve_environment_spec,
    run_async,
    warn_deprecated_flag,
)
from harbor.hosted.config import CredentialMode, HostedJobConfig
from harbor.models.agent.name import AgentName
from harbor.models.bridge import BridgeKind
from harbor.models.environment_type import EnvironmentType
from harbor.models.job.config import (
    DatasetConfig,
    migrate_legacy_job_config,
    JobConfig,
)
from harbor.models.job.result import JobStats
from harbor.models.task.task import Task
from harbor.models.trial.config import (
    AgentConfig,
    EnvironmentConfig,
    ResourceMode,
    TaskConfig,
)
from harbor.models.trial.paths import TrialPaths
from harbor.models.trial.result import TrialResult

jobs_app = Typer(
    no_args_is_help=True, context_settings={"help_option_names": ["-h", "--help"]}
)
console = Console()
logger = logging.getLogger(__name__)

_AGENT_METAVAR = (
    "[" + "|".join(sorted(AgentName.values() - {AgentName.ACP.value})) + "|acp:<agent>]"
)
_ENV_METAVAR = "[" + "|".join(sorted(e.value for e in EnvironmentType)) + "]"

_APPEND_CONFIG_PATHS = frozenset(
    {
        ("agents",),
        ("datasets",),
        ("tasks",),
        ("metrics",),
        ("extra_instruction_paths",),
        ("extra_instructions",),
        ("retry", "include_exceptions"),
        ("retry", "exclude_exceptions"),
        ("environment", "extra_docker_compose"),
        ("environment", "extra_allowed_hosts"),
        ("verifier", "include_logs"),
        ("verifier", "exclude_logs"),
        ("user_agent", "skills"),
        ("user_agent", "extra_allowed_hosts"),
        ("user_agent", "include_logs"),
        ("user_agent", "exclude_logs"),
    }
)
_EXCLUSIVE_CONFIG_GROUPS: dict[tuple[str, ...], tuple[frozenset[str], ...]] = {
    ("environment",): (frozenset({"type"}), frozenset({"import_path"})),
    ("user_agent",): (frozenset({"name"}), frozenset({"import_path"})),
}


def _validate_bridge_target_agents(agents: list[AgentConfig], kind: BridgeKind) -> None:
    """Fail fast when built-in targets do not support a bridge.

    Only named built-in agents can be checked here; import-path and ACP
    registry agents are validated at trial start instead.
    """
    from harbor.agents.factory import AgentFactory

    for agent in agents:
        if agent.name is None or agent.name not in AgentName.values():
            continue
        agent_cls = AgentFactory.get_agent_class(AgentName(agent.name))
        if kind not in agent_cls.capabilities.bridges:
            raise ValueError(
                f"Agent '{agent.name}' does not support the '{kind}' bridge."
            )


def _run_preflight(config: JobConfig) -> None:
    from harbor.agents.factory import AgentFactory
    from harbor.environments.factory import EnvironmentFactory

    EnvironmentFactory.run_preflight(
        type=config.environment.type,
        import_path=config.environment.import_path,
    )
    try:
        for agent in config.agents:
            AgentFactory.run_preflight(agent)
        if config.user_agent is not None:
            AgentFactory.run_preflight(config.user_agent)
    except ValueError as exc:
        console.print(str(exc), style="red", markup=False, highlight=False)
        raise SystemExit(1) from None


def _confirm_host_env_access(
    job,
    console: Console,
    *,
    explicit_env_file_keys: set[str] | None = None,
    skip_confirm: bool = False,
) -> None:
    import tomllib

    from pydantic import ValidationError

    from harbor.models.task.config import TaskConfig as TaskDefinitionConfig
    from harbor.models.task.paths import TaskPaths
    from harbor.utils.env import get_required_host_vars

    is_oracle = any(a.name == AgentName.ORACLE.value for a in job.config.agents)
    explicit_env_file_keys = explicit_env_file_keys or set()
    explicit_job_environment_keys = set(job.config.environment.env)
    explicit_job_verifier_keys = set(job.config.verifier.env)
    sections: dict[str, list[tuple[str, str | None]]] = {}

    for task_config in job._task_configs:
        try:
            local_path = task_config.get_local_path()
        except ValueError:
            continue
        if not local_path.exists():
            continue
        try:
            task_config_model = TaskDefinitionConfig.model_validate_toml(
                TaskPaths(local_path).config_path.read_text()
            )
        except (OSError, tomllib.TOMLDecodeError, ValidationError):
            continue

        env_sections = [
            ("environment", task_config_model.environment.env),
            ("verifier", task_config_model.verifier.env),
        ]
        if is_oracle:
            env_sections.append(("solution", task_config_model.solution.env))

        for section_name, env_dict in env_sections:
            filtered_env_dict = env_dict
            if section_name == "environment" and explicit_job_environment_keys:
                filtered_env_dict = {
                    key: value
                    for key, value in env_dict.items()
                    if key not in explicit_job_environment_keys
                }
            elif section_name == "verifier" and explicit_job_verifier_keys:
                filtered_env_dict = {
                    key: value
                    for key, value in env_dict.items()
                    if key not in explicit_job_verifier_keys
                }

            required = [
                item
                for item in get_required_host_vars(filtered_env_dict)
                if item[0] not in explicit_env_file_keys
            ]
            if required:
                key = f"[{section_name}.env]"
                existing = sections.get(key, [])
                for item in required:
                    if item not in existing:
                        existing.append(item)
                if existing:
                    sections[key] = existing

    if not sections:
        return

    missing = []
    for section, vars_list in sections.items():
        for var_name, default in vars_list:
            if default is None and var_name not in os.environ:
                missing.append((section, var_name))

    if missing:
        table = Table(
            title="Missing Environment Variables",
            title_style="bold red",
            show_header=True,
            header_style="bold",
            padding=(0, 2),
            show_edge=False,
            show_lines=False,
        )
        table.add_column("Variable", style="cyan")
        table.add_column("Phase", style="dim")

        for section, var_name in missing:
            escaped = section.replace("[", "\\[")
            table.add_row(var_name, escaped)

        console.print()
        console.print(table)
        console.print(
            "\n[yellow]Export them in your shell or pass --env-file.[/yellow]"
        )
        raise SystemExit(1)

    if skip_confirm:
        return

    table = Table(
        title="Environment Variables",
        title_style="bold",
        show_header=True,
        header_style="bold",
        padding=(0, 2),
        show_edge=False,
        show_lines=False,
    )
    table.add_column("Variable", style="cyan")
    table.add_column("Phase", style="dim")

    for section, vars_list in sections.items():
        escaped = section.replace("[", "\\[")
        for var_name, default in vars_list:
            table.add_row(var_name, escaped)

    console.print()
    console.print(table)
    console.print()

    response = console.input(
        "Tasks in this run will load these from your environment. [yellow]Proceed? (Y/n):[/yellow] "
    )
    if response.strip().lower() in ("n", "no"):
        raise SystemExit(0)


def _format_duration(started_at: datetime | None, finished_at: datetime | None) -> str:
    if started_at is None or finished_at is None:
        return "unknown"

    total_seconds = max(0, int((finished_at - started_at).total_seconds()))
    minutes, seconds = divmod(total_seconds, 60)
    hours, minutes = divmod(minutes, 60)

    if hours > 0:
        return f"{hours}h {minutes}m {seconds}s"
    if minutes > 0:
        return f"{minutes}m {seconds}s"
    return f"{seconds}s"


def _format_group_title(evals_key: str, job_result) -> str:
    parts = evals_key.split("__")
    if len(parts) == 3:
        agent_name, model_name, dataset_name = parts
    else:
        agent_name, dataset_name = parts
        model_name = None

    for trial_result in job_result.trial_results:
        trial_evals_key = JobStats.format_agent_evals_key(
            trial_result.agent_info.name,
            (
                trial_result.agent_info.model_info.name
                if trial_result.agent_info.model_info
                else None
            ),
            trial_result.source or "adhoc",
        )
        if trial_evals_key != evals_key:
            continue

        agent_name = trial_result.agent_info.name
        model_name = (
            trial_result.agent_info.model_info.name
            if trial_result.agent_info.model_info
            else model_name
        )
        dataset_name = trial_result.source or dataset_name
        break

    title_parts = [dataset_name, agent_name]
    if model_name:
        title_parts.append(model_name)
    return " • ".join(title_parts)


def print_job_results_tables(job_result) -> None:
    for evals_key, dataset_stats in job_result.stats.evals.items():
        console.print(f"[bold]{_format_group_title(evals_key, job_result)}[/bold]")

        summary_table = Table(show_header=True)
        summary_table.add_column("Trials", justify="right")
        summary_table.add_column("Exceptions", justify="right")

        summary_row = [str(dataset_stats.n_trials), str(dataset_stats.n_errors)]
        if dataset_stats.metrics:
            for i, metric in enumerate(dataset_stats.metrics):
                for key, value in metric.items():
                    metric_label = (
                        f"Metric {i + 1}: {key}"
                        if len(dataset_stats.metrics) > 1
                        else key
                    )
                    summary_table.add_column(metric_label.title(), justify="right")
                    if isinstance(value, float):
                        summary_row.append(f"{value:.3f}")
                    else:
                        summary_row.append(str(value))

        if dataset_stats.pass_at_k:
            for k, value in sorted(dataset_stats.pass_at_k.items()):
                summary_table.add_column(f"Pass@{k}", justify="right")
                summary_row.append(f"{value:.3f}")

        summary_table.add_row(*summary_row)
        console.print(summary_table)

        if dataset_stats.reward_stats:
            reward_table = Table(show_header=True)
            reward_table.add_column("Reward")
            reward_table.add_column("Count", justify="right")
            for reward_key, reward_values in dataset_stats.reward_stats.items():
                for reward_value, trial_names in reward_values.items():
                    count = len(trial_names)
                    reward_table.add_row(str(reward_value), str(count))
            console.print()
            console.print(reward_table)

        if dataset_stats.exception_stats:
            exception_table = Table(show_header=True)
            exception_table.add_column("Exception")
            exception_table.add_column("Count", justify="right")
            for (
                exception_type,
                trial_names,
            ) in dataset_stats.exception_stats.items():
                count = len(trial_names)
                exception_table.add_row(exception_type, str(count))
            console.print()
            console.print(exception_table)

        console.print()


def _handle_sigterm(_signum, _frame):
    raise KeyboardInterrupt


def build_job_config(
    config_path: Annotated[
        list[str] | None,
        Option(
            "-c",
            "--config",
            help="YAML/JSON JobConfig file or GitHub URL. Repeatable; later configs "
            "override earlier ones. Additive lists append; [] clears them. "
            "Schema: harbor job schema.",
            rich_help_panel="Config",
            show_default=False,
        ),
    ] = None,
    diff_sources: Annotated[
        list[str] | None,
        Option(
            "--diff",
            help="Source job directory or Harbor Hub job UUID to compare against. "
            "Can be used multiple times. Prints a reuse/regrade/rerun preview "
            "before running a job.",
            rich_help_panel="Config",
            show_default=False,
        ),
    ] = None,
    print_config: Annotated[
        bool,
        Option(
            "--print-config",
            help="Print the resolved JobConfig JSON and exit.",
            rich_help_panel="Config",
            show_default=False,
        ),
    ] = False,
    job_name: Annotated[
        str | None,
        Option(
            "--job-name",
            help="Name of the job (default: timestamp)",
            rich_help_panel="Job Settings",
            show_default=False,
        ),
    ] = None,
    jobs_dir: Annotated[
        Path | None,
        Option(
            "-o",
            "--jobs-dir",
            help=f"Directory to store job results (default: {
                JobConfig.model_fields['jobs_dir'].default
            })",
            rich_help_panel="Job Settings",
            show_default=False,
        ),
    ] = None,
    n_attempts: Annotated[
        int | None,
        Option(
            "-k",
            "--n-attempts",
            help=f"Number of attempts per trial (default: {
                JobConfig.model_fields['n_attempts'].default
            })",
            rich_help_panel="Job Settings",
            show_default=False,
        ),
    ] = None,
    timeout_multiplier: Annotated[
        float | None,
        Option(
            "--timeout-multiplier",
            help=f"Multiplier for task timeouts (default: {
                JobConfig.model_fields['timeout_multiplier'].default
            })",
            rich_help_panel="Job Settings",
            show_default=False,
        ),
    ] = None,
    agent_timeout_multiplier: Annotated[
        float | None,
        Option(
            "--agent-timeout-multiplier",
            help="Multiplier for agent execution timeout (overrides "
            "--timeout-multiplier)",
            rich_help_panel="Job Settings",
            show_default=False,
        ),
    ] = None,
    verifier_timeout_multiplier: Annotated[
        float | None,
        Option(
            "--verifier-timeout-multiplier",
            help="Multiplier for verifier timeout (overrides --timeout-multiplier)",
            rich_help_panel="Job Settings",
            show_default=False,
        ),
    ] = None,
    agent_setup_timeout_multiplier: Annotated[
        float | None,
        Option(
            "--agent-setup-timeout-multiplier",
            help="Multiplier for agent setup timeout (overrides --timeout-multiplier)",
            rich_help_panel="Job Settings",
            show_default=False,
        ),
    ] = None,
    environment_build_timeout_multiplier: Annotated[
        float | None,
        Option(
            "--environment-build-timeout-multiplier",
            help="Multiplier for environment build timeout (overrides "
            "--timeout-multiplier)",
            rich_help_panel="Job Settings",
            show_default=False,
        ),
    ] = None,
    quiet: Annotated[
        bool,
        Option(
            "-q",
            "--quiet",
            "--silent",
            help="Suppress individual trial progress displays",
            rich_help_panel="Job Settings",
            show_default=False,
        ),
    ] = False,
    debug: Annotated[
        bool,
        Option(
            "--debug",
            help="Enable debug logging",
            rich_help_panel="Job Settings",
            show_default=False,
        ),
    ] = False,
    n_concurrent_trials: Annotated[
        int | None,
        Option(
            "-n",
            "--n-concurrent",
            help=f"Number of concurrent trials to run (default: {
                JobConfig.model_fields['n_concurrent_trials'].default
            })",
            rich_help_panel="Job Settings",
            show_default=False,
        ),
    ] = None,
    n_concurrent_agents: Annotated[
        int | None,
        Option(
            "--n-concurrent-agents",
            min=1,
            help=(
                "Per-agent execution concurrency cap, at most --n-concurrent. Local "
                "only; incompatible with --launch. Default: unset."
            ),
            rich_help_panel="Job Settings",
            show_default=False,
        ),
    ] = None,
    max_retries: Annotated[
        int | None,
        Option(
            "-r",
            "--max-retries",
            help="Maximum number of retry attempts (default: 0)",
            rich_help_panel="Job Settings",
            show_default=False,
        ),
    ] = None,
    retry_include_exceptions: Annotated[
        list[str] | None,
        Option(
            "--retry-include",
            help="Exception types to retry on. If not specified, all exceptions except "
            "those in --retry-exclude are retried (can be used multiple times)",
            rich_help_panel="Job Settings",
            show_default=False,
        ),
    ] = None,
    retry_exclude_exceptions: Annotated[
        list[str] | None,
        Option(
            "--retry-exclude",
            help="Exception types to NOT retry on (can be used multiple times)",
            rich_help_panel="Job Settings",
            show_default=False,
        ),
    ] = None,
    agent_name: Annotated[
        str | None,
        Option(
            "-a",
            "--agent",
            metavar=_AGENT_METAVAR,
            help=(
                "Agent to run, or a custom agent import path "
                "(module.path:ClassName). Also accepts an ACP registry "
                "shorthand (e.g. acp:opencode@1.3.9). "
                "Options: harbor agent schema <name>."
            ),
            rich_help_panel="Agent",
            show_default=False,
        ),
    ] = None,
    agent_import_path: Annotated[
        str | None,
        Option(
            "--agent-import-path",
            help="Deprecated: pass the import path to --agent instead.",
            rich_help_panel="Agent",
            show_default=False,
            hidden=True,
        ),
    ] = None,
    model_names: Annotated[
        list[str] | None,
        Option(
            "-m",
            "--model",
            help="Model name for the agent (can be used multiple times)",
            rich_help_panel="Agent",
            show_default=True,
        ),
    ] = None,
    agent_kwargs: Annotated[
        list[str] | None,
        Option(
            "--ak",
            "--agent-kwarg",
            help="Agent key=value option. Repeatable. See harbor agent schema <name>.",
            rich_help_panel="Agent",
            show_default=False,
        ),
    ] = None,
    effort: Annotated[
        str | None,
        Option(
            "--effort",
            help="Reasoning effort for the agent.",
            rich_help_panel="Agent",
            show_default=False,
        ),
    ] = None,
    allow_agent_hosts: Annotated[
        list[str] | None,
        Option(
            "--allow-agent-host",
            help="Allow hostname or IP/CIDR during agent execution only. Extends the "
            "agent allowlist. Repeatable.",
            rich_help_panel="Agent",
            show_default=False,
        ),
    ] = None,
    resume_trajectory: Annotated[
        bool | None,
        Option(
            "--resume-trajectory",
            help="Resume the previous step's native session in multi-step tasks. "
            "Requires agent resume support.",
            rich_help_panel="Agent",
            show_default=False,
        ),
    ] = None,
    load_trajectory: Annotated[
        str | None,
        Option(
            "--load-trajectory",
            help="Load a session for the first step: native .jsonl (same agent) or "
            "ATIF .json (supported agents). Later steps start fresh unless "
            "--resume-trajectory is set.",
            rich_help_panel="Agent",
            show_default=False,
        ),
    ] = None,
    agent_env: Annotated[
        list[str] | None,
        Option(
            "--ae",
            "--agent-env",
            help="Agent environment variable as KEY=VALUE. Repeatable.",
            rich_help_panel="Agent",
            show_default=False,
        ),
    ] = None,
    agent_include_logs: Annotated[
        list[str] | None,
        Option(
            "--agent-include-logs",
            help="Download matching agent logs (relative glob). Repeatable.",
            rich_help_panel="Agent",
            show_default=False,
            hidden=True,
        ),
    ] = None,
    agent_exclude_logs: Annotated[
        list[str] | None,
        Option(
            "--agent-exclude-logs",
            help="Skip matching agent logs (relative glob), after includes. "
            "Repeatable.",
            rich_help_panel="Agent",
            show_default=False,
            hidden=True,
        ),
    ] = None,
    mcp_config: Annotated[
        list[Path] | None,
        Option(
            "--mcp-config",
            help="Claude-style .mcp.json or Harbor MCP config file. Repeatable.",
            rich_help_panel="Agent",
            show_default=False,
        ),
    ] = None,
    skills: Annotated[
        list[str] | None,
        Option(
            "--skill",
            "--skills",
            help="Skill directory or git source: org/name[@ref] or URL. Repeatable.",
            rich_help_panel="Agent",
            show_default=False,
        ),
    ] = None,
    user_agent_name: Annotated[
        str | None,
        Option(
            "--user-agent",
            metavar=_AGENT_METAVAR,
            help="Agent that plays the simulated user in a multi-turn trial. "
            "The --agent becomes the ACP target it converses with.",
            rich_help_panel="Simulated User",
            show_default=False,
        ),
    ] = None,
    user_model: Annotated[
        str | None,
        Option(
            "--user-model",
            help="Model name for the simulated-user agent.",
            rich_help_panel="Simulated User",
            show_default=False,
        ),
    ] = None,
    user_agent_kwargs: Annotated[
        list[str] | None,
        Option(
            "--uk",
            "--user-agent-kwarg",
            help="Additional simulated-user agent kwarg in key=value format.",
            rich_help_panel="Simulated User",
            show_default=False,
        ),
    ] = None,
    user_persona_path: Annotated[
        Path | None,
        Option(
            "--user-persona-path",
            help="Persona text file for {{ persona }}. Default: built-in persona.",
            rich_help_panel="Simulated User",
            show_default=False,
        ),
    ] = None,
    user_prompt_template_path: Annotated[
        Path | None,
        Option(
            "--user-prompt-template-path",
            help="Jinja2 prompt file. Requires {{ instruction }} and {{ "
            "bridge_instructions }}; {{ persona }} is optional. Default: built-in "
            "template.",
            rich_help_panel="Simulated User",
            show_default=False,
        ),
    ] = None,
    bridge_kind: Annotated[
        BridgeKind | None,
        Option(
            "--bridge",
            help="Protocol bridge connecting the simulated user to the target.",
            rich_help_panel="Simulated User",
            show_default=False,
        ),
    ] = None,
    bridge_prompt_path: Annotated[
        Path | None,
        Option(
            "--bridge-prompt-path",
            help="Plain-text instructions teaching the user agent how to use the "
            "bridge.",
            rich_help_panel="Simulated User",
            show_default=False,
        ),
    ] = None,
    bridge_kwargs: Annotated[
        list[str] | None,
        Option(
            "--bk",
            "--bridge-kwarg",
            help="Additional bridge kwarg in key=value format.",
            rich_help_panel="Simulated User",
            show_default=False,
        ),
    ] = None,
    environment: Annotated[
        str | None,
        Option(
            "-e",
            "--env",
            metavar=_ENV_METAVAR,
            help=(
                f"Environment type (default: {EnvironmentType.DOCKER.value}) or a "
                "custom environment import path (module.path:ClassName)."
            ),
            rich_help_panel="Environment",
            show_default=False,
        ),
    ] = None,
    allow_environment_hosts: Annotated[
        list[str] | None,
        Option(
            "--allow-environment-host",
            help="Add hostname or IP/CIDR to the environment network baseline at "
            "startup. Repeatable.",
            rich_help_panel="Environment",
            show_default=False,
        ),
    ] = None,
    environment_import_path: Annotated[
        str | None,
        Option(
            "--environment-import-path",
            help="Deprecated: pass the import path to --env instead.",
            rich_help_panel="Environment",
            show_default=False,
            hidden=True,
        ),
    ] = None,
    environment_force_build: Annotated[
        bool | None,
        Option(
            "--force-build/--no-force-build",
            help=f"Whether to force rebuild the environment (default: {
                '--force-build'
                if EnvironmentConfig.model_fields['force_build'].default
                else '--no-force-build'
            })",
            rich_help_panel="Environment",
            show_default=False,
        ),
    ] = None,
    environment_delete: Annotated[
        bool | None,
        Option(
            "--delete/--no-delete",
            help=f"Whether to delete the environment after completion (default: {
                '--delete'
                if EnvironmentConfig.model_fields['delete'].default
                else '--no-delete'
            })",
            rich_help_panel="Environment",
            show_default=False,
        ),
    ] = None,
    stream: Annotated[
        bool | None,
        Option(
            "--stream/--no-stream",
            help="Sync the trajectory and enable browser VS Code over SSH.",
            rich_help_panel="Environment",
            show_default=False,
        ),
    ] = None,
    cpus: Annotated[
        ResourceMode | None,
        Option(
            "--cpus",
            help="Task CPU enforcement policy.",
            rich_help_panel="Environment",
            show_default=False,
        ),
    ] = None,
    memory: Annotated[
        ResourceMode | None,
        Option(
            "--memory",
            help="Task memory enforcement policy.",
            rich_help_panel="Environment",
            show_default=False,
        ),
    ] = None,
    override_cpus: Annotated[
        int | None,
        Option(
            "--override-cpus",
            help="Override the number of CPUs for the environment",
            rich_help_panel="Environment",
            show_default=False,
        ),
    ] = None,
    override_memory_mb: Annotated[
        int | None,
        Option(
            "--override-memory-mb",
            help="Override the memory (in MB) for the environment",
            rich_help_panel="Environment",
            show_default=False,
        ),
    ] = None,
    override_storage_mb: Annotated[
        int | None,
        Option(
            "--override-storage-mb",
            help="Override the storage (in MB) for the environment",
            rich_help_panel="Environment",
            show_default=False,
        ),
    ] = None,
    override_gpus: Annotated[
        int | None,
        Option(
            "--override-gpus",
            help="Override the number of GPUs for the environment",
            rich_help_panel="Environment",
            show_default=False,
        ),
    ] = None,
    override_tpu: Annotated[
        str | None,
        Option(
            "--override-tpu",
            help=(
                "TPU TYPE=TOPOLOGY (e.g. v6e=2x4). One spec only: each pod gets one "
                "slice."
            ),
            rich_help_panel="Environment",
            show_default=False,
            hidden=True,
        ),
    ] = None,
    mounts: Annotated[
        str | None,
        Option(
            "--mounts",
            "--mounts-json",
            help="JSON array of volume mounts for the environment container "
            "(Docker Compose service volume format). --mounts-json is a "
            "deprecated alias.",
            rich_help_panel="Environment",
            show_default=False,
        ),
    ] = None,
    extra_docker_compose: Annotated[
        list[Path] | None,
        Option(
            "--extra-docker-compose",
            help="Additional Docker Compose overlay file. Can be used multiple times.",
            rich_help_panel="Environment",
            show_default=False,
        ),
    ] = None,
    environment_kwargs: Annotated[
        list[str] | None,
        Option(
            "--ek",
            "--environment-kwarg",
            help="Environment kwarg in key=value format (can be used multiple times)",
            rich_help_panel="Environment",
            show_default=False,
        ),
    ] = None,
    yes: Annotated[
        bool,
        Option(
            "-y",
            "--yes",
            help=(
                "Auto-confirm prompts, including diff execution, host environment "
                "access, and sharing with organizations you are not a member of."
            ),
            rich_help_panel="Job Settings",
        ),
    ] = False,
    env_file: Annotated[
        Path | None,
        Option(
            "--env-file",
            help="Path to a .env file to load into environment.",
            rich_help_panel="Job Settings",
        ),
    ] = None,
    verifier_env: Annotated[
        list[str] | None,
        Option(
            "--ve",
            "--verifier-env",
            help="Verifier environment variable as KEY=VALUE. Repeatable.",
            rich_help_panel="Verifier",
            show_default=False,
        ),
    ] = None,
    verifier_include_logs: Annotated[
        list[str] | None,
        Option(
            "--verifier-include-logs",
            help="Download matching verifier logs (relative glob). Repeatable.",
            rich_help_panel="Verifier",
            show_default=False,
            hidden=True,
        ),
    ] = None,
    verifier_exclude_logs: Annotated[
        list[str] | None,
        Option(
            "--verifier-exclude-logs",
            help="Skip matching verifier logs (relative glob), after includes. "
            "Repeatable.",
            rich_help_panel="Verifier",
            show_default=False,
            hidden=True,
        ),
    ] = None,
    verifier: Annotated[
        str | None,
        Option(
            "--verifier",
            help="Custom verifier import path (module.path:ClassName).",
            rich_help_panel="Verifier",
            show_default=False,
        ),
    ] = None,
    verifier_import_path: Annotated[
        str | None,
        Option(
            "--verifier-import-path",
            help="Deprecated: pass the import path to --verifier instead.",
            rich_help_panel="Verifier",
            show_default=False,
            hidden=True,
        ),
    ] = None,
    verifier_kwargs: Annotated[
        list[str] | None,
        Option(
            "--verifier-kwarg",
            help="Additional verifier kwarg in the format 'key=value'.",
            rich_help_panel="Verifier",
            show_default=False,
        ),
    ] = None,
    disable_verification: Annotated[
        bool,
        Option(
            "--disable-verification/--enable-verification",
            help="Disable task verification (skip running tests)",
            rich_help_panel="Verifier",
            show_default=False,
        ),
    ] = False,
    install_only: Annotated[
        bool,
        Option(
            "--install-only",
            help="Install the agent, then exit without running or verifying.",
            rich_help_panel="Job Settings",
            show_default=False,
        ),
    ] = False,
    path: Annotated[
        Path | None,
        Option(
            "-p",
            "--path",
            help="Path to a local task or dataset directory",
            rich_help_panel="Dataset",
            show_default=False,
        ),
    ] = None,
    extra_instruction_paths: Annotated[
        list[Path] | None,
        Option(
            "--extra-instruction-path",
            help="Append instruction file before --extra-instruction text. Repeatable.",
            rich_help_panel="Dataset",
            show_default=False,
        ),
    ] = None,
    extra_instructions: Annotated[
        list[str] | None,
        Option(
            "--extra-instruction",
            help="Append instruction text after --extra-instruction-path files. "
            "Repeatable.",
            rich_help_panel="Dataset",
            show_default=False,
        ),
    ] = None,
    task_git_url: Annotated[
        str | None,
        Option(
            help="Git URL for a task repository",
            rich_help_panel="Dataset",
            hidden=True,
            show_default=False,
        ),
    ] = None,
    task_git_commit_id: Annotated[
        str | None,
        Option(
            "--task-git-commit",
            help="Git commit ID for the task (requires --task-git-url)",
            rich_help_panel="Dataset",
            hidden=True,
            show_default=False,
        ),
    ] = None,
    dataset_name_version: Annotated[
        str | None,
        Option(
            "-d",
            "--dataset",
            help="Dataset name@version (e.g., 'dataset@1.0')",
            rich_help_panel="Dataset",
            show_default=False,
        ),
    ] = None,
    registry_url: Annotated[
        str | None,
        Option(
            "--registry-url",
            help="Registry URL for remote dataset",
            rich_help_panel="Dataset",
            hidden=True,
            show_default="The default harbor registry.",
        ),
    ] = None,
    registry_path: Annotated[
        Path | None,
        Option(
            "--registry-path",
            help="Path to a registry.json file or its parent directory. With --repo, "
            "this is a repo-relative path.",
            rich_help_panel="Dataset",
            show_default=False,
        ),
    ] = None,
    repo: Annotated[
        str | None,
        Option(
            "--repo",
            help="Git registry to resolve datasets from (e.g. 'org/name', a "
            "GitHub/Hugging Face/GitLab URL, optionally pinned with '@ref').",
            rich_help_panel="Dataset",
            show_default=False,
        ),
    ] = None,
    task_ref: Annotated[
        str | None,
        Option(
            "-t",
            "--task",
            help="Run a single task from the registry (org/name[@ref])",
            rich_help_panel="Dataset",
            show_default=False,
        ),
    ] = None,
    dataset_task_names: Annotated[
        list[str] | None,
        Option(
            "-i",
            "--include-task-name",
            help="Task name to include from dataset (supports glob patterns)",
            rich_help_panel="Dataset",
            show_default=False,
        ),
    ] = None,
    dataset_exclude_task_names: Annotated[
        list[str] | None,
        Option(
            "-x",
            "--exclude-task-name",
            help="Task name to exclude from dataset (supports glob patterns)",
            rich_help_panel="Dataset",
            show_default=False,
        ),
    ] = None,
    n_tasks: Annotated[
        int | None,
        Option(
            "-l",
            "--n-tasks",
            help="Maximum number of tasks to run (applied after other filters)",
            rich_help_panel="Dataset",
            show_default=False,
        ),
    ] = None,
    export_traces: Annotated[
        bool,
        Option(
            "--export-traces/--no-export-traces",
            help="After job completes, export traces from the job directory",
            hidden=True,
        ),
    ] = False,
    export_sharegpt: Annotated[
        bool,
        Option(
            "--export-sharegpt/--no-export-sharegpt",
            help="Also emit ShareGPT column when exporting traces",
            hidden=True,
        ),
    ] = False,
    export_episodes: Annotated[
        str,
        Option(
            "--export-episodes",
            help="Which episodes to export per trial (all|last)",
            hidden=True,
        ),
    ] = "all",
    export_push: Annotated[
        bool,
        Option(
            "--export-push/--no-export-push",
            help="Push exported dataset to HF Hub",
            hidden=True,
        ),
    ] = False,
    export_repo: Annotated[
        str | None,
        Option(
            "--export-repo",
            help="Target HF repo id (org/name) when pushing traces",
            hidden=True,
        ),
    ] = None,
    export_instruction_metadata: Annotated[
        bool,
        Option(
            "--export-instruction-metadata/--no-export-instruction-metadata",
            help="Include instruction text column when exporting traces",
            hidden=True,
        ),
    ] = False,
    export_verifier_metadata: Annotated[
        bool,
        Option(
            "--export-verifier-metadata/--no-export-verifier-metadata",
            help="Include verifier stdout/stderr column when exporting traces",
            hidden=True,
        ),
    ] = False,
    artifact_paths: Annotated[
        list[str] | None,
        Option(
            "--artifact",
            help="Environment path to download after the trial. Repeatable.",
            rich_help_panel="Job Settings",
            show_default=False,
        ),
    ] = None,
    job_plugin: Annotated[
        list[str] | None,
        Option(
            "--plugin",
            help="Import path for a job plugin class (module:ClassName). Repeatable.",
            rich_help_panel="Integrations",
            show_default=False,
        ),
    ] = None,
    plugin_kwargs: Annotated[
        list[str] | None,
        Option(
            "--pk",
            "--plugin-kwarg",
            help="key=value for one plugin, or PLUGIN.key=value to target a --plugin "
            "import path. Repeatable.",
            rich_help_panel="Integrations",
            show_default=False,
        ),
    ] = None,
    upload: Annotated[
        bool,
        Option(
            "--upload",
            help="Upload the finished job to Harbor Hub for sharing.",
            rich_help_panel="Harbor Hub",
        ),
    ] = False,
    launch: Annotated[
        bool,
        Option(
            "--launch",
            help="Run on Harbor Hub.",
            rich_help_panel="Harbor Hub",
        ),
    ] = False,
    dry_run: Annotated[
        bool,
        Option(
            "--dry-run",
            help="Validate config, preflight, and task metadata without downloading tasks, "
            "cloning repositories, or running trials. With --launch, validates on Hub "
            "without queuing or charging quota. With --diff, resolves tasks and "
            "downloads source jobs as needed, then shows the comparison without "
            "prompting or running trials.",
            rich_help_panel="Harbor Hub",
        ),
    ] = False,
    use_static_ip: Annotated[
        bool,
        Option(
            "--use-static-ip",
            help="Use a static outbound IP. Requires --launch.",
            rich_help_panel="Harbor Hub",
        ),
    ] = False,
    credential_mode: Annotated[
        CredentialMode | None,
        Option(
            "--credential-mode",
            help="Model credentials via Hub proxy (gateway) or native provider "
            "endpoint (direct). Default: gateway. Requires --launch.",
            rich_help_panel="Harbor Hub",
            show_default=False,
        ),
    ] = None,
    one_off_secret: Annotated[
        list[str] | None,
        Option(
            "--one-off-secret",
            metavar="NAME[=VALUE]",
            help="Job-only secret; bare NAME reads your environment. Overrides "
            "account-wide secrets; encrypted and revoked at job end. Requires "
            "--launch. Repeatable.",
            rich_help_panel="Harbor Hub",
            show_default=False,
        ),
    ] = None,
    stored_secret: Annotated[
        list[str] | None,
        Option(
            "--stored-secret",
            metavar="NAME",
            help="Grant an owning-org secret to all agents, adding to config "
            "selections. Requires --launch. Repeatable. Select credentials or use "
            "--no-secrets (oracle/nop exempt).",
            rich_help_panel="Harbor Hub",
            show_default=False,
        ),
    ] = None,
    no_secrets: Annotated[
        bool,
        Option(
            "--no-secrets",
            help="Launch without credentials. Conflicts with secret selections in "
            "flags or config. Requires --launch.",
            rich_help_panel="Harbor Hub",
            show_default=False,
        ),
    ] = False,
    registry_credential: Annotated[
        list[str] | None,
        Option(
            "--registry-secret",
            metavar="HOST=NAME_OR_ID",
            help="Select a stored image-pull secret when multiple credentials match a "
            "host. Requires --launch. Repeatable.",
            rich_help_panel="Harbor Hub",
            show_default=False,
        ),
    ] = None,
    public: Annotated[
        bool | None,
        Option(
            "--public/--private",
            help="Uploaded job visibility (default: private). Requires --upload.",
            rich_help_panel="Harbor Hub",
            show_default=False,
        ),
    ] = None,
    share_org: Annotated[
        list[str] | None,
        Option(
            "--share",
            help="Share the job with an organization. Requires --upload or --launch. "
            "Repeatable.",
            rich_help_panel="Harbor Hub",
            show_default=False,
        ),
    ] = None,
    share_user: Annotated[
        list[str] | None,
        Option(
            "--share-user",
            help="Share the job with a GitHub username. Requires --upload or --launch. "
            "Repeatable.",
            rich_help_panel="Harbor Hub",
            show_default=False,
            hidden=True,
        ),
    ] = None,
    org: Annotated[
        str | None,
        Option(
            "--org",
            help="Owning organization (default: personal org). Requires --upload or "
            "--launch.",
            rich_help_panel="Harbor Hub",
            show_default=False,
        ),
    ] = None,
) -> JobConfig:
    if diff_sources and launch:
        raise ValueError("--diff cannot be combined with --launch.")
    if dry_run and print_config:
        raise ValueError("--dry-run and --print-config are mutually exclusive.")
    if launch and upload:
        console.print("[red]Error:[/red] --launch and --upload are mutually exclusive.")
        raise SystemExit(1)

    # Harbor Hub flag validation: --public/--private requires --upload so the
    # semantics stay explicit (no hidden "oh, you wanted to upload too").
    if public is not None and not upload:
        console.print("[red]Error:[/red] --public / --private requires --upload.")
        raise SystemExit(1)
    if (share_org or share_user) and not (upload or launch):
        console.print(
            "[red]Error:[/red] --share / --share-user requires --upload or --launch."
        )
        raise SystemExit(1)
    if one_off_secret and not launch:
        console.print("[red]Error:[/red] --one-off-secret requires --launch.")
        raise SystemExit(1)
    if stored_secret and not launch:
        console.print("[red]Error:[/red] --stored-secret requires --launch.")
        raise SystemExit(1)
    if credential_mode is not None and not launch:
        console.print("[red]Error:[/red] --credential-mode requires --launch.")
        raise SystemExit(1)
    if use_static_ip and not launch:
        console.print("[red]Error:[/red] --use-static-ip requires --launch.")
        raise SystemExit(1)
    if registry_credential and not launch:
        console.print("[red]Error:[/red] --registry-secret requires --launch.")
        raise SystemExit(1)
    if no_secrets and not launch:
        console.print("[red]Error:[/red] --no-secrets requires --launch.")
        raise SystemExit(1)
    if n_concurrent_agents is not None and launch:
        console.print(
            "[red]Error:[/red] --n-concurrent-agents is only supported for local runs."
        )
        raise SystemExit(1)
    if org is not None and not (upload or launch):
        console.print("[red]Error:[/red] --org requires --upload or --launch.")
        raise SystemExit(1)

    if launch:
        console.print("[dim]Preparing hosted launch...[/dim]")

    # ``vercel env pull`` (the command the Vercel Sandbox preflight points
    # users at) writes ``VERCEL_OIDC_TOKEN`` to ``.env.local`` by default.
    # Without this fallback the documented onboarding flow loops forever:
    # the token is written but never loaded, so ``preflight`` re-emits the
    # same auth error on every run. ``.env.local`` is a standard Vercel /
    # Next.js convention and harmless to other environment providers.
    # ``override=False`` keeps it the lowest-priority source: real shell env
    # and an explicit ``--env-file`` (loaded next with ``override=True``)
    # both win for any key they set, while keys *only* in ``.env.local`` —
    # such as the OIDC token — still reach ``os.environ``.
    if (Path.cwd() / ".env.local").exists():
        load_dotenv(Path.cwd() / ".env.local", override=False)

    if env_file is not None:
        if not env_file.exists():
            console.print(f"[red]❌ Env file not found: {env_file}[/red]")
            raise SystemExit(1)
        load_dotenv(env_file, override=True)

    # Harbor Hub auth for --upload is validated in `HarborHubUploadPlugin.on_job_start`
    # (before any orchestrator work). We deliberately don't pre-check here in a
    # separate `run_async` call — `run_async` calls `asyncio.run`, which creates
    # and tears down an event loop per invocation. The Supabase auth client caches
    # a singleton tied to the loop that created it, so a cross-loop reuse raises
    # ``Event loop is closed``. Doing the check inside the same `run_async` as
    # the run itself avoids that.

    config_data: dict[str, Any] = {}
    if config_path is not None:
        try:
            for source in config_path:
                try:
                    layer = load_config_source(source)
                except (ValueError, YAMLError) as exc:
                    raise ValueError(
                        f"Failed to load config from {source}: {exc}"
                    ) from exc
                if not isinstance(layer, dict):
                    raise ValueError(f"Config {source} must contain a mapping")
                config_data = merge_config(
                    config_data,
                    layer,
                    append_paths=_APPEND_CONFIG_PATHS,
                    exclusive_groups=_EXCLUSIVE_CONFIG_GROUPS,
                )
        except ValueError as exc:
            console.print(f"[red]Error:[/red] {exc}")
            raise SystemExit(1) from exc
    # Migrate before applying overrides so legacy retry settings merge normally.
    config = migrate_legacy_job_config(config_data)
    config.setdefault("agents", [{}])
    config.setdefault("retry", {})
    config.setdefault("environment", {})
    config.setdefault("verifier", {})

    if job_name is not None:
        config["job_name"] = job_name
    if jobs_dir is not None:
        config["jobs_dir"] = jobs_dir
    if n_attempts is not None:
        config["n_attempts"] = n_attempts
    if timeout_multiplier is not None:
        config["timeout_multiplier"] = timeout_multiplier
    if agent_timeout_multiplier is not None:
        config["agent_timeout_multiplier"] = agent_timeout_multiplier
    if verifier_timeout_multiplier is not None:
        config["verifier_timeout_multiplier"] = verifier_timeout_multiplier
    if agent_setup_timeout_multiplier is not None:
        config["agent_setup_timeout_multiplier"] = agent_setup_timeout_multiplier
    if environment_build_timeout_multiplier is not None:
        config["environment_build_timeout_multiplier"] = (
            environment_build_timeout_multiplier
        )
    if debug:
        config["debug"] = debug

    if n_concurrent_trials is not None:
        config["n_concurrent_trials"] = n_concurrent_trials
    if quiet:
        config["quiet"] = quiet
    if max_retries is not None:
        config["retry"]["max_retries"] = max_retries
    if retry_include_exceptions is not None:
        config["retry"]["include_exceptions"] = set(retry_include_exceptions)
    if retry_exclude_exceptions is not None:
        config["retry"]["exclude_exceptions"] = set(retry_exclude_exceptions)

    if agent_import_path is not None:
        warn_deprecated_flag("--agent-import-path", "--agent")
    if agent_name is not None or agent_import_path is not None:
        config["agents"] = []
        # --agent wins over the deprecated alias when both are provided.
        resolved_import_path = agent_import_path if agent_name is None else None
        parsed_kwargs = parse_kwargs(agent_kwargs)
        parsed_env = parse_env_vars(agent_env)
        parsed_mcp_servers = [
            server
            for mcp_config_path in mcp_config or []
            for server in load_mcp_servers(mcp_config_path)
        ]

        if model_names is not None:
            config["agents"] = [
                dict(
                    name=agent_name,
                    import_path=resolved_import_path,
                    model_name=model_name,
                    skills=list(skills or []),
                    extra_allowed_hosts=list(allow_agent_hosts or []),
                    include_logs=list(agent_include_logs or []),
                    exclude_logs=list(agent_exclude_logs or []),
                    kwargs=parsed_kwargs,
                    env=parsed_env,
                    mcp_servers=parsed_mcp_servers,
                )
                for model_name in model_names
            ]
        else:
            config["agents"] = [
                dict(
                    name=agent_name,
                    import_path=resolved_import_path,
                    skills=list(skills or []),
                    extra_allowed_hosts=list(allow_agent_hosts or []),
                    include_logs=list(agent_include_logs or []),
                    exclude_logs=list(agent_exclude_logs or []),
                    kwargs=parsed_kwargs,
                    env=parsed_env,
                    mcp_servers=parsed_mcp_servers,
                )
            ]
    else:
        parsed_kwargs = parse_kwargs(agent_kwargs)
        parsed_env = parse_env_vars(agent_env)
        parsed_mcp_servers = [
            server
            for mcp_config_path in mcp_config or []
            for server in load_mcp_servers(mcp_config_path)
        ]
        if (
            parsed_kwargs
            or parsed_env
            or parsed_mcp_servers
            or skills
            or allow_agent_hosts
            or allow_environment_hosts
            or agent_include_logs
            or agent_exclude_logs
        ):
            for agent in config["agents"]:
                if parsed_kwargs:
                    agent.setdefault("kwargs", {}).update(parsed_kwargs)
                if parsed_env:
                    agent.setdefault("env", {}).update(parsed_env)
                if parsed_mcp_servers:
                    agent.setdefault("mcp_servers", []).extend(parsed_mcp_servers)
                if skills:
                    agent.setdefault("skills", []).extend(skills)
                if allow_agent_hosts:
                    agent.setdefault("extra_allowed_hosts", []).extend(
                        allow_agent_hosts
                    )
                if agent_include_logs:
                    agent.setdefault("include_logs", []).extend(agent_include_logs)
                if agent_exclude_logs:
                    agent.setdefault("exclude_logs", []).extend(agent_exclude_logs)

    if effort is not None:
        for agent in config["agents"]:
            agent.setdefault("kwargs", {})["reasoning_effort"] = effort

    if n_concurrent_agents is not None:
        for agent in config["agents"]:
            agent["n_concurrent"] = n_concurrent_agents

    if resume_trajectory is not None:
        for agent in config["agents"]:
            agent["resume_trajectory"] = resume_trajectory

    if load_trajectory is not None:
        # Resolve now so a stored job config replays from any working directory.
        resolved_trajectory = str(Path(load_trajectory).expanduser().resolve())
        for agent in config["agents"]:
            agent["load_trajectory"] = resolved_trajectory

    if user_agent_name is not None:
        existing_user_agent = config.get("user_agent")
        existing_bridge = (
            deepcopy(existing_user_agent.get("bridge"))
            if existing_user_agent is not None
            else None
        )
        resolved_bridge_kind = bridge_kind or (
            existing_bridge.get("kind") if existing_bridge is not None else None
        )
        if resolved_bridge_kind is None:
            console.print("[red]Error:[/red] --user-agent requires --bridge.")
            raise SystemExit(1)
        resolved_bridge: dict[str, Any] = existing_bridge or dict(
            kind=resolved_bridge_kind
        )
        resolved_bridge["kind"] = resolved_bridge_kind
        if bridge_prompt_path is not None:
            resolved_bridge["prompt_path"] = bridge_prompt_path
        if bridge_kwargs is not None:
            resolved_bridge.setdefault("kwargs", {}).update(parse_kwargs(bridge_kwargs))
        config["user_agent"] = dict(
            name=user_agent_name,
            model_name=user_model,
            kwargs=parse_kwargs(user_agent_kwargs),
            env=parse_env_vars(agent_env),
            user_persona_path=(
                user_persona_path
                if user_persona_path is not None
                else (
                    existing_user_agent.get("user_persona_path")
                    if existing_user_agent is not None
                    else None
                )
            ),
            user_prompt_template_path=(
                user_prompt_template_path
                if user_prompt_template_path is not None
                else (
                    existing_user_agent.get("user_prompt_template_path")
                    if existing_user_agent is not None
                    else None
                )
            ),
            bridge=resolved_bridge,
        )
    elif user_model is not None and config.get("user_agent") is not None:
        config["user_agent"]["model_name"] = user_model
    if config.get("user_agent") is not None:
        if user_agent_kwargs is not None:
            config["user_agent"].setdefault("kwargs", {}).update(
                parse_kwargs(user_agent_kwargs)
            )
        if user_persona_path is not None:
            config["user_agent"]["user_persona_path"] = user_persona_path
        if user_prompt_template_path is not None:
            config["user_agent"]["user_prompt_template_path"] = (
                user_prompt_template_path
            )
        if bridge_kind is not None:
            config["user_agent"].setdefault("bridge", {})["kind"] = bridge_kind
        if bridge_prompt_path is not None:
            config["user_agent"].setdefault("bridge", {})["prompt_path"] = (
                bridge_prompt_path
            )
        if bridge_kwargs is not None:
            config["user_agent"].setdefault("bridge", {}).setdefault(
                "kwargs", {}
            ).update(parse_kwargs(bridge_kwargs))

    if config.get("user_agent") is None and (
        user_model is not None
        or user_agent_kwargs
        or user_persona_path is not None
        or user_prompt_template_path is not None
        or bridge_kind is not None
        or bridge_prompt_path is not None
        or bridge_kwargs
    ):
        console.print(
            "[red]Error:[/red] simulated-user and bridge flags require "
            "--user-agent (or user_agent in the job config)."
        )
        raise SystemExit(1)

    if allow_environment_hosts is not None:
        config["environment"].setdefault("extra_allowed_hosts", []).extend(
            allow_environment_hosts
        )
    if environment_import_path is not None:
        warn_deprecated_flag("--environment-import-path", "--env")
        config["environment"]["import_path"] = environment_import_path
        config["environment"]["type"] = (
            None  # Clear type so import_path takes precedence
        )
    if environment is not None:
        env_type, env_import_path = resolve_environment_spec(environment)
        config["environment"]["type"] = env_type
        config["environment"]["import_path"] = env_import_path
    if environment_force_build is not None:
        config["environment"]["force_build"] = environment_force_build
    if environment_delete is not None:
        config["environment"]["delete"] = environment_delete
    if stream is not None:
        config["environment"]["stream"] = stream
    if cpus is not None:
        config["environment"]["cpu_enforcement_policy"] = cpus
    if memory is not None:
        config["environment"]["memory_enforcement_policy"] = memory
    if override_cpus is not None:
        config["environment"]["override_cpus"] = override_cpus
    if override_memory_mb is not None:
        config["environment"]["override_memory_mb"] = override_memory_mb
    if override_storage_mb is not None:
        config["environment"]["override_storage_mb"] = override_storage_mb
    if override_gpus is not None:
        config["environment"]["override_gpus"] = override_gpus
    if override_tpu is not None:
        config["environment"]["override_tpu"] = parse_tpu_spec(override_tpu)
    if mounts is not None:
        config["environment"]["mounts"] = json.loads(mounts)
    if extra_docker_compose is not None:
        config["environment"].setdefault("extra_docker_compose", []).extend(
            extra_docker_compose
        )
    if environment_kwargs is not None:
        config["environment"].setdefault("kwargs", {}).update(
            parse_kwargs(environment_kwargs)
        )

    if verifier_env is not None:
        config["verifier"].setdefault("env", {}).update(parse_env_vars(verifier_env))
    if verifier_include_logs is not None:
        config["verifier"].setdefault("include_logs", []).extend(verifier_include_logs)
    if verifier_exclude_logs is not None:
        config["verifier"].setdefault("exclude_logs", []).extend(verifier_exclude_logs)
    if verifier_import_path is not None:
        warn_deprecated_flag("--verifier-import-path", "--verifier")
        config["verifier"]["import_path"] = verifier_import_path
    if verifier is not None:
        config["verifier"]["import_path"] = verifier
    if verifier_kwargs is not None:
        config["verifier"].setdefault("kwargs", {}).update(
            parse_kwargs(verifier_kwargs)
        )
    if install_only:
        config["install_only"] = True
        # --install-only implies --disable-verification, including for task validation.
        disable_verification = True
    if disable_verification:
        config["verifier"]["disable"] = disable_verification

    if artifact_paths is not None:
        config["artifacts"] = list(artifact_paths)
    if extra_instruction_paths is not None:
        config["extra_instruction_paths"] = list(extra_instruction_paths)
    if extra_instructions is not None:
        config["extra_instructions"] = list(extra_instructions)

    task_specified = task_git_url is not None or task_git_commit_id is not None

    dataset_specified = (
        dataset_name_version is not None
        or registry_url is not None
        or registry_path is not None
        or dataset_task_names is not None
        or dataset_exclude_task_names is not None
        or n_tasks is not None
        or task_ref is not None
    )

    if task_specified and dataset_specified:
        raise ValueError("Cannot specify both task and dataset parameters")

    if repo is not None:
        if registry_url is not None:
            raise ValueError("--repo and --registry-url are mutually exclusive.")
        if task_specified or task_ref is not None:
            raise ValueError("--repo cannot be combined with --task / --task-git-url.")

        repo_dataset_name: str | None = None
        repo_dataset_version: str | None = None
        if dataset_name_version is not None:
            if "@" in dataset_name_version:
                repo_dataset_name, repo_dataset_version = dataset_name_version.split(
                    "@", 1
                )
            else:
                repo_dataset_name = dataset_name_version
            if "/" in repo_dataset_name:
                raise ValueError("--dataset with --repo must be a bare name (no '/').")

        config["tasks"] = []
        config["datasets"] = [
            dict(
                repo=repo,
                name=repo_dataset_name,
                version=repo_dataset_version,
                path=path,
                registry_path=registry_path,
                task_names=dataset_task_names,
                exclude_task_names=dataset_exclude_task_names,
                n_tasks=n_tasks,
            )
        ]

    elif path is not None:
        is_task = task_git_url is not None or Task.is_valid_dir(
            path,
            disable_verification=disable_verification,
        )

        if is_task:
            config["tasks"] = [
                dict(
                    path=path,
                    git_url=task_git_url,
                    git_commit_id=task_git_commit_id,
                )
            ]
            config["datasets"] = []
        else:
            config["tasks"] = []
            config["datasets"] = [
                dict(
                    path=path,
                    task_names=dataset_task_names,
                    exclude_task_names=dataset_exclude_task_names,
                    n_tasks=n_tasks,
                )
            ]

    elif task_specified:
        raise ValueError("Task configuration with --task-git-url requires --path")

    elif dataset_specified:
        config["tasks"] = []

        if task_ref is not None:
            from harbor.models.package.reference import PackageReference

            ref = PackageReference.parse(task_ref)
            config["datasets"] = []
            config["tasks"] = [
                dict(
                    name=ref.name,
                    ref=ref.ref,
                )
            ]

        elif dataset_name_version is not None:
            if "@" in dataset_name_version:
                name, version = dataset_name_version.split("@", 1)
            else:
                name, version = dataset_name_version, None

            # Detect package reference (org/name format)
            if "/" in name:
                config["datasets"] = [
                    dict(
                        name=name,
                        ref=version or "latest",
                        task_names=dataset_task_names,
                        exclude_task_names=dataset_exclude_task_names,
                        n_tasks=n_tasks,
                    )
                ]
            else:
                config["datasets"] = [
                    dict(
                        registry_url=registry_url,
                        registry_path=registry_path,
                        name=name,
                        version=version,
                        task_names=dataset_task_names,
                        exclude_task_names=dataset_exclude_task_names,
                        n_tasks=n_tasks,
                    )
                ]

        else:
            raise ValueError(
                "Cannot specify --registry-url, --registry-path, --include-task-name, or "
                "--exclude-task-name without also specifying --dataset, --task, or --path."
            )

    if launch:
        if org is not None:
            config["organization"] = org
        if credential_mode is not None:
            config["credential_mode"] = credential_mode
        if use_static_ip:
            config["static_outbound_ip"] = True

    config_model = HostedJobConfig if launch else JobConfig
    config = config_model.model_validate(config, extra="forbid" if dry_run else None)

    if config.user_agent is not None:
        from harbor.trial.simulated_user import validate_user_agent_version_pin

        try:
            _validate_bridge_target_agents(config.agents, config.user_agent.bridge.kind)
            for agent in config.agents:
                validate_user_agent_version_pin(
                    agent.name,
                    agent.kwargs.get("version"),
                    config.user_agent.name,
                    config.user_agent.kwargs.get("version"),
                )
        except ValueError as exc:
            console.print(f"[red]Error:[/red] {exc}")
            raise SystemExit(1) from exc

    return config


@wraps(build_job_config)
def start(*args, **kwargs):
    """Parse run options once; share config construction with job init."""
    options = signature(build_job_config).bind(*args, **kwargs)
    options.apply_defaults()
    try:
        config = build_job_config(**options.arguments)
        return _execute_job(
            config,
            diff_sources=options.arguments["diff_sources"],
            print_config=options.arguments["print_config"],
            launch=options.arguments["launch"],
            dry_run=options.arguments["dry_run"],
            credential_mode=options.arguments["credential_mode"],
            org=options.arguments["org"],
            stored_secret=options.arguments["stored_secret"],
            env_file=options.arguments["env_file"],
            one_off_secret=options.arguments["one_off_secret"],
            registry_credential=options.arguments["registry_credential"],
            no_secrets=options.arguments["no_secrets"],
            yes=options.arguments["yes"],
            upload=options.arguments["upload"],
            public=options.arguments["public"],
            share_org=options.arguments["share_org"],
            share_user=options.arguments["share_user"],
            job_plugin=options.arguments["job_plugin"],
            plugin_kwargs=options.arguments["plugin_kwargs"],
            export_traces=options.arguments["export_traces"],
            export_push=options.arguments["export_push"],
            export_repo=options.arguments["export_repo"],
            export_episodes=options.arguments["export_episodes"],
            export_sharegpt=options.arguments["export_sharegpt"],
            export_instruction_metadata=options.arguments[
                "export_instruction_metadata"
            ],
            export_verifier_metadata=options.arguments["export_verifier_metadata"],
        )
    except ValueError as exc:
        if get_current_context(silent=True) is None:
            raise
        from harbor.cli.config_validation import format_validation_error

        message = (
            format_validation_error(exc)
            if isinstance(exc, ValidationError)
            else str(exc)
        )
        console.print(message, style="red", markup=False)
        raise SystemExit(1) from None


# wraps preserves the shared option signature; keep the public command name.
start.__name__ = "start"


def _execute_job(
    config: JobConfig,
    *,
    diff_sources,
    print_config,
    launch,
    dry_run,
    credential_mode,
    org,
    stored_secret,
    env_file,
    one_off_secret,
    registry_credential,
    no_secrets,
    yes,
    upload,
    public,
    share_org,
    share_user,
    job_plugin,
    plugin_kwargs,
    export_traces,
    export_push,
    export_repo,
    export_episodes,
    export_sharegpt,
    export_instruction_metadata,
    export_verifier_metadata,
):
    plugin_configs = plugin_configs_from_cli(job_plugin, plugin_kwargs)
    if print_config:
        config_dump = config.model_dump(mode="json", exclude_defaults=True)
        if launch:
            # Show the complete retry policy that will be submitted to the Hub.
            config_dump["retry"] = config.retry.model_dump(mode="json")
        print(
            json.dumps(
                config_dump,
                indent=2,
                ensure_ascii=False,
            )
        )
        return

    if launch:
        from harbor.cli.hosted_jobs import run_hosted_launch

        if not isinstance(config, HostedJobConfig):
            raise RuntimeError("hosted launch did not produce a HostedJobConfig")
        run_hosted_launch(
            config=config,
            credential_mode=credential_mode,
            share_org=share_org,
            share_user=share_user,
            org=org,
            stored_secret=stored_secret,
            env_file=env_file,
            one_off_secret=one_off_secret,
            registry_credential=registry_credential,
            no_secrets=no_secrets,
            yes=yes,
            dry_run=dry_run,
            console=console,
        )
        return

    if dry_run and not diff_sources:
        from harbor.cli.config_validation import (
            print_validation_report,
            validate_job_config,
            validate_local_sources,
        )

        async def _validate_local():
            print_validation_report(await validate_job_config(config))
            _run_preflight(config)
            report = await validate_local_sources(config)
            print_validation_report(report)
            return report

        try:
            report = run_async(_validate_local())
        except DATASET_RESOLUTION_ERRORS as exc:
            abort_dataset_resolution(console, exc, "Dry run failed")
        except (ValueError, OSError, RuntimeError) as exc:
            console.print(f"[red]Dry run failed:[/red] {exc}")
            raise SystemExit(1) from None
        count = (
            f"{report.n_trials} trial(s)"
            if report.n_trials is not None
            else "trial count unknown"
        )
        console.print(f"Dry run OK — {count}; nothing was run.")
        return

    if diff_sources:
        from harbor.job_diff import compare_job_trials, resolve_diff_sources
        from harbor.job_plan import JobPlan
        from harbor.trial.regrade import RegradeError

        if config.source_jobs:
            console.print(
                "[red]Error:[/red] --diff cannot be combined with source_jobs "
                "already present in the target config."
            )
            raise SystemExit(1)
        if config.install_only:
            console.print("[red]Error:[/red] --diff cannot use --install-only.")
            raise SystemExit(1)

        async def _run_diff():
            resolved_sources, source_trials = await resolve_diff_sources(
                diff_sources, jobs_dir=config.jobs_dir
            )
            plan = await JobPlan.from_config(config)
            return (
                compare_job_trials(plan, source_trials),
                [source_job for source_job, _ in resolved_sources],
            )

        try:
            diff_result, source_job_configs = run_async(_run_diff())
        except DATASET_RESOLUTION_ERRORS as exc:
            abort_dataset_resolution(console, exc, "Diff failed; no job was started.")
        except (OSError, RegradeError, ValueError, ValidationError) as exc:
            console.print(f"[red]Error:[/red] {exc}")
            raise SystemExit(1) from None

        counts = diff_result.counts
        n_target_trials = len(diff_result.trials)
        console.print("[bold]Job Diff[/bold]")
        console.print(f"Target trials: {n_target_trials}")
        console.print(f"Reuse: {counts['reuse']}/{n_target_trials}")
        console.print(f"Regrade: {counts['regrade']}/{n_target_trials}")
        console.print(f"Rerun: {counts['rerun']}/{n_target_trials}")

        table = Table(show_header=True)
        table.add_column("Action")
        table.add_column("Target Trial")
        table.add_column("Task")
        table.add_column("Source Trial")
        table.add_column("Reason")
        for trial in diff_result.trials:
            source_trial = (
                f"{trial.source.job_label}:{trial.source.trial_name}"
                if trial.source is not None
                else "-"
            )
            table.add_row(
                trial.action.value,
                trial.target_trial_name,
                trial.task_name,
                source_trial,
                trial.reason,
            )
        console.print(table)

        if diff_result.skipped_source_trials:
            console.print(
                "[yellow]Warning:[/yellow] Skipped "
                f"{diff_result.skipped_source_trials} source trial(s) whose task "
                "lock has no semantic version."
            )
        if diff_result.n_regrade_downgraded:
            console.print(
                "[yellow]Warning:[/yellow] "
                f"{diff_result.n_regrade_downgraded} trial(s) had minor task "
                "changes but could not be regraded, so they must be rerun."
            )

        if dry_run:
            console.print("Dry run complete; no job was started.")
            return

        n_regrade = counts["regrade"]
        n_rerun = counts["rerun"]
        if n_regrade + n_rerun == 0:
            console.print("Nothing to execute.")
            return
        if not yes and not confirm(
            f"Proceed with {n_regrade} regrade(s) and {n_rerun} rerun(s)?",
            default=False,
        ):
            console.print("Cancelled.")
            return
        config.source_jobs = source_job_configs

    async def _run_job():
        from harbor.cli.job_sharing import (
            confirm_non_member_org_shares,
            normalize_share_values,
        )
        from harbor.job import Job

        requested_share_orgs = normalize_share_values(share_org)
        requested_share_users = normalize_share_values(share_user)
        confirm_non_member_orgs = (
            await confirm_non_member_org_shares(requested_share_orgs, yes=yes)
            if upload
            else False
        )
        job = await Job.create(config)
        _confirm_host_env_access(
            job,
            console,
            explicit_env_file_keys=explicit_env_file_keys,
            skip_confirm=yes,
        )

        from harbor.cli.job_plugins import attach_job_plugins, finalize_job_plugins

        plugins = await attach_job_plugins(job, plugin_configs)

        hub_plugin = None
        if upload:
            from harbor.cli.plugins.harbor_hub import HarborHubUploadPlugin

            hub_plugin = HarborHubUploadPlugin(
                public=public,
                org=org,
                share_orgs=requested_share_orgs,
                share_users=requested_share_users,
                confirm_non_member_orgs=confirm_non_member_orgs,
                yes=yes,
                console=console,
            )
            await hub_plugin.on_job_start(job)

        job_result = await job.run()

        # Print the run summary BEFORE plugin and Harbor Hub finalize so users
        # see results even if downstream operations fail.
        console.print()
        print_job_results_tables(job_result)
        console.print("[bold]Job Info[/bold]")
        console.print(
            f"Total runtime: {_format_duration(job_result.started_at, job_result.finished_at)}"
        )
        console.print(f"Results written to {job._job_result_path}")
        console.print(f"Inspect results by running `harbor view {job.job_dir.parent}`")

        await finalize_job_plugins(plugins, job_result)

        # Finalize must run on the same event loop as `HarborHubUploadPlugin.on_job_start`
        # — the Supabase auth client is a module-level singleton tied to
        # whichever loop first created it. A separate `run_async` call would
        # create a new loop and reuse the dead-loop-bound client → boom.
        if hub_plugin is not None:
            await hub_plugin.on_job_end(job_result)
        else:
            console.print(f"Share results by running `harbor upload {job.job_dir}`")
        console.print()

        return job, job_result

    _run_preflight(config)

    explicit_env_file_keys: set[str] = set()
    if env_file is not None:
        explicit_env_file_keys = {
            key for key in dotenv_values(env_file).keys() if key is not None
        }

    signal.signal(signal.SIGTERM, _handle_sigterm)

    show_registry_hint_if_first_run(console)

    # `_run_job` itself prints the summary + invokes the upload finalize
    # (when --upload is set) so everything stays on one event loop. See
    # the long comment in `HarborHubUploadPlugin.on_job_end` for why this matters.
    try:
        job, job_result = run_async(_run_job())
    except DATASET_RESOLUTION_ERRORS as exc:
        abort_dataset_resolution(console, exc, "No job was started.")

    if export_traces:
        from harbor.utils.traces_utils import export_traces as _export_traces

        job_dir = job.job_dir
        print(f"[traces] Exporting traces from job dir: {job_dir}")
        try:
            if export_push and not export_repo:
                raise ValueError("--export-push requires --export-repo <org/name>")
            ds = _export_traces(
                root=job_dir,
                recursive=True,
                episodes="last" if export_episodes == "last" else "all",
                to_sharegpt=export_sharegpt,
                repo_id=export_repo,
                push=export_push,
                include_instruction=export_instruction_metadata,
                include_verifier_output=export_verifier_metadata,
            )
            print(f"[traces] Exported {len(ds)} rows from {job_dir}")
        except Exception as e:
            print(f"[traces] Export failed: {e}")


@jobs_app.command()
def resume(
    job_path: Annotated[
        Path,
        Option(
            "-p",
            "--job-path",
            help="Path to the job directory containing the config.json file",
        ),
    ],
    filter_error_types: Annotated[
        list[str] | None,
        Option(
            "-f",
            "--filter-error-type",
            help="Remove trials with these error types before resuming (can be used "
            "multiple times)",
            show_default=False,
        ),
    ] = ["CancelledError"],
    job_plugin: Annotated[
        list[str] | None,
        Option(
            "--plugin",
            help="Import path for a job plugin class (module:ClassName). Repeatable.",
            rich_help_panel="Integrations",
            show_default=False,
        ),
    ] = None,
    plugin_kwargs: Annotated[
        list[str] | None,
        Option(
            "--pk",
            "--plugin-kwarg",
            help="Plugin kwarg in the format 'key=value' or 'PLUGIN.key=value'. "
            "The PLUGIN prefix must match a --plugin value and targets that "
            "plugin. Kwargs without a prefix require exactly one --plugin. "
            "Can be set multiple times.",
            rich_help_panel="Integrations",
            show_default=False,
        ),
    ] = None,
    upload: Annotated[
        bool,
        Option(
            "--upload",
            help="After the resume finishes, upload the job to Harbor Hub. "
            "If the job was already partially uploaded (e.g. from a previous "
            "`harbor run --upload` that crashed), this fills in the missing "
            "trials and finalizes — it's an idempotent sweep.",
            rich_help_panel="Harbor Hub",
        ),
    ] = False,
    public: Annotated[
        bool | None,
        Option(
            "--public/--private",
            help="Visibility for the uploaded job. Requires --upload. "
            "No flag = private for new jobs, unchanged for existing ones.",
            rich_help_panel="Harbor Hub",
            show_default=False,
        ),
    ] = None,
    share_org: Annotated[
        list[str] | None,
        Option(
            "--share",
            help="Share the uploaded job with an organization. Requires --upload. Repeatable.",
            rich_help_panel="Harbor Hub",
            show_default=False,
        ),
    ] = None,
    share_user: Annotated[
        list[str] | None,
        Option(
            "--share-user",
            help="Share the uploaded job with a GitHub username. Requires --upload. Repeatable.",
            rich_help_panel="Harbor Hub",
            show_default=False,
        ),
    ] = None,
    org: Annotated[
        str | None,
        Option(
            "--org",
            help="Organization that should own the uploaded job. Requires "
            "--upload. Defaults to your personal org. If the job was already "
            "uploaded, this must match the existing owner — ownership can't "
            "be changed on re-upload (use transfer or copy).",
            rich_help_panel="Harbor Hub",
            show_default=False,
        ),
    ] = None,
    yes: Annotated[
        bool,
        Option(
            "--yes",
            "-y",
            help="Confirm sharing with organizations you are not a member of.",
            rich_help_panel="Harbor Hub",
        ),
    ] = False,
):
    """Resume an existing job from its job directory."""
    from harbor.job import Job

    # Mirror the validation in `start()` — setting visibility without
    # --upload is almost certainly a mistake, so fail fast rather than
    # silently ignoring the flag.
    if public is not None and not upload:
        console.print("[red]Error:[/red] --public / --private requires --upload.")
        raise SystemExit(1)
    if (share_org or share_user) and not upload:
        console.print("[red]Error:[/red] --share / --share-user requires --upload.")
        raise SystemExit(1)
    if org is not None and not upload:
        console.print("[red]Error:[/red] --org requires --upload.")
        raise SystemExit(1)
    plugin_configs = plugin_configs_from_cli(job_plugin, plugin_kwargs)

    job_dir = Path(job_path)
    config_path = job_dir / "config.json"

    if not job_dir.exists():
        raise ValueError(f"Job directory does not exist: {job_dir}")

    if not config_path.exists():
        raise ValueError(f"Config file not found: {config_path}")

    if filter_error_types:
        filter_error_types_set = set(filter_error_types)
        for trial_dir in job_dir.iterdir():
            if not trial_dir.is_dir():
                continue

            trial_paths = TrialPaths(trial_dir)

            if not trial_paths.result_path.exists():
                continue

            try:
                result_text = trial_paths.result_path.read_text()
            except (OSError, UnicodeDecodeError) as e:
                logger.warning(
                    "Skipping trial directory %s because result.json could not be read: %s",
                    trial_dir,
                    e,
                )
                continue

            if not result_text.strip():
                logger.warning(
                    "Skipping trial directory %s because result.json is empty",
                    trial_dir,
                )
                continue

            try:
                trial_result = TrialResult.model_validate_json(result_text)
            except ValidationError as e:
                logger.warning(
                    "Skipping trial directory %s because result.json could not be parsed: %s",
                    trial_dir,
                    e,
                )
                continue
            if (
                trial_result.exception_info is not None
                and trial_result.exception_info.exception_type in filter_error_types_set
            ):
                console.print(
                    f"Removing trial directory with {
                        trial_result.exception_info.exception_type
                    }: {trial_dir.name}"
                )
                shutil.rmtree(trial_dir)

    config = JobConfig.model_validate_json(config_path.read_text())

    _run_preflight(config)

    async def _run_job():
        from harbor.cli.job_sharing import (
            confirm_non_member_org_shares,
            normalize_share_values,
        )

        requested_share_orgs = normalize_share_values(share_org)
        requested_share_users = normalize_share_values(share_user)
        confirm_non_member_orgs = (
            await confirm_non_member_org_shares(requested_share_orgs, yes=yes)
            if upload
            else False
        )
        job = await Job.create(config)
        from harbor.cli.job_plugins import attach_job_plugins, finalize_job_plugins

        plugins = await attach_job_plugins(job, plugin_configs)
        # Same streaming setup as `harbor run --upload`. The primitives
        # already handle the resume case correctly:
        #  * `start_job` detects an already-inserted row from the original
        #    `harbor run --upload` and preserves it.
        #  * The streaming hook's `upload_single_trial` short-circuits on
        #    trials whose archive path has already been finalized.
        #  * The post-run `upload_job` sweep resumes reserved trial rows whose
        #    archive path is still NULL, then finalizes the job if needed.

        hub_plugin = None
        if upload:
            from harbor.cli.plugins.harbor_hub import HarborHubUploadPlugin

            hub_plugin = HarborHubUploadPlugin(
                public=public,
                org=org,
                share_orgs=requested_share_orgs,
                share_users=requested_share_users,
                confirm_non_member_orgs=confirm_non_member_orgs,
                yes=yes,
                console=console,
            )
            await hub_plugin.on_job_start(job)
        job_result = await job.run()

        await finalize_job_plugins(plugins, job_result)

        # Streaming + post-run finalize must share an event loop — see
        # `HarborHubUploadPlugin.on_job_end` for why.
        if hub_plugin is not None:
            await hub_plugin.on_job_end(job_result)
        return job_result

    try:
        job_result = run_async(_run_job())
    except DATASET_RESOLUTION_ERRORS as exc:
        abort_dataset_resolution(console, exc, "No job was started.")

    # Print results tables
    print_job_results_tables(job_result)


@jobs_app.command()
def summarize(
    job_path: Annotated[Path, Argument(help="Path to job directory.")] = Path("."),
):
    """Removed command shim."""
    console.print(
        "[red]Error: 'harbor jobs summarize' has been removed. "
        "Use 'harbor analyze <job-dir>' instead.[/red]"
    )
    raise SystemExit(1)


def _humanize_bytes(n: int) -> str:
    size: float = float(n)
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024:
            return f"{size:.1f} {unit}" if unit != "B" else f"{int(size)} {unit}"
        size /= 1024
    return f"{size:.1f} TB"


@jobs_app.command()
def share(
    job_id: Annotated[str, Argument(help="Job ID (UUID) to share.")],
    share_org: Annotated[
        list[str] | None,
        Option("--org", help="Organization to share with. Repeatable."),
    ] = None,
    share_user: Annotated[
        list[str] | None,
        Option(
            "--user",
            help="GitHub username to share with via their personal org. Repeatable.",
        ),
    ] = None,
    yes: Annotated[
        bool,
        Option(
            "--yes",
            "-y",
            help="Confirm sharing with organizations you are not a member of.",
        ),
    ] = False,
    debug: Annotated[
        bool,
        Option("--debug", help="Show extra details on failure.", hidden=True),
    ] = False,
) -> None:
    """Add org or user shares to an already-uploaded job."""
    from harbor.cli.job_sharing import (
        confirm_non_member_org_shares,
        format_share_summary,
        normalize_share_values,
    )
    from harbor.upload.db_client import UploadDB

    try:
        parsed_job_id = UUID(job_id)
    except ValueError:
        console.print("[red]Error:[/red] job_id must be a UUID.")
        raise SystemExit(1) from None

    requested_share_orgs = normalize_share_values(share_org)
    requested_share_users = normalize_share_values(share_user)
    if not requested_share_orgs and not requested_share_users:
        console.print("[red]Error:[/red] provide --org or --user.")
        raise SystemExit(1)

    async def _share() -> None:
        confirm_non_member_orgs = await confirm_non_member_org_shares(
            requested_share_orgs,
            yes=yes,
        )
        db = UploadDB()
        await db.get_user_id()
        result = await db.add_job_shares(
            job_id=parsed_job_id,
            org_names=requested_share_orgs,
            usernames=requested_share_users,
            confirm_non_member_orgs=confirm_non_member_orgs,
        )
        share_summary = format_share_summary(
            share_orgs=[
                org["name"]
                for org in result.get("orgs", [])
                if isinstance(org, dict) and org.get("name")
            ],
            share_users=[
                user.get("github_username") or user.get("id")
                for user in result.get("users", [])
                if isinstance(user, dict)
                and (user.get("github_username") or user.get("id"))
            ],
        )
        console.print(f"Updated job shares for {parsed_job_id}.")
        if share_summary:
            console.print(f"Shared with {share_summary}")

    try:
        run_async(_share())
    except SystemExit:
        raise
    except Exception as exc:
        console.print(f"[red]Error:[/red] {type(exc).__name__}: {exc}")
        if debug:
            raise
        raise SystemExit(1) from None


@jobs_app.command()
def download(
    job_id: Annotated[str, Argument(help="Job ID (UUID) to download.")],
    output_dir: Annotated[
        Path,
        Option(
            "--output-dir",
            "-o",
            help="Directory in which to materialize the job_dir. Defaults to ./jobs.",
        ),
    ] = Path("jobs"),
    overwrite: Annotated[
        bool,
        Option("--overwrite", help="Replace an existing job_dir if present."),
    ] = False,
    include_retries: Annotated[
        bool,
        Option(
            "--include-retries",
            help="Include retry history when reconstructing from trial archives.",
        ),
    ] = False,
    debug: Annotated[
        bool,
        Option("--debug", help="Show extra details on failure.", hidden=True),
    ] = False,
) -> None:
    """Download a job (and all its trials) from the Harbor platform."""
    from uuid import UUID

    from rich.console import Console
    from typer import echo

    from harbor.cli.utils import run_async

    local_console = Console()

    try:
        job_uuid = UUID(job_id)
    except ValueError:
        echo(f"Error: {job_id!r} is not a valid UUID.")
        raise SystemExit(1) from None

    async def _download() -> None:
        from harbor.auth.errors import AuthenticationError
        from harbor.download.downloader import Downloader

        downloader = Downloader()

        # Friendly auth error — mirror upload's behaviour.
        try:
            await downloader.db.get_user_id()
        except (AuthenticationError, RuntimeError) as exc:
            echo(str(exc))
            raise SystemExit(1) from None

        # Pass the user's path through as-is (no `.resolve()`) so the
        # summary + suggested `harbor view` / `harbor analyze` commands
        # print in the same relative/absolute form the user typed. Default
        # `-o jobs` stays `jobs` instead of expanding to an unwieldy
        # cwd-prefixed absolute path.
        with local_console.status(f"[cyan]Downloading job {job_uuid}..."):
            result = await downloader.download_job(
                job_uuid,
                output_dir,
                overwrite=overwrite,
                include_retries=include_retries,
            )

        echo(
            f"Downloaded {result.job_name} "
            f"({_humanize_bytes(result.archive_size_bytes)}) "
            f"in {result.download_time_sec:.2f}s → {result.output_dir}"
        )
        if result.reconstructed_from_trials is True:
            echo(
                "Warning: full job archive was unavailable; reconstructed from "
                f"{result.n_trials_downloaded} trial archive(s)."
            )
            if result.n_trials_missing:
                echo(
                    f"Warning: {result.n_trials_missing} trial(s) were missing "
                    "downloadable archives. See "
                    f"{result.manifest_path or result.output_dir / 'download_manifest.json'}"
                )
        echo(f"Inspect locally by running `harbor view {result.output_dir.parent}`")
        echo(f"Analyze trajectories by running `harbor analyze {result.output_dir}`")

    try:
        run_async(_download())
    except SystemExit:
        raise
    except Exception as exc:
        echo(f"Error: {type(exc).__name__}: {exc}")
        if debug:
            raise
        raise SystemExit(1) from None


def _primary_reward(result: TrialResult) -> float | None:
    if result.verifier_result is None or not result.verifier_result.rewards:
        return None
    rewards = result.verifier_result.rewards
    if "reward" in rewards:
        return float(rewards["reward"])
    if len(rewards) == 1:
        return float(next(iter(rewards.values())))
    return None


def _print_regrade_delta(trial_results: list[TrialResult]) -> None:
    """Compare regraded rewards against the recorded source trial rewards."""
    from harbor.trial.regrade import find_cached_source_trial_dir

    pairs: list[tuple[float, float]] = []
    n_compared = 0
    n_up = 0
    n_down = 0
    for result in trial_results:
        source_trial = result.config.source_trial
        if source_trial is None:
            continue
        source_trial_dir = source_trial.path
        if source_trial_dir is None and source_trial.trial_id is not None:
            source_trial_dir = find_cached_source_trial_dir(
                result.config.trials_dir, source_trial.trial_id
            )
        if source_trial_dir is None:
            continue
        source_paths = TrialPaths(trial_dir=source_trial_dir)
        try:
            source_result = TrialResult.model_validate_json(
                source_paths.result_path.read_text()
            )
        except (OSError, ValidationError):
            continue
        old_reward = _primary_reward(source_result)
        new_reward = _primary_reward(result)
        if old_reward is None or new_reward is None:
            continue
        n_compared += 1
        pairs.append((old_reward, new_reward))
        if new_reward > old_reward:
            n_up += 1
        elif new_reward < old_reward:
            n_down += 1

    if not pairs:
        return

    old_mean = sum(old for old, _ in pairs) / len(pairs)
    new_mean = sum(new for _, new in pairs) / len(pairs)
    n_changed = n_up + n_down
    console.print(
        f"Regrade delta over {n_compared} trial(s): "
        f"{n_changed} changed ({n_up} up, {n_down} down), "
        f"mean reward {old_mean:.3f} → {new_mean:.3f}"
    )


@jobs_app.command()
def regrade(
    source: Annotated[
        str,
        Argument(
            help="Source job directory, or a Harbor Hub job UUID to "
            "download and re-score. Never modified."
        ),
    ],
    task_paths: Annotated[
        list[Path] | None,
        Option(
            "-p",
            "--task-path",
            help="Task directory (or a directory of task directories) providing "
            "the verifiers to regrade with; matched to trials by task name. "
            "Can be used multiple times.",
            show_default=False,
        ),
    ] = None,
    task_refs: Annotated[
        list[str] | None,
        Option(
            "-t",
            "--task",
            help="Registry task providing a verifier (org/name[@ref]). "
            "Can be used multiple times.",
            show_default=False,
        ),
    ] = None,
    dataset_specs: Annotated[
        list[str] | None,
        Option(
            "-d",
            "--dataset",
            help="Dataset providing verifier tasks: a registry name@version "
            "(e.g. 'dataset@1.0') or a package org/name[@ref]. Can be used "
            "multiple times.",
            show_default=False,
        ),
    ] = None,
    launch: Annotated[
        bool,
        Option(
            "--launch",
            help="Create one hosted regrade job for selected trials.",
            rich_help_panel="Harbor Hub",
        ),
    ] = False,
    org: Annotated[
        str | None,
        Option(
            "--org",
            help="Source organization; required with --launch.",
            rich_help_panel="Harbor Hub",
        ),
    ] = None,
    stored_secret: Annotated[
        list[str] | None,
        Option(
            "--stored-secret",
            help="Stored verifier credential name. Repeatable.",
            rich_help_panel="Harbor Hub",
        ),
    ] = None,
    one_off_secret: Annotated[
        list[str] | None,
        Option(
            "--one-off-secret",
            help="Verifier credential from the local environment. Repeatable.",
            rich_help_panel="Harbor Hub",
        ),
    ] = None,
    registry_credential: Annotated[
        list[str] | None,
        Option(
            "--registry-secret",
            metavar="HOST=NAME_OR_ID",
            help="Select a stored image-pull secret when multiple credentials match a "
            "host. Requires --launch. Repeatable.",
            show_default=False,
            rich_help_panel="Harbor Hub",
        ),
    ] = None,
    use_static_ip: Annotated[
        bool,
        Option(
            "--use-static-ip",
            help="Use a static outbound IP. Requires --launch.",
            rich_help_panel="Harbor Hub",
        ),
    ] = False,
    yes: Annotated[
        bool,
        Option(
            "-y",
            "--yes",
            help="Accept hosted launch and local task upload.",
            rich_help_panel="Harbor Hub",
        ),
    ] = False,
    dry_run: Annotated[
        bool,
        Option(
            "--dry-run",
            help="Validate without queuing work.",
            rich_help_panel="Harbor Hub",
        ),
    ] = False,
    environment: Annotated[
        str | None,
        Option(
            "-e",
            "--env",
            metavar=_ENV_METAVAR,
            help=f"Environment type for the verifier environments (default: "
            f"{EnvironmentType.DOCKER.value}) or a custom environment import "
            "path (module.path:ClassName).",
            show_default=False,
        ),
    ] = None,
    verifier_env: Annotated[
        list[str] | None,
        Option(
            "--ve",
            "--verifier-env",
            help="Environment variable for the verifier in the format KEY=VALUE. "
            "Can be used multiple times.",
            show_default=False,
        ),
    ] = None,
    verifier: Annotated[
        str | None,
        Option(
            "--verifier",
            help="Custom verifier import path (module.path:ClassName). "
            "Replaces the tasks' test-script verifiers.",
            show_default=False,
        ),
    ] = None,
    verifier_kwargs: Annotated[
        list[str] | None,
        Option(
            "--verifier-kwarg",
            help="Additional verifier kwarg in the format 'key=value'. "
            "Requires --verifier. Can be used multiple times.",
            show_default=False,
        ),
    ] = None,
    n_concurrent_trials: Annotated[
        int | None,
        Option(
            "-n",
            "--n-concurrent",
            help=f"Number of concurrent regrades to run (default: {
                JobConfig.model_fields['n_concurrent_trials'].default
            })",
            show_default=False,
        ),
    ] = None,
    job_name: Annotated[
        str | None,
        Option(
            "--job-name",
            help="Name of the new job (default: current timestamp)",
            show_default=False,
        ),
    ] = None,
    jobs_dir: Annotated[
        Path | None,
        Option(
            "-o",
            "--jobs-dir",
            help=f"Directory to store the new job (default: {
                JobConfig.model_fields['jobs_dir'].default
            })",
            show_default=False,
        ),
    ] = None,
):
    """Re-run verification for every trial of a recorded job.

    SOURCE is a local job directory or a Hub job UUID. Local execution downloads
    Hub sources and creates a new job directory seeded with source agent logs
    and artifacts. With --launch, SOURCE must be an existing Hub job UUID;
    the new job runs remotely using the recorded artifacts.

    Local regrade supports multi-step tasks when every step uses a separate
    verifier and each source contains the same completed step sequence.
    Hosted regrade currently supports single-step tasks with separate verifiers.
    """
    from harbor.job import Job
    from harbor.models.trial.config import VerifierConfig
    from harbor.trial.regrade import (
        RegradeError,
        expand_task_path,
        resolve_source_job,
    )

    if not task_paths and not task_refs and not dataset_specs:
        console.print(
            "[red]Error:[/red] Provide at least one verifier source via "
            "-p/--task-path, -t/--task, or -d/--dataset."
        )
        raise SystemExit(1)

    try:
        task_dirs: list[Path] = []
        for task_path in task_paths or []:
            task_dirs.extend(expand_task_path(task_path))

        tasks = [TaskConfig(path=task_dir) for task_dir in dict.fromkeys(task_dirs)]
        for task_ref in task_refs or []:
            from harbor.models.package.reference import PackageReference

            ref = PackageReference.parse(task_ref)
            tasks.append(TaskConfig(name=ref.name, ref=ref.ref))

        datasets = []
        for spec in dataset_specs or []:
            name, _, version = spec.partition("@")
            if "/" in name:
                datasets.append(DatasetConfig(name=name, ref=version or "latest"))
            else:
                datasets.append(DatasetConfig(name=name, version=version or None))
    except (ValueError, ValidationError) as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise SystemExit(1) from None

    if launch:
        from harbor.cli.hosted_jobs import (
            prepare_hosted_job_regrade,
            run_hosted_regrade,
        )

        if environment or verifier or verifier_kwargs:
            raise ValueError(
                "Hosted regrade uses the task verifier and hosted environment."
            )
        if not org:
            raise ValueError("--launch regrade requires --org matching the source job.")
        try:
            source_job_id = UUID(source)
        except ValueError:
            raise ValueError(
                "--launch job regrade requires an existing Hub job UUID."
            ) from None
        try:
            selection, tasks = run_async(
                prepare_hosted_job_regrade(
                    source_job_id,
                    tasks,
                    datasets,
                )
            )
        except DATASET_RESOLUTION_ERRORS as exc:
            abort_dataset_resolution(console, exc, "No job was started.")
        run_hosted_regrade(
            source=selection,
            tasks=tasks,
            org=org,
            stored_secret=stored_secret,
            one_off_secret=one_off_secret,
            registry_credential=registry_credential,
            use_static_ip=use_static_ip,
            verifier_env=verifier_env,
            job_name=job_name,
            n_concurrent_trials=n_concurrent_trials,
            yes=yes,
            dry_run=dry_run,
            console=console,
        )
        return
    if (
        org
        or stored_secret
        or one_off_secret
        or registry_credential
        or use_static_ip
        or dry_run
    ):
        raise ValueError("Hosted regrade options require --launch.")

    effective_jobs_dir = (
        jobs_dir if jobs_dir is not None else JobConfig.model_fields["jobs_dir"].default
    )
    try:
        with console.status(f"[cyan]Resolving source job {source}..."):
            source_job, job_dir = run_async(
                resolve_source_job(
                    source, jobs_dir=effective_jobs_dir, action="regrade"
                )
            )
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise SystemExit(1) from None
    if source_job.type == "hub":
        console.print(f"Source job: {job_dir}")

    if not (job_dir / "config.json").exists():
        console.print(
            f"[red]Error:[/red] {job_dir} is not a job directory (missing config.json)."
        )
        raise SystemExit(1)

    environment_config = EnvironmentConfig()
    if environment is not None:
        env_type, env_import_path = resolve_environment_spec(environment)
        environment_config.type = env_type
        environment_config.import_path = env_import_path

    verifier_config = VerifierConfig()
    if verifier_env is not None:
        verifier_config.env.update(parse_env_vars(verifier_env))
    if verifier is not None:
        verifier_config.import_path = verifier
    if verifier_kwargs is not None:
        verifier_config.kwargs.update(parse_kwargs(verifier_kwargs))

    config = JobConfig(
        source_jobs=[source_job],
        tasks=tasks,
        datasets=datasets,
        environment=environment_config,
        verifier=verifier_config,
    )
    if n_concurrent_trials is not None:
        config.n_concurrent_trials = n_concurrent_trials
    if job_name is not None:
        config.job_name = job_name
    if jobs_dir is not None:
        config.jobs_dir = jobs_dir

    _run_preflight(config)

    async def _run_job():
        # Derivation failures (unregradable source, uncovered tasks, ...) are
        # user errors, not crashes; runtime errors during job.run() are
        # recorded per trial as usual.
        try:
            job = await Job.create(config)
        except DATASET_RESOLUTION_ERRORS as exc:
            abort_dataset_resolution(console, exc, "No job was started.")
        except (ValueError, RegradeError) as exc:
            console.print(f"[red]Error:[/red] {exc}")
            raise SystemExit(1) from None
        console.print(f"Regrading {len(job)} trial(s) from {job_dir}")
        console.print(f"New job directory: {job.job_dir}")
        return job.job_dir, await job.run()

    new_job_dir, job_result = run_async(_run_job())

    print_job_results_tables(job_result)
    if job_result.trial_results:
        _print_regrade_delta(job_result.trial_results)
    # The per-trial source seeds are scratch, not part of the job record;
    # an interrupted run keeps them so resume does not re-download.
    shutil.rmtree(new_job_dir / ".sources", ignore_errors=True)


jobs_app.command()(start)
jobs_app.command("schema")(job_schema)

jobs_app.command(
    "init", context_settings={"allow_extra_args": True, "ignore_unknown_options": True}
)(job_init)

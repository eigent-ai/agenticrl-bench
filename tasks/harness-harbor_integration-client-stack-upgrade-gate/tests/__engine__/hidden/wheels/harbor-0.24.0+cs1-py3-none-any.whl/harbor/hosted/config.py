"""Configuration extensions used by Harbor Hub interfaces."""

from __future__ import annotations

from enum import Enum
from typing import Self
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from harbor.hosted.api import ENV_VAR_RE
from harbor.models.job.config import JobConfig, RetryConfig
from harbor.models.trial.config import AgentConfig, TrialConfig


class HostedRegradeSource(BaseModel):
    """Explicit source selection for one hosted regrade job."""

    model_config = ConfigDict(extra="forbid")
    source_trial_ids: list[UUID] = Field(min_length=1, max_length=50_000)
    source_job_id: UUID | None = None

    @model_validator(mode="after")
    def validate_selection(self) -> Self:
        if len(set(self.source_trial_ids)) != len(self.source_trial_ids):
            raise ValueError("Source trial IDs must be distinct.")
        if len(self.source_trial_ids) > 1 and self.source_job_id is None:
            raise ValueError("A batch regrade requires a source job ID.")
        return self

    def request_payload(self) -> dict[str, object]:
        if self.source_job_id is None:
            return {"source_trial_id": str(self.source_trial_ids[0])}
        return self.model_dump(mode="json")


class CredentialMode(str, Enum):
    """Credential delivery selection."""

    GATEWAY = "gateway"
    DIRECT = "direct"


class JobSecretSource(BaseModel):
    """Reference to a local environment variable."""

    model_config = ConfigDict(extra="forbid")

    from_env: str = Field(
        min_length=1,
        description="Local environment variable containing the secret value.",
    )


class HostedAgentConfig(AgentConfig):
    """Agent configuration with named credential selections."""

    model_config = ConfigDict(extra="forbid")

    secrets: list[str] | None = Field(
        default=None,
        description=(
            "Secret names selected for this agent. None leaves the selection "
            "unspecified; [] explicitly selects none."
        ),
    )
    source: dict[str, object] | None = Field(
        default=None,
        description="Optional structured agent source descriptor.",
    )

    @model_validator(mode="after")
    def _validate_secret_names(self) -> Self:
        if self.secrets is None:
            return self
        seen: set[str] = set()
        for name in self.secrets:
            if ENV_VAR_RE.fullmatch(name) is None:
                raise ValueError(
                    f"agent secret name {name!r} must look like OPENAI_API_KEY"
                )
            if name in seen:
                raise ValueError(f"agent secret name {name!r} is duplicated")
            seen.add(name)
        return self


_HOSTED_RETRY_EXCLUDE_EXCEPTIONS = {
    "CredentialError",
    "NoCredentialError",
    "OutputTokenExceededError",
    "ContextWindowExceededError",
    "ApiProviderResourceNotFoundError",
    "SandboxLikelyOutOfMemoryError",
    "DockerComposeNeedsLintError",
    "MissingApiKeyError",
    "HostedUserError",
    "ImportPathNotAllowedError",
    "SourceRejectedError",
    "RegistryAuthError",
    "RegistryCredentialInvalidError",
    "RegistryImageAccessError",
    "RegistryImageNotFoundError",
    "PrebuiltImagePlatformError",
}


def _hosted_retry_exclude_exceptions() -> set[str]:
    """Return Harbor's defaults plus deterministic hosted-only outcomes."""

    return set(RetryConfig().exclude_exceptions or ()) | set(
        _HOSTED_RETRY_EXCLUDE_EXCEPTIONS
    )


class HostedRetryConfig(RetryConfig):
    """Retry defaults for hosted jobs without changing portable local runs."""

    exclude_exceptions: set[str] | None = Field(
        default_factory=_hosted_retry_exclude_exceptions,
        description="Exception types to NOT retry on. Takes precedence over "
        "include_exceptions.",
    )


class HostedJobConfig(JobConfig):
    """Additional job configuration accepted by Harbor Hub."""

    model_config = ConfigDict(extra="forbid")

    organization: str | None = Field(
        default=None,
        description="Organization associated with the request.",
    )
    credential_mode: CredentialMode | None = Field(
        default=None,
        description="Credential delivery mode.",
    )
    static_outbound_ip: bool | None = Field(
        default=None,
        strict=True,
        description=(
            "Use static outbound IP for trial sandboxes. None lets the Hub "
            "choose the default for the credential mode."
        ),
    )
    agents: list[HostedAgentConfig] = Field(
        default_factory=lambda: [HostedAgentConfig()]
    )
    retry: HostedRetryConfig = Field(default_factory=HostedRetryConfig)
    job_secrets: dict[str, JobSecretSource] = Field(
        default_factory=dict,
        description=(
            "Environment-backed secret references keyed by variable name. "
            "Every entry must be selected by an agent."
        ),
    )

    @model_validator(mode="after")
    def _validate_static_outbound_ip(self) -> Self:
        if (
            self.credential_mode is CredentialMode.GATEWAY
            and self.static_outbound_ip is False
        ):
            raise ValueError("static_outbound_ip must be true in gateway mode")
        return self

    @field_validator("retry", mode="before")
    @classmethod
    def _apply_hosted_retry_defaults(cls, value: object) -> object:
        # Preserve explicit overrides while applying hosted defaults to fields
        # omitted by programmatic callers, just as for config-file mappings.
        if isinstance(value, RetryConfig) and not isinstance(value, HostedRetryConfig):
            defaults = RetryConfig().model_dump()
            # In-place set mutations are not recorded in model_fields_set.
            return {
                name: item
                for name, item in value.model_dump().items()
                if name in value.model_fields_set or item != defaults.get(name)
            }
        return value

    @model_validator(mode="after")
    def _validate_job_secret_routing(self) -> Self:
        selected = {name for agent in self.agents for name in (agent.secrets or [])}
        for name in self.job_secrets:
            if ENV_VAR_RE.fullmatch(name) is None:
                raise ValueError(
                    f"job secret name {name!r} must look like OPENAI_API_KEY"
                )
        unused = sorted(set(self.job_secrets) - selected)
        if unused:
            raise ValueError(
                "job secrets are not selected by any agent: " + ", ".join(unused)
            )
        return self


class HostedTrialConfig(TrialConfig):
    """Trial configuration with Harbor Hub extensions."""

    model_config = ConfigDict(extra="forbid")

    credential_mode: CredentialMode = Field(
        description="Credential delivery mode for this trial."
    )
    static_outbound_ip: bool = Field(
        default=True,
        strict=True,
        description=(
            "Use static outbound IP for this sandbox. Defaults to true for "
            "persisted trials that predate this option; the Hub materializes "
            "the selected value for new submissions."
        ),
    )
    agent: HostedAgentConfig = Field(default_factory=HostedAgentConfig)

    @model_validator(mode="after")
    def _validate_static_outbound_ip(self) -> Self:
        if (
            self.credential_mode is CredentialMode.GATEWAY
            and not self.static_outbound_ip
        ):
            raise ValueError("static_outbound_ip must be true in gateway mode")
        return self

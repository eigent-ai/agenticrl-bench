import base64
import json
import shlex
from collections.abc import Iterable
from datetime import datetime, timezone
from pathlib import Path
from typing import Annotated, Any, ClassVar, Literal, override

from pydantic import BeforeValidator, Field

from harbor.agents.capabilities import AgentCapabilities
from harbor.agents.installed.antigravity_base_url import validate_base_url
from harbor.agents.installed.base import (
    AgentAuthenticationError,
    ApiInternalServerError,
    ApiOverloadedError,
    ApiRateLimitError,
    ApiResponseStalledError,
    ApiUsageLimitError,
    BaseInstalledAgent,
    ErrorPattern,
    NonZeroAgentExitCodeError,
    UnknownApiError,
    with_prompt_template,
)
from harbor.agents.options import Cli, InstalledAgentOptions
from harbor.environments.base import BaseEnvironment
from harbor.utils.env import parse_bool_env_value
from harbor.models.agent.context import AgentContext
from harbor.models.agent.name import AgentName
from harbor.models.trajectories import (
    Agent,
    ContentPart,
    FinalMetrics,
    ImageSource,
    Metrics,
    Observation,
    ObservationResult,
    Step,
    ToolCall,
    Trajectory,
)

_ImageMediaType = Literal["image/jpeg", "image/png", "image/gif", "image/webp"]
_ReasoningEffort = Literal["minimal", "low", "medium", "high"]
_REASONING_EFFORT_CHOICES = frozenset(("minimal", "low", "medium", "high"))
_FLASH_ONLY_REASONING_EFFORTS = frozenset(("minimal", "medium"))
# agy 1.1.x step-transcript record types (parser adopted from #2687).
_CURRENT_TRANSCRIPT_TYPES = frozenset(("USER_INPUT", "PLANNER_RESPONSE"))
_INTERNAL_TRANSCRIPT_TYPES = frozenset(
    ("CHECKPOINT", "CONVERSATION_HISTORY", "EPHEMERAL_MESSAGE")
)


def _validate_antigravity_reasoning_effort(value: Any) -> Any:
    if value is not None and value not in _REASONING_EFFORT_CHOICES:
        raise ValueError(
            f"Invalid value for 'reasoning_effort': '{value}'. "
            f"Valid values: {', '.join(sorted(_REASONING_EFFORT_CHOICES))}"
        )
    return value


class AntigravityCliOptions(InstalledAgentOptions):
    sandbox: Annotated[bool | None, Cli("--sandbox")] = Field(
        default=None,
        description="Run Antigravity CLI in a sandbox.",
    )
    reasoning_effort: Annotated[
        _ReasoningEffort | None,
        BeforeValidator(_validate_antigravity_reasoning_effort),
    ] = Field(
        default=None,
        description="Model reasoning effort.",
    )
    binary_path: str | None = Field(
        default=None,
        description=(
            "Local agy binary to upload instead of running the released installer."
        ),
    )


class AntigravityCli(BaseInstalledAgent):
    """
    The antigravity-cli agent uses Google's Antigravity CLI tool to solve tasks.

    Authentication follows the documented headless path
    (https://antigravity.google/docs/cli/install#using-a-gemini-api-key):
    ``GEMINI_API_KEY`` must be set (host env or ``--ae``), and the agent writes
    ``"modelProvider": "gemini"`` into ``~/.gemini/antigravity-cli/settings.json``
    so agy skips the interactive sign-in. ``GOOGLE_API_KEY`` is accepted as an
    alias and forwarded to agy as ``GEMINI_API_KEY``, the only variable it
    reads. ``GOOGLE_GEMINI_BASE_URL`` optionally points model requests at a
    Gemini-compatible endpoint.

    Alternatively, ``AGY_ADC_AUTH=true`` selects the enterprise path
    (https://antigravity.google/docs/enterprise#application-default-credentials-adc-in-antigravity-cli):
    agy authenticates from Application Default Credentials already present in
    the container, and no API key or ``modelProvider`` is involved. ADC
    supports Gemini 3 Flash and newer models only.

    ``AGY_CLI_*`` environment variables from ``--ae`` or the host are forwarded
    to agy, and ``binary_path`` uploads a local agy build in place of the
    released installer.
    """

    @override
    def get_version_command(self) -> str | None:
        return "$HOME/.local/bin/agy --version"

    capabilities = AgentCapabilities(atif=True, skills=True, mcp_servers=True)
    options_model = AntigravityCliOptions
    options: AntigravityCliOptions

    # agy (>= 1.2.6) writes a single-line marker to stderr on fatal errors:
    #   AGY_ERROR: {"short_error":"...","status":"RESOURCE_EXHAUSTED","retryable":true,...}
    # "status" is a google.rpc.Code name (covers both HTTP and gRPC) and precedes
    # "retryable" in the serialized struct. Each pattern matches to end-of-line so
    # it outranks base free-text needles inside short_error (rightmost match wins);
    # list order breaks ties so specific statuses beat the retryable/non-retryable
    # catch-alls.
    ERROR_PATTERNS: ClassVar[list[ErrorPattern]] = [
        *BaseInstalledAgent.ERROR_PATTERNS,
        ErrorPattern(
            r'AGY_ERROR:.*"status":"RESOURCE_EXHAUSTED".*"retryable":\s*true.*',
            ApiRateLimitError,
        ),
        ErrorPattern(
            r'AGY_ERROR:.*"status":"RESOURCE_EXHAUSTED".*"retryable":\s*false.*',
            ApiUsageLimitError,
        ),
        ErrorPattern(
            r'AGY_ERROR:.*"status":"UNAVAILABLE".*"retryable":\s*true.*',
            ApiOverloadedError,
        ),
        ErrorPattern(
            r'AGY_ERROR:.*"status":"INTERNAL".*"retryable":\s*true.*',
            ApiInternalServerError,
        ),
        ErrorPattern(
            r'AGY_ERROR:.*"status":"DEADLINE_EXCEEDED".*"retryable":\s*true.*',
            ApiResponseStalledError,
        ),
        ErrorPattern(
            r'AGY_ERROR:.*"status":"UNAUTHENTICATED".*',
            AgentAuthenticationError,
        ),
        ErrorPattern(r'AGY_ERROR:.*"retryable":\s*true.*', UnknownApiError),
        ErrorPattern(
            r'AGY_ERROR:.*"retryable":\s*false.*',
            NonZeroAgentExitCodeError,
        ),
    ]

    # Counter for generating unique image filenames within a session
    _image_counter: int = 0

    # Headless agy gives up on a --prompt run after 5 minutes by default;
    # agentic trials routinely run longer, so raise the ceiling and leave the
    # real budget to Harbor's own trial timeout.
    _PRINT_TIMEOUT = "24h"

    # Model discovery is only an optimization. Keep a hung catalog request
    # from consuming the task's entire agent timeout before the prompt is sent.
    _MODEL_LIST_TIMEOUT_SEC = 15

    # How much of agy's stderr is replayed onto the exec's own stderr for error
    # classification. The replay is a tail, so a cap below the whole log can cut
    # off the very diagnostic it exists to carry; it is sized to clear a whole
    # run rather than to be tight. Across 68 captured runs agy's glog stderr
    # peaked at 27.8 KB (232 lines, ~125 B/line), and an ADC-heavy run logging
    # the ~1k lines seen in the field would be ~125 KB. What matters for
    # resources is that the replay is bounded at all: uncapped, a pathologically
    # verbose run pushes its whole log through the environment's buffered
    # command result.
    _STDERR_REPLAY_BYTES = 256 * 1024

    # Set when --ae/extra_env carried an explicit AGY_ADC_AUTH=false: the
    # entry is removed (agy documents disable as *unset*, so the container
    # must not see a literal "false") but the per-run "off" still has to
    # suppress a host-level AGY_ADC_AUTH=true.
    _adc_disabled_via_extra_env: bool = False

    @staticmethod
    @override
    def name() -> str:
        return AgentName.ANTIGRAVITY_CLI.value

    def __init__(
        self,
        *args: Any,
        reasoning_effort: _ReasoningEffort | None = None,
        **kwargs: Any,
    ):
        super().__init__(*args, reasoning_effort=reasoning_effort, **kwargs)
        self._validate_reasoning_effort(self.options.reasoning_effort, self.model_name)
        self._sanitize_auth_extra_env()

    def _sanitize_auth_extra_env(self) -> None:
        """Make extra_env auth entries match the agent's auth semantics.

        Trial overlays raw ``extra_env`` onto every agent exec ABOVE the env
        dict ``run()`` builds, so a value here reaches agy verbatim no matter
        what ``run()`` resolved. Empty auth values mean unset and are dropped
        (an empty ``--ae GEMINI_API_KEY=`` must not re-shadow a resolved key),
        and ``AGY_ADC_AUTH`` is canonicalized to the documented ``"true"`` or
        dropped when falsy.
        """
        for name in (
            "GEMINI_API_KEY",
            "GOOGLE_API_KEY",
            "GOOGLE_GEMINI_BASE_URL",
            "GOOGLE_APPLICATION_CREDENTIALS",
            *[k for k in self._extra_env if k.startswith("AGY_CLI_")],
        ):
            if name in self._extra_env and not self._extra_env[name]:
                del self._extra_env[name]
        # agy only reads GEMINI_API_KEY: rename a GOOGLE_API_KEY alias rather
        # than duplicating it, so only the honored name rides Trial's exec
        # overlay while the scrubber still sees the value. An explicit
        # GEMINI_API_KEY wins.
        alias = self._extra_env.pop("GOOGLE_API_KEY", None)
        if alias is not None and "GEMINI_API_KEY" not in self._extra_env:
            self._extra_env["GEMINI_API_KEY"] = alias
        raw_adc = self._extra_env.get("AGY_ADC_AUTH")
        if raw_adc is not None:
            # A passed-through empty means unset; an explicit false is a
            # per-run "off" that must suppress a host-level opt-in; non-empty
            # garbage still raises — it is ambiguous about the billing path.
            if not raw_adc.strip():
                del self._extra_env["AGY_ADC_AUTH"]
            elif parse_bool_env_value(raw_adc, name="AGY_ADC_AUTH"):
                self._extra_env["AGY_ADC_AUTH"] = "true"
            else:
                del self._extra_env["AGY_ADC_AUTH"]
                self._adc_disabled_via_extra_env = True
        if self._use_adc_auth():
            # Trial overlays extra_env onto every exec; an ADC run's contract
            # is "no API key involved", so key material must not ride the
            # overlay into the container.
            for name in (
                "GEMINI_API_KEY",
                "GOOGLE_API_KEY",
                "GOOGLE_GEMINI_BASE_URL",
            ):
                self._extra_env.pop(name, None)

    @staticmethod
    def _validate_reasoning_effort(
        reasoning_effort: _ReasoningEffort | None,
        model_name: str | None,
    ) -> None:
        if (
            reasoning_effort is not None
            and reasoning_effort not in _REASONING_EFFORT_CHOICES
        ):
            raise ValueError(
                f"Invalid value for 'reasoning_effort': '{reasoning_effort}'. "
                f"Valid values: {', '.join(sorted(_REASONING_EFFORT_CHOICES))}"
            )
        if reasoning_effort is None or model_name is None:
            return
        if "2.5" in model_name:
            raise ValueError(
                "Gemini 2.5 models do not support reasoning_effort. "
                "Use a Gemini 3 model, or add explicit thinking_budget support."
            )
        if (
            reasoning_effort in _FLASH_ONLY_REASONING_EFFORTS
            and "flash" not in model_name
        ):
            raise ValueError(
                f"Gemini model '{model_name}' does not support "
                f"reasoning_effort='{reasoning_effort}'. "
                "Use 'low' or 'high', or choose a Gemini 3 Flash model."
            )

    @override
    async def install(self, environment: BaseEnvironment) -> None:
        # Provision the binary only; run() writes the full settings.json
        # (auth provider, model registration, skills, MCP) just before agy
        # starts, so nothing else needs to exist beforehand.
        binary_path = self.options.binary_path
        if binary_path:
            resolved_binary = Path(binary_path).expanduser()
            if not resolved_binary.is_file():
                raise FileNotFoundError(
                    f"binary_path does not point at a file: {binary_path}"
                )
            # Needed for TLS when skipping the curl-based installer.
            await self.ensure_system_dependencies(environment, ("ca_certificates",))
            await environment.upload_file(str(resolved_binary), "/tmp/agy-custom")
            # environment.upload_file lands as root while preserving local file
            # mode (often 0700), so make it world-readable before exec_as_agent.
            await self.exec_as_root(environment, command="chmod 755 /tmp/agy-custom")
            # Match the path install.sh writes to so version/run commands are unchanged.
            await self.exec_as_agent(
                environment,
                command=(
                    "install -D -m 755 /tmp/agy-custom $HOME/.local/bin/agy && "
                    "rm -f /tmp/agy-custom"
                ),
            )
        else:
            await self.ensure_system_dependencies(environment, ("curl",))
            await self.exec_as_agent(
                environment,
                command="curl -fsSL https://antigravity.google/cli/install.sh | bash",
            )
        await self.exec_as_agent(
            environment,
            command="$HOME/.local/bin/agy --version",
        )

    def _use_adc_auth(self) -> bool:
        """True when AGY_ADC_AUTH opts this run into enterprise ADC auth.

        Documented for headless use on the enterprise page; the CLI then
        authenticates from Application Default Credentials against the Gemini
        Enterprise Agent Platform, with no modelProvider or API key involved.
        An explicit opt-in wins over an ambient host-environment API key so a
        stale shell export cannot flip the run back to Gemini API billing.
        In ADC mode ``_sanitize_auth_extra_env`` also drops ``--ae`` key
        material so it cannot ride Trial's exec overlay into the container.
        An exported-but-empty value means unset; non-empty garbage raises
        rather than silently choosing a billing path; an explicit
        ``--ae AGY_ADC_AUTH=false`` is a per-run "off" that beats a
        host-level opt-in.
        """
        if self._adc_disabled_via_extra_env:
            return False
        value = self._get_env("AGY_ADC_AUTH")
        if value is None or not value.strip():
            return False
        return parse_bool_env_value(value, name="AGY_ADC_AUTH")

    def _validate_base_url(self, base_url: str) -> None:
        """Enforce the transport policy for a custom Gemini endpoint."""
        validate_base_url(base_url, self._get_env, self.logger)

    def _find_api_key(self) -> str | None:
        """Return the first non-empty GEMINI_API_KEY/GOOGLE_API_KEY value.

        Walks the env sources in precedence order (``--ae``/extra_env before
        the host environment, matching ``_get_env``), preferring
        ``GEMINI_API_KEY`` over the ``GOOGLE_API_KEY`` alias within each
        source. Unlike ``_get_env``, empty values read as unset: they neither
        satisfy the key requirement nor shadow a usable value in the same or a
        lower-precedence source.
        """
        for source in self._env_sources():
            for name in ("GEMINI_API_KEY", "GOOGLE_API_KEY"):
                if source.get(name):
                    return source[name]
        return None

    def _resolve_api_key(self) -> str:
        """Resolve the Gemini API key or fail before agy can hang on sign-in.

        Without a key (and with ``modelProvider`` consequently unset) agy
        falls back to interactive browser OAuth, which in a headless container
        prints a sign-in URL and dies on its own timeout — burning the whole
        trial. ``GOOGLE_API_KEY`` is accepted as an alias since other Google
        tooling conventionally uses it, but agy itself only reads
        ``GEMINI_API_KEY``, so the value is forwarded under that name.
        """
        key = self._find_api_key()
        if not key:
            raise ValueError(
                "antigravity-cli requires a Gemini API key: set GEMINI_API_KEY "
                "(or GOOGLE_API_KEY) in the host environment, or pass "
                "`--ae GEMINI_API_KEY=<key>`. Create a key in Google AI Studio: "
                "https://aistudio.google.com/app/api-keys. For enterprise "
                "Application Default Credentials auth, set AGY_ADC_AUTH=true "
                "instead."
            )
        return key

    def _save_image(
        self,
        image_data: str,
        mime_type: str,
        step_id: int,
        obs_index: int,
        image_index: int = 0,
    ) -> tuple[str, _ImageMediaType] | tuple[None, None]:
        """Save a base64 image to the images directory.

        Args:
            image_data: Base64-encoded image data
            mime_type: MIME type of the image (e.g., 'image/png')
            step_id: The step ID this image belongs to
            obs_index: Index of the observation result within the step
            image_index: Index of the image within the observation (for multiple images)

        Returns:
            Tuple of (relative_path, media_type) for the saved image, or (None, None) on failure
        """
        # Create images directory if it doesn't exist
        images_dir = self.logs_dir / "images"
        images_dir.mkdir(exist_ok=True)

        # Determine file extension from mime type
        # Only accept MIME types that ImageSource validates
        extension_map: dict[_ImageMediaType, str] = {
            "image/png": "png",
            "image/jpeg": "jpg",
            "image/gif": "gif",
            "image/webp": "webp",
        }
        for valid_type, extension in extension_map.items():
            if mime_type == valid_type:
                break
        else:
            # Unsupported MIME type - return None to avoid Pydantic validation error
            self.logger.debug(f"Unsupported image MIME type: {mime_type}")
            return None, None

        # Generate unique filename
        filename = f"step_{step_id}_obs_{obs_index}_img_{image_index}.{extension}"
        image_path = images_dir / filename

        # Decode and save the image
        try:
            image_bytes = base64.b64decode(image_data)
            image_path.write_bytes(image_bytes)
        except Exception as e:
            self.logger.debug(f"Failed to save image: {e}")
            return None, None

        # Return relative path from trajectory.json location
        return f"images/{filename}", valid_type

    def _convert_gemini_to_atif(
        self, gemini_trajectory: dict[str, Any]
    ) -> Trajectory | None:
        """Convert Gemini CLI trajectory format to ATIF format."""
        session_id = gemini_trajectory.get("sessionId", "unknown")
        messages = gemini_trajectory.get("messages", [])

        if not messages:
            return None

        def _extract_text(content: Any) -> str:
            """Extract text from Gemini content field (list of dicts or string)."""
            if isinstance(content, str):
                return content
            if isinstance(content, list):
                return "\n".join(
                    part.get("text", "") if isinstance(part, dict) else str(part)
                    for part in content
                )
            return str(content) if content else ""

        steps: list[Step] = []
        step_id = 1

        # Track metrics for final_metrics calculation
        total_input_tokens = 0
        total_output_tokens = 0
        total_cached_tokens = 0

        for message in messages:
            msg_type = message.get("type")
            timestamp = message.get("timestamp")

            # User message
            if msg_type == "user":
                content = _extract_text(message.get("content", ""))
                steps.append(
                    Step(
                        step_id=step_id,
                        timestamp=timestamp,
                        source="user",
                        message=content,
                    )
                )
                step_id += 1

            # Gemini (agent) message
            elif msg_type == "gemini":
                content = _extract_text(message.get("content", ""))
                thoughts = message.get("thoughts", [])
                tool_calls_data = message.get("toolCalls", [])
                tokens = message.get("tokens", {})
                model_name = message.get("model")

                # Build reasoning content from thoughts
                reasoning_content: str | None = None
                if thoughts:
                    reasoning_parts = []
                    for thought in thoughts:
                        subject = thought.get("subject", "")
                        description = thought.get("description", "")
                        if subject and description:
                            reasoning_parts.append(f"{subject}: {description}")
                        elif description:
                            reasoning_parts.append(description)
                    if reasoning_parts:
                        reasoning_content = "\n".join(reasoning_parts)

                # Handle tool calls
                tool_calls: list[ToolCall] | None = None
                observation: Observation | None = None

                if tool_calls_data:
                    tool_calls = []
                    observation_results: list[ObservationResult] = []

                    for tc in tool_calls_data:
                        tool_call_id = tc.get("id", "")
                        tool_name = tc.get("name", "")
                        args = tc.get("args", {})
                        result = tc.get("result", [])

                        tool_calls.append(
                            ToolCall(
                                tool_call_id=tool_call_id,
                                function_name=tool_name,
                                arguments=args,
                            )
                        )

                        # Extract observation content from result
                        # This may include text output and/or image data
                        obs_content: str | list[ContentPart] | None = None
                        obs_index = len(observation_results)

                        if result:
                            text_output: str | None = None
                            image_parts: list[ContentPart] = []

                            for res_item in result:
                                if isinstance(res_item, dict):
                                    func_resp = res_item.get("functionResponse", {})
                                    response = func_resp.get("response", {})
                                    output = response.get("output")
                                    if output:
                                        text_output = output

                                    # Check for image data in parts
                                    parts = func_resp.get("parts", [])
                                    image_index = 0
                                    for part in parts:
                                        if isinstance(part, dict):
                                            inline_data = part.get("inlineData", {})
                                            if inline_data:
                                                mime_type = inline_data.get(
                                                    "mimeType", "image/png"
                                                )
                                                data = inline_data.get("data", "")
                                                if data:
                                                    # Save the image and get the path
                                                    image_path, media_type = (
                                                        self._save_image(
                                                            data,
                                                            mime_type,
                                                            step_id,
                                                            obs_index,
                                                            image_index,
                                                        )
                                                    )
                                                    if image_path and media_type:
                                                        image_parts.append(
                                                            ContentPart(
                                                                type="image",
                                                                source=ImageSource(
                                                                    media_type=media_type,
                                                                    path=image_path,
                                                                ),
                                                            )
                                                        )
                                                    image_index += 1

                            # Build observation content
                            if image_parts:
                                # Multimodal content - combine text and images
                                content_parts: list[ContentPart] = []
                                if text_output:
                                    content_parts.append(
                                        ContentPart(type="text", text=text_output)
                                    )
                                content_parts.extend(image_parts)
                                obs_content = content_parts
                            else:
                                # Text-only content
                                obs_content = text_output

                        observation_results.append(
                            ObservationResult(
                                source_call_id=tool_call_id or None,
                                content=obs_content,
                            )
                        )

                    if observation_results:
                        observation = Observation(results=observation_results)

                # Build metrics
                metrics: Metrics | None = None
                if tokens:
                    input_tokens = tokens.get("input", 0)
                    output_tokens = tokens.get("output", 0)
                    cached_tokens = tokens.get("cached", 0)
                    thoughts_tokens = tokens.get("thoughts", 0)
                    tool_tokens = tokens.get("tool", 0)

                    # Calculate completion tokens (output + thoughts + tool)
                    completion_tokens = output_tokens + thoughts_tokens + tool_tokens

                    # Update totals
                    total_input_tokens += input_tokens
                    total_output_tokens += completion_tokens
                    total_cached_tokens += cached_tokens

                    metrics = Metrics(
                        prompt_tokens=input_tokens,
                        completion_tokens=completion_tokens,
                        cached_tokens=cached_tokens,
                        extra={
                            "thoughts_tokens": thoughts_tokens,
                            "tool_tokens": tool_tokens,
                        },
                    )

                # Use thoughts as message when content is empty
                display_message = content if content else (reasoning_content or "")

                steps.append(
                    Step(
                        step_id=step_id,
                        timestamp=timestamp,
                        source="agent",
                        model_name=model_name,
                        message=display_message,
                        reasoning_content=reasoning_content if content else None,
                        tool_calls=tool_calls,
                        observation=observation,
                        metrics=metrics,
                    )
                )
                step_id += 1

        if not steps:
            return None

        # Build final metrics
        final_metrics = FinalMetrics(
            total_prompt_tokens=total_input_tokens,
            total_completion_tokens=total_output_tokens,
            total_cached_tokens=total_cached_tokens,
            total_steps=len(steps),
        )

        # Determine model name from first agent step
        default_model_name: str | None = None
        for step in steps:
            if step.source == "agent" and step.model_name:
                default_model_name = step.model_name
                break

        # Build trajectory
        trajectory = Trajectory(
            schema_version="ATIF-v1.6",
            session_id=session_id,
            agent=Agent(
                name=AgentName.ANTIGRAVITY_CLI.value,
                version=self.version() or "unknown",
                model_name=default_model_name,
            ),
            steps=steps,
            final_metrics=final_metrics,
        )

        return trajectory

    @staticmethod
    def _merge_message_update(message: dict[str, Any], update: dict[str, Any]) -> None:
        """Apply a Gemini JSONL message_update record to a message record."""
        for key, value in update.items():
            if key in {"type", "id"}:
                continue
            current = message.get(key)
            if isinstance(current, dict) and isinstance(value, dict):
                current.update(value)
            else:
                message[key] = value

    def _load_gemini_session(self, path: Path) -> dict[str, Any] | None:
        # Gemini CLI v0.40+ writes JSONL; older versions wrote a single JSON
        # blob with a `messages` array. Normalize to the legacy shape.
        text = path.read_text()
        if not text.strip():
            return None

        try:
            data = json.loads(text)
            if isinstance(data, dict) and "messages" in data:
                return data
        except json.JSONDecodeError:
            pass

        metadata: dict[str, Any] = {}
        message_ids: list[str] = []
        messages_by_id: dict[str, dict[str, Any]] = {}
        pending_updates: dict[str, list[dict[str, Any]]] = {}

        for line in text.splitlines():
            stripped = line.strip()
            if not stripped:
                continue
            try:
                record = json.loads(stripped)
            except json.JSONDecodeError:
                continue
            if not isinstance(record, dict):
                continue

            if "$rewindTo" in record:
                rewind_id = record["$rewindTo"]
                if rewind_id in message_ids:
                    idx = message_ids.index(rewind_id)
                    for removed in message_ids[idx:]:
                        messages_by_id.pop(removed, None)
                        pending_updates.pop(removed, None)
                    del message_ids[idx:]
                else:
                    message_ids.clear()
                    messages_by_id.clear()
                    pending_updates.clear()
            elif "$set" in record and isinstance(record["$set"], dict):
                metadata.update(record["$set"])
            elif record.get("type") in {"user", "gemini"}:
                mid = record.get("id")
                if isinstance(mid, str) and mid in messages_by_id:
                    message = messages_by_id[mid]
                    message.update(record)
                else:
                    message = record
                    if isinstance(mid, str):
                        message_ids.append(mid)
                        messages_by_id[mid] = message
                if isinstance(mid, str):
                    for update in pending_updates.pop(mid, []):
                        self._merge_message_update(message, update)
            elif record.get("type") == "message_update":
                mid = record.get("id")
                if isinstance(mid, str) and mid in messages_by_id:
                    self._merge_message_update(messages_by_id[mid], record)
                elif isinstance(mid, str):
                    pending_updates.setdefault(mid, []).append(record)
            elif "sessionId" in record:
                for k, v in record.items():
                    if k != "messages":
                        metadata[k] = v

        if not message_ids and not metadata:
            return None

        result: dict[str, Any] = {
            "sessionId": metadata.get("sessionId", "unknown"),
            "messages": [messages_by_id[mid] for mid in message_ids],
        }
        for k, v in metadata.items():
            if k not in ("sessionId", "messages"):
                result[k] = v
        return result

    @staticmethod
    def _load_step_transcript(path: Path) -> list[dict[str, Any]] | None:
        """Load an Antigravity 1.1.x step transcript, if ``path`` contains one."""
        # Full transcripts repeat in-progress snapshots, so files can be large
        # and duplicate keys common: track the last entry per normalized
        # (step_index, type, source) in a dict and tombstone superseded
        # snapshots in place instead of rescanning the list per line.
        entries: list[tuple[int, int, dict[str, Any]] | None] = []
        last_by_key: dict[tuple[int, str, str], int] = {}
        for line_number, line in enumerate(path.read_text().splitlines()):
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(record, dict):
                continue
            step_index = record.get("step_index")
            if not isinstance(step_index, int):
                continue

            # Replace an earlier non-terminal snapshot of the same record, but
            # preserve distinct records that happen to share a step index.
            record_type = str(record.get("type") or "").upper()
            source = str(record.get("source") or "").upper()
            key = (step_index, record_type, source)
            matching_position = last_by_key.get(key)
            if matching_position is not None:
                previous_entry = entries[matching_position]
                if previous_entry is not None:
                    previous = previous_entry[2]
                    previous_status = str(previous.get("status") or "").upper()
                    if previous == record or previous_status not in {
                        "DONE",
                        "ERROR",
                        "FAILED",
                    }:
                        entries[matching_position] = None
            entries.append((step_index, line_number, record))
            last_by_key[key] = len(entries) - 1

        records = [entry for entry in entries if entry is not None]
        if not any(
            str(record.get("type") or "").upper() in _CURRENT_TRANSCRIPT_TYPES
            for _, _, record in records
        ):
            return None
        return [record for _, _, record in sorted(records)]

    @staticmethod
    def _transcript_text(value: Any) -> str:
        if value is None:
            return ""
        if isinstance(value, str):
            return value
        if isinstance(value, (dict, list)):
            return json.dumps(value, ensure_ascii=False)
        return str(value)

    @staticmethod
    def _transcript_timestamp(value: Any) -> str | None:
        """Normalize supported transcript timestamps without failing the export."""
        if isinstance(value, bool) or value is None:
            return None
        if isinstance(value, (int, float)):
            # Antigravity transcripts have used both Unix seconds and milliseconds.
            seconds = value / 1000 if abs(value) >= 100_000_000_000 else value
            try:
                return datetime.fromtimestamp(seconds, tz=timezone.utc).isoformat()
            except (OSError, OverflowError, ValueError):
                return None
        if isinstance(value, str):
            try:
                return datetime.fromisoformat(value.replace("Z", "+00:00")).isoformat()
            except ValueError:
                return None
        return None

    def _convert_step_transcript_to_atif(
        self, records: list[dict[str, Any]]
    ) -> Trajectory | None:
        """Convert Antigravity 1.1.x step records to ATIF v1.7."""
        steps: list[Step] = []
        pending_calls: list[tuple[Step, str]] = []

        for record in records:
            record_type = str(record.get("type") or "").upper()
            if record_type in _INTERNAL_TRANSCRIPT_TYPES:
                continue

            timestamp = self._transcript_timestamp(record.get("created_at"))
            content = self._transcript_text(record.get("content"))

            if record_type == "USER_INPUT":
                steps.append(
                    Step(
                        step_id=len(steps) + 1,
                        timestamp=timestamp,
                        source="user",
                        message=content,
                    )
                )
                continue

            if record_type == "PLANNER_RESPONSE":
                tool_calls: list[ToolCall] = []
                step_index = record.get("step_index")
                for call_index, raw_call in enumerate(record.get("tool_calls") or []):
                    if not isinstance(raw_call, dict):
                        continue
                    call_id = f"antigravity-{step_index}-{call_index}"
                    raw_arguments = raw_call.get("args")
                    arguments = (
                        raw_arguments
                        if isinstance(raw_arguments, dict)
                        else {"value": raw_arguments}
                    )
                    tool_calls.append(
                        ToolCall(
                            tool_call_id=call_id,
                            function_name=str(raw_call.get("name") or "unknown"),
                            arguments=arguments,
                        )
                    )

                step = Step(
                    step_id=len(steps) + 1,
                    timestamp=timestamp,
                    source="agent",
                    model_name=self.model_name,
                    message=content,
                    reasoning_content=self._transcript_text(record.get("thinking"))
                    or None,
                    tool_calls=tool_calls or None,
                )
                steps.append(step)
                # Results have no call IDs. Scope their positional association to
                # the latest planner response so an incomplete turn cannot shift
                # every subsequent result.
                pending_calls = [(step, call.tool_call_id) for call in tool_calls]
                continue

            error = self._transcript_text(record.get("error"))
            status = str(record.get("status") or "").upper()
            # Tool result steps follow planner tool calls in the same order but do
            # not carry call IDs. Fold each one into the issuing agent step before
            # classifying SYSTEM-sourced and ERROR results as standalone events.
            if pending_calls:
                step, call_id = pending_calls.pop(0)
                result_extra = {
                    key: record[key]
                    for key in (
                        "type",
                        "status",
                        "exit_code",
                        "exitCode",
                        "error",
                    )
                    if record.get(key) is not None
                }
                result = ObservationResult(
                    source_call_id=call_id,
                    content=content
                    or self._transcript_text(record.get("error"))
                    or None,
                    extra=result_extra or None,
                )
                if step.observation is None:
                    step.observation = Observation(results=[result])
                else:
                    step.observation.results.append(result)
                continue

            # Preserve actionable system and error records once all results for
            # the current planner response have been consumed.
            if content or error or status in {"ERROR", "FAILED"}:
                steps.append(
                    Step(
                        step_id=len(steps) + 1,
                        timestamp=timestamp,
                        source="system",
                        message=content or error or f"{record_type} failed",
                        extra={
                            "antigravity_type": record_type,
                            "status": record.get("status"),
                        },
                    )
                )

        if not steps:
            return None

        return Trajectory(
            schema_version="ATIF-v1.7",
            session_id=self.session_id,
            agent=Agent(
                name=AgentName.ANTIGRAVITY_CLI.value,
                version=self.version() or "unknown",
                model_name=self.model_name,
            ),
            steps=steps,
            final_metrics=FinalMetrics(total_steps=len(steps)),
        )

    _STREAM_LOG_FILENAME = "antigravity-stream.jsonl"
    _STDERR_LOG_FILENAME = "antigravity-cli.err"

    def _stream_usage_totals(self) -> tuple[int, int, int] | None:
        """Return (prompt, completion, cached) tokens from the stream-json log.

        The step transcript carries no usage data at all, so token and cost
        reporting has to come from agy's ``--output-format stream-json`` output,
        which emits a ``usage`` block on each terminal ``step_update`` and an
        aggregate on the ``result`` event.

        Prefers the ``result`` aggregate and falls back to summing the steps,
        so a run killed before the result event still reports what it spent.
        Returns None when the log has no usage at all.

        ``cache_read_tokens`` is disjoint from ``input_tokens`` in the stream
        while ATIF's prompt total is defined as inclusive of cache hits, so the
        two are summed; otherwise cached would exceed the total it is part of.
        """
        path = self.logs_dir / self._STREAM_LOG_FILENAME
        if not path.exists():
            return None

        def _as_int(value: Any) -> int:
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                return 0
            return int(value)

        def _totals(usage: dict[str, Any]) -> tuple[int, int, int]:
            cached = _as_int(usage.get("cache_read_tokens"))
            return (
                _as_int(usage.get("input_tokens")) + cached,
                _as_int(usage.get("output_tokens")),
                cached,
            )

        def _largest(
            seen: tuple[int, int, int] | None, totals: tuple[int, int, int]
        ) -> tuple[int, int, int]:
            if seen is None:
                return totals
            return (
                max(seen[0], totals[0]),
                max(seen[1], totals[1]),
                max(seen[2], totals[2]),
            )

        def _sum(values: Iterable[tuple[int, int, int]]) -> tuple[int, int, int]:
            prompt, completion, cached = 0, 0, 0
            for value in values:
                prompt += value[0]
                completion += value[1]
                cached += value[2]
            return prompt, completion, cached

        # A repeat restates a running total rather than adding to it. Keeping
        # the largest value seen stops a repeat multiplying the bill and stops a
        # zero-filled update erasing a real one. Print mode streams a single
        # conversation, so a step index identifies a step on its own.
        result_total: tuple[int, int, int] | None = None
        step_totals: dict[int, tuple[int, int, int]] = {}
        # Usage without a step index cannot be identified as a repeat.
        unkeyed_totals: list[tuple[int, int, int]] = []
        # A run killed mid-write leaves the last line truncated. agy also prints
        # its interactive auth fallback as plain text.
        text = path.read_text(encoding="utf-8", errors="replace")
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(event, dict):
                continue
            if event.get("event") == "result":
                usage = (event.get("result") or {}).get("usage")
                if isinstance(usage, dict):
                    result_total = _largest(result_total, _totals(usage))
            elif event.get("event") == "step_update":
                payload = event.get("step_update") or {}
                usage = payload.get("usage")
                if isinstance(usage, dict):
                    usage_totals = _totals(usage)
                    step_index = payload.get("step_index")
                    if isinstance(step_index, bool) or not isinstance(step_index, int):
                        unkeyed_totals.append(usage_totals)
                        continue
                    step_totals[step_index] = _largest(
                        step_totals.get(step_index), usage_totals
                    )

        if result_total is not None:
            return result_total
        if step_totals or unkeyed_totals:
            return _sum([*step_totals.values(), *unkeyed_totals])
        return None

    def _apply_stream_usage(
        self, context: AgentContext, trajectory: "Trajectory | None"
    ) -> None:
        """Record stream-json token usage on the context and the trajectory."""
        totals = self._stream_usage_totals()
        if totals is None:
            return
        prompt, completion, cached = totals
        context.n_input_tokens = prompt
        context.n_output_tokens = completion
        context.n_cache_tokens = cached
        context.cost_usd = self._compute_cost_from_pricing(prompt, completion, cached)
        if trajectory is not None and trajectory.final_metrics is not None:
            trajectory.final_metrics.total_prompt_tokens = prompt
            trajectory.final_metrics.total_completion_tokens = completion
            trajectory.final_metrics.total_cached_tokens = cached
            trajectory.final_metrics.total_cost_usd = context.cost_usd

    def _compute_cost_from_pricing(
        self,
        prompt_tokens: int | None,
        completion_tokens: int | None,
        cached_tokens: int | None,
    ) -> float | None:
        # Gemini CLI's session file has no cost field; back it out from
        # LiteLLM's pricing. Return None on miss rather than a misleading $0.
        if not self.model_name:
            return None

        try:
            import litellm
        except ImportError:
            self.logger.debug("litellm not available; cost_usd left as None")
            return None

        pricing: dict[str, Any] | None = None
        for key in (self.model_name, self.model_name.split("/", 1)[-1]):
            entry = litellm.model_cost.get(key)
            if entry:
                pricing = entry
                break

        if pricing is None:
            self.logger.debug(
                "No LiteLLM pricing for '%s'; cost_usd left as None",
                self.model_name,
            )
            return None

        input_rate = pricing.get("input_cost_per_token") or 0.0
        output_rate = pricing.get("output_cost_per_token") or 0.0
        cache_read_rate = pricing.get("cache_read_input_token_cost") or input_rate

        uncached = max(0, (prompt_tokens or 0) - (cached_tokens or 0))
        cached = cached_tokens or 0
        output = completion_tokens or 0

        return uncached * input_rate + cached * cache_read_rate + output * output_rate

    @override
    def populate_context_post_run(self, context: AgentContext) -> None:
        gemini_path: Path | None = None
        for candidate in (
            "antigravity-cli.trajectory.jsonl",
            "antigravity-cli.trajectory.json",
        ):
            p = self.logs_dir / candidate
            if p.exists():
                gemini_path = p
                break

        if gemini_path is None:
            # No trajectory to build, but the stream log may still show usage.
            self._apply_stream_usage(context, None)
            return

        step_records = self._load_step_transcript(gemini_path)
        if step_records is not None:
            try:
                trajectory = self._convert_step_transcript_to_atif(step_records)
                if trajectory is not None:
                    # Step transcripts expose no usage, so tokens and cost come
                    # from the stream-json log written by the same run.
                    self._apply_stream_usage(context, trajectory)
                    (self.logs_dir / "trajectory.json").write_text(
                        json.dumps(trajectory.to_json_dict(), indent=2)
                    )
                    return
            except Exception as e:
                self.logger.debug(
                    f"Error converting Antigravity step transcript to ATIF: {e}"
                )
            # A mixed or partially parseable transcript may still contain a
            # legacy Gemini session, so let that parser make a best effort.

        gemini_trajectory = self._load_gemini_session(gemini_path)
        if gemini_trajectory is None:
            self.logger.debug(f"Could not parse Gemini session at {gemini_path}")
            # An empty or malformed transcript still leaves the stream log, which
            # is written separately and carries the run's usage. Reporting no
            # trajectory is not a reason to also report no tokens and no cost.
            self._apply_stream_usage(context, None)
            return

        n_input_tokens = 0
        n_output_tokens = 0
        n_cache_tokens = 0
        for message in gemini_trajectory.get("messages", []):
            if message.get("type") == "gemini":
                tokens = message.get("tokens") or {}
                n_input_tokens += tokens.get("input", 0)
                n_output_tokens += (
                    tokens.get("output", 0)
                    + tokens.get("tool", 0)
                    + tokens.get("thoughts", 0)
                )
                n_cache_tokens += tokens.get("cached", 0)

        context.n_input_tokens = n_input_tokens
        context.n_output_tokens = n_output_tokens
        context.n_cache_tokens = n_cache_tokens
        context.cost_usd = self._compute_cost_from_pricing(
            n_input_tokens, n_output_tokens, n_cache_tokens
        )

        try:
            atif_trajectory = self._convert_gemini_to_atif(gemini_trajectory)

            if atif_trajectory:
                atif_path = self.logs_dir / "trajectory.json"
                atif_path.write_text(
                    json.dumps(atif_trajectory.to_json_dict(), indent=2)
                )
        except Exception as e:
            self.logger.debug(f"Error converting Gemini trajectory to ATIF: {e}")

    def _build_register_skills_command(self) -> str | None:
        """Return a shell command that copies skills to the Antigravity CLI skills directory."""
        if not self.skills_dir:
            return None
        return (
            f"mkdir -p ~/.gemini/antigravity-cli/skills && "
            f"cp -r {shlex.quote(self.skills_dir)}/* "
            f"~/.gemini/antigravity-cli/skills/ 2>/dev/null || true"
        )

    @staticmethod
    def _parse_known_models(stdout: str) -> set[str]:
        """Parse `agy models` output into a set of model slugs.

        The output is a progress line followed by tab-separated
        ``slug<TAB>display name`` rows; anything unparseable yields an empty
        set so callers fall back to registering the model.
        """
        known: set[str] = set()
        for line in stdout.splitlines():
            parts = [part.strip() for part in line.split("\t")]
            if len(parts) >= 2 and parts[0] and " " not in parts[0]:
                known.add(parts[0])
        return known

    @staticmethod
    def _model_is_known(model: str, known: set[str]) -> bool:
        """True when agy's model gate recognizes the slug.

        ADC-mode listings publish effort-suffixed slugs (gemini-3.7-flash-low
        etc.) while the gate also accepts the bare base name and then demands
        --effort; registering the base name instead would route it through
        the broken custom-model path.
        """
        if model in known:
            return True
        # Probe with the agent's full effort vocabulary (including "minimal")
        # so the two never diverge.
        return any(f"{model}-{effort}" in known for effort in _REASONING_EFFORT_CHOICES)

    def _build_settings_config(
        self, model: str | None = None, register_model: bool = True
    ) -> dict[str, Any]:
        """Build the agy settings.json content for this run."""
        config: dict[str, Any] = {}

        if self.mcp_servers:
            servers = {}
            for server in self.mcp_servers:
                if server.transport == "stdio":
                    servers[server.name] = {
                        "command": server.command,
                        "args": server.args,
                    }
                elif server.transport == "streamable-http":
                    servers[server.name] = {"httpUrl": server.url}
                else:  # sse
                    servers[server.name] = {"url": server.url}
            config["mcpServers"] = servers

        if model and register_model:
            # agy rejects any --model outside its `agy models` list unless it
            # is registered here — registration is what lets non-built-in
            # slugs (and custom GOOGLE_GEMINI_BASE_URL endpoints) run at all.
            # Never register a built-in: registration routes the slug through
            # agy's custom-model request path, which 400s for several models
            # that work fine on their native path (agy 1.1.14).
            config["customModelsConfig"] = {
                "customModels": {model: {"modelName": model}}
            }

        if not self._use_adc_auth() and self._find_api_key():
            # Documented headless auth: modelProvider="gemini" plus the
            # GEMINI_API_KEY env var makes agy skip the sign-in screen. Never
            # written without the key — agy refuses to start on that
            # combination — and never in ADC mode, which must not route to the
            # Gemini API.
            config["modelProvider"] = "gemini"

        # The workspace root comes from --add-dir "$PWD" on the run command;
        # this documented switch additionally lets tasks touch paths outside
        # that root.
        config["allowNonWorkspaceAccess"] = True
        config["experimental"] = {"skills": True}
        return config

    _RUN_MARKER = "/tmp/.harbor-antigravity-run-start"

    def _build_collect_trajectory_command(self, scoped: bool) -> str:
        """Return the post-run command that copies trajectory artifacts.

        agy 1.1.x writes the transcript to
        ``~/.gemini/antigravity-cli/brain/<uuid>/.system_generated/logs/`` and
        the complete tool-call record (the only one that survives a mid-turn
        cutoff) to ``~/.gemini/antigravity-cli/conversations/<uuid>.db``
        (verified live on 1.1.14). Both are copied into /logs/agent; the
        pre-1.1 ``~/.agy`` location stays as a fallback for older binaries.
        Parsing the transcript into ATIF is #2687's job — this only collects.
        ``scoped`` limits collection to files newer than the run marker so a
        retained container cannot leak a previous run's trajectory.
        """
        newer = f"-newer {self._RUN_MARKER} " if scoped else ""
        # Tab-separated mtime sort survives paths with spaces.
        return (
            'src=$(find "$HOME/.gemini/antigravity-cli/brain" -type f '
            f"-name 'transcript_full.jsonl' {newer}"
            "-printf '%T@\\t%p\\n' 2>/dev/null | sort -nr | head -n1 | cut -f2-); "
            'if [ -n "$src" ]; then '
            'cp -- "$src" /logs/agent/antigravity-cli.trajectory.jsonl; '
            "else "
            'src=$(find "$HOME/.agy/antigravity-cli/tmp" -type f '
            "\\( -name 'session-*.jsonl' -o -name 'session-*.json' \\) "
            f"{newer}"
            "-printf '%T@\\t%p\\n' 2>/dev/null | sort -nr | head -n1 | cut -f2-); "
            'if [ -n "$src" ]; then '
            'cp -- "$src" "/logs/agent/antigravity-cli.trajectory.${src##*.}"; '
            "fi; fi; "
            'db=$(find "$HOME/.gemini/antigravity-cli/conversations" -type f '
            f"-name '*.db' {newer}"
            "-printf '%T@\\t%p\\n' 2>/dev/null | sort -nr | head -n1 | cut -f2-); "
            'if [ -n "$db" ]; then '
            'cp -- "$db" /logs/agent/antigravity-conversation.db; '
            "for ext in -wal -shm; do "
            '[ -f "${db}${ext}" ] && '
            'cp -- "${db}${ext}" "/logs/agent/antigravity-conversation.db${ext}"; '
            "done; fi; true"
        )

    def _build_mcp_config(self) -> dict[str, Any]:
        """Build ~/.gemini/config/mcp_config.json for agy >= 1.1.27.

        Newer agy reads MCP servers from this file, not from the ``mcpServers``
        block in settings.json, and it names an HTTP endpoint ``serverUrl``
        (``httpUrl`` there is parsed as a stdio command). The same shape is
        what ``agy mcp add`` writes. settings.json keeps its ``mcpServers``
        block so older agy builds still see the servers.
        """
        servers: dict[str, Any] = {}
        for server in self.mcp_servers:
            if server.transport == "stdio":
                servers[server.name] = {
                    "command": server.command,
                    "args": server.args,
                    "disabled": False,
                }
            else:  # streamable-http and sse are both URL servers to agy
                servers[server.name] = {"serverUrl": server.url, "disabled": False}
        return {"mcpServers": servers}

    def _build_settings_command(
        self,
        model: str | None = None,
        register_model: bool = True,
        activate_mcp: bool = True,
    ) -> str:
        """Return the command that writes settings.json where agy reads it."""
        config = self._build_settings_config(model, register_model=register_model)
        if not activate_mcp:
            config.pop("mcpServers", None)
        escaped = shlex.quote(json.dumps(config, indent=2))
        command = (
            "mkdir -p ~/.gemini/antigravity-cli && "
            f"printf %s {escaped} > ~/.gemini/antigravity-cli/settings.json"
        )
        if self.mcp_servers or not activate_mcp:
            mcp_config = (
                self._build_mcp_config() if activate_mcp else {"mcpServers": {}}
            )
            mcp_escaped = shlex.quote(json.dumps(mcp_config, indent=2))
            command += (
                " && mkdir -p ~/.gemini/config && "
                f"printf %s {mcp_escaped} > ~/.gemini/config/mcp_config.json"
            )
        return command

    def _forwarded_cli_env(self) -> dict[str, str]:
        """Collect non-empty ``AGY_CLI_*`` variables across env sources in precedence order."""
        forwarded: dict[str, str] = {}
        for source in self._env_sources():
            for name, value in source.items():
                if name.startswith("AGY_CLI_") and value:
                    forwarded.setdefault(name, value)
        return forwarded

    @with_prompt_template
    async def run(
        self,
        instruction: str,
        environment: BaseEnvironment,
        context: AgentContext,
    ) -> None:
        escaped_instruction = shlex.quote(instruction)

        if not self.model_name or "/" not in self.model_name:
            raise ValueError("Model name must be in the format provider/model_name")

        model = self.model_name.split("/")[-1]

        # Gemini CLI refuses to honor `--yolo` in an untrusted workspace and
        # overrides approval mode back to "default"
        env = {"GEMINI_CLI_TRUST_WORKSPACE": "true"}
        if self._use_adc_auth():
            if "2.5" in model:
                raise ValueError(
                    "ADC auth (AGY_ADC_AUTH) supports Gemini 3 Flash and newer "
                    f"models only; '{model}' is not supported. Use a Gemini 3 "
                    "model or authenticate with GEMINI_API_KEY instead."
                )
            env["AGY_ADC_AUTH"] = "true"
            # Go's ADC resolution honors this as the credentials-file pointer;
            # the file itself must already be in the container (baked or
            # mounted), Harbor does not upload credentials.
            adc_path = self._get_env("GOOGLE_APPLICATION_CREDENTIALS")
            if adc_path:
                env["GOOGLE_APPLICATION_CREDENTIALS"] = adc_path
            self.logger.debug("antigravity-cli auth: enterprise ADC mode")
        else:
            # The only credential variable agy reads; GOOGLE_API_KEY values
            # arrive here under the name agy honors.
            env["GEMINI_API_KEY"] = self._resolve_api_key()
            base_url = self._get_env("GOOGLE_GEMINI_BASE_URL")
            if base_url:
                self._validate_base_url(base_url)
                env["GOOGLE_GEMINI_BASE_URL"] = base_url
            self.logger.debug(
                "antigravity-cli auth: Gemini API key mode"
                + (" (custom base URL set)" if base_url else "")
            )

        env.update(self._forwarded_cli_env())

        # Provisioning commands never talk to the API, so they run without
        # the auth env: secrets reach only `agy models` and agy itself.
        skills_command = self._build_register_skills_command()
        if skills_command:
            await self.exec_as_agent(environment, command=skills_command)

        # Settings first: `agy models` below needs the auth opt-in
        # (modelProvider + key) already on disk to fetch the listing.
        # Do not activate MCP yet: agy models opens these connections but exits
        # before initialization completes. Clear any previous run's config too.
        await self.exec_as_agent(
            environment,
            command=self._build_settings_command(
                model, register_model=False, activate_mcp=False
            ),
        )

        # Register the model only when agy does not already know it: built-in
        # slugs must take their native request path (the custom path 400s for
        # several of them). If the listing is unavailable or unparseable, fall
        # back to registering, which preserves behavior for unknown slugs.
        register_model = False
        if model:
            register_model = True
            try:
                listing = await self.exec_as_agent(
                    environment,
                    # Daytona and Modal keep async-session stdin open. agy 1.1.22
                    # waits for EOF even for this non-interactive subcommand, so
                    # disconnect stdin explicitly just like the prompt command.
                    command="$HOME/.local/bin/agy models </dev/null",
                    env=env,
                    timeout_sec=self._MODEL_LIST_TIMEOUT_SEC,
                )
                known = self._parse_known_models(listing.stdout or "")
                if known:
                    register_model = not self._model_is_known(model, known)
            except Exception:
                self.logger.debug("agy models listing failed; registering model")
        await self.exec_as_agent(
            environment,
            command=self._build_settings_command(model, register_model=register_model),
        )

        cli_flags = self.build_cli_flags()
        extra_flags = (cli_flags + " ") if cli_flags else ""
        # agy selects its model from --model (matched against the customModels
        # registration in settings.json); headless runs fail loudly on unknown
        # models instead of falling back to the default.
        model_flag = f"--model {shlex.quote(model)} " if model else ""
        effort_flag = (
            f"--effort {shlex.quote(self.options.reasoning_effort)} "
            if self.options.reasoning_effort
            else ""
        )

        # Scope trajectory collection to this run; on failure collect
        # unscoped rather than lose the trajectory entirely.
        marker_created = False
        try:
            await self.exec_as_agent(environment, command=f"touch {self._RUN_MARKER}")
            marker_created = True
        except Exception:
            self.logger.debug("run marker creation failed; collecting unscoped")

        try:
            await self.exec_as_agent(
                environment,
                command=(
                    f"$HOME/.local/bin/agy --dangerously-skip-permissions "
                    f"--print-timeout {self._PRINT_TIMEOUT} "
                    # The step transcript carries no usage data, so token and
                    # cost totals are read back from this stream. agy still
                    # writes the transcript alongside it.
                    f"--output-format stream-json "
                    # Register the cwd as the workspace: without it headless
                    # agy anchors bare-filename file-tool writes to its own
                    # scratch dir instead of the task workdir (agy 1.1.14).
                    f'--add-dir "$PWD" '
                    f"{model_flag}{effort_flag}{extra_flags}--prompt={escaped_instruction} "
                    # agy logs heavily to stderr. Sharing one pipe would let a
                    # stderr line land inside a JSON record larger than
                    # PIPE_BUF. Replaying the stderr afterwards keeps API and
                    # network failures visible to error classification, which
                    # matches ERROR_PATTERNS against the exec's own output.
                    # Only on a non-zero exit, because that is the only time
                    # anything reads it (_classify_exec_error), and capped by
                    # bytes rather than lines, since agy keeps logging after a
                    # failed call and a small line window drops the one line
                    # that selects a targeted retry policy.
                    f"2>/logs/agent/{self._STDERR_LOG_FILENAME} </dev/null "
                    f"| stdbuf -oL tee /logs/agent/{self._STREAM_LOG_FILENAME}; "
                    f"rc=$?; if [ $rc -ne 0 ]; then "
                    f"tail -c {self._STDERR_REPLAY_BYTES} "
                    f"/logs/agent/{self._STDERR_LOG_FILENAME} >&2; fi; "
                    f"exit $rc"
                ),
                env=env,
            )
        finally:
            try:
                await self.exec_as_agent(
                    environment,
                    command=self._build_collect_trajectory_command(
                        scoped=marker_created
                    ),
                )
            except Exception:
                pass
